import { Checkbox, FormControlLabel, MenuItem, OutlinedInput, Select, TextField } from "@mui/material";
import React, { useEffect, useMemo, useState } from "react";
import { MuiDataTable } from "../../../../shared-web/basicTable/DataTable";
import { FormikDropdown, FormikFastDropdown } from "../../../../shared-web/formik/FormikDropdown";
import { ErrorMessage, FastField, Field } from "formik";
import { FieldFormik } from "../../../../shared-web/formik/FormikBase";
import { GridConfigColumns } from "../../../services/CreateNewWidgetService";
import { FormikCheckBox } from "../../../../shared-web/formik/FormikCheckbox";
import { MuiDropdown } from "../../../../shared-web/dropdown/MuiDropdown";

interface Properties {
  gridConfigData: any;
  onChangeDropdown(event: Event, tableData: any): void;
}

export const GridConfiguration: React.FC<Properties> = props => {
  const { gridConfigData } = props;
  const [setUpdateGridConfigData] = React.useState<any>(gridConfigData);

  const dropdownlist = [
    { id: "Yes", text: "Yes" },
    { id: "No", text: "No" }
  ];


  useEffect(() => {
    // console.log(gridConfigData, "asdfsadfdsa");
    return ()=>{
      // console.log(gridConfigData,"test");
    }
  }, [props])

  const gridConfig = {
    columns: [
      {
        name: "columnName",
        label: "Column Name"
      },
      {
        name: "displayName",
        label: "Display Name",
        options: {
           customBodyRender: (value: any, tableMeta: any, updateValue: any) => {
            // return <FormikFastDropdown id={`${tableMeta.rowIndex}.${tableMeta.columnData.name}`} value={value ?? "Yes"} options={dropdownlist} onChange={(event) => props.onChangeDropdown(event, tableMeta)} />
            return  <TextField className="displayNameField"
              id={`confProperties.gridConfig.columns[${tableMeta.rowIndex}][${tableMeta.columnData.name}]`}
              name={`confProperties.gridConfig.columns[${tableMeta.rowIndex}][${tableMeta.columnData.name}]`}
              onChange={(event:any) => props.onChangeDropdown(event.target.value, tableMeta)}          
              size="small"
             />
          //  return <Field name="{`${tableMeta.rowIndex}.${tableMeta.columnData.name}`}" onChange={(event:any) => props.onChangeDropdown(event.target.value, tableMeta)}/>
          }
        }
      },
      {
        name: "visibility",
        label: "Visibility",
        options: {
          customBodyRender: (value: any, tableMeta: any, updateValue: any) => {
            // return <FormikFastDropdown id={`confProperties.gridConfig.columns[${tableMeta.rowIndex}][${tableMeta.columnData.name}]`} options={dropdownlist} onChange={(event) => props.onChangeDropdown(event, tableMeta)} />
            return  (
              <>
            <ErrorMessage name={`confProperties.gridConfig.columns[${tableMeta.rowIndex}][${tableMeta.columnData.name}]`} />
            <FormikFastDropdown id={`${tableMeta.rowIndex}[${tableMeta.columnData.name}]`} options={dropdownlist} onChange={(event) => props.onChangeDropdown(event, tableMeta)} />
            </>
            )
          }
        }

      },     
      {
        name: "sorting",
        label: "Sorting",
        options: {
          editable: true,
          customBodyRender: (value: any, tableMeta: any, updateValue: any) => {
            // return <FormikFastDropdown id={`confProperties.gridConfig.columns[${tableMeta.rowIndex}][${tableMeta.columnData.name}]`}  options={dropdownlist} onChange={(event) => props.onChangeDropdown(event, tableMeta)} />
            return <FormikFastDropdown id={`${tableMeta.rowIndex}[${tableMeta.columnData.name}]`}  options={dropdownlist} onChange={(event) => props.onChangeDropdown(event, tableMeta)} />
          }
        }
      },
      {
        name: "filter",
        label: "Filter",
        options: {
          customBodyRender: (value: any, tableMeta: any, updateValue: any) => {
            // return <FormikFastDropdown id={`confProperties.gridConfig.columns[${tableMeta.rowIndex}][${tableMeta.columnData.name}]`} options={dropdownlist} onChange={(event) => props.onChangeDropdown(event, tableMeta)} />
            return <FormikFastDropdown id={`${tableMeta.rowIndex}[${tableMeta.columnData.name}]`} options={dropdownlist} onChange={(event) => props.onChangeDropdown(event, tableMeta)} />
          }
        }
      }
    ]
  };

  return (
    <FastField>
      {(fieldFormik: FieldFormik<string>): JSX.Element => (
        <div className="backgroundColor">
          <h3 className="configureTitle">Configure grid features:</h3>
          <MuiDataTable
            id={'lineDataTable'}
            className={'innerDataTableMain'}
            title={''}
            tableType={'mui'}
            titleFontSize={24}
            titleColor={""}
            onTableInit={(action: string, tableState: Object): void => { console.log(action) }}
            tableData={gridConfigData}
            tableColumn={gridConfig.columns}
            tableOptions={{
              print: false,
              pagination: false,
              filter: false,
              sort: false,
              search: false,
              download: false,
              viewColumns: false,
              selectableRowsHideCheckboxes: true
            }}
          />
          <div className="checkboxField">
            {/* <span className="exportImgCheckbox">
              <FormikCheckBox id="exportToExcel" labelText="Export to excel" />
            </span> */}
            {/* <FormikCheckBox id="print" labelText="Print" /> */}
            <label className="exportImgCheckbox checkboxContainer">
              <Field className="checkbox" type="checkbox" name="confProperties.gridConfig.excelExport" />
              Export to excel
              <span className="checkmark"></span>
            </label>
            <label className="checkboxContainer">
              <Field className="checkbox" type="checkbox" name="confProperties.gridConfig.print" />
              Print
              <span className="checkmark"></span>
            </label>
          </div>
        </div>
      )}
    </FastField>

  )
}
