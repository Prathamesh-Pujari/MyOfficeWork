import { Accordion, AccordionDetails, AccordionSummary, Grid, Typography } from "@mui/material";
import { ErrorMessage, Field, Formik, FormikProps } from "formik";
import { Buttons } from "../../../../shared-web/buttons/Buttons";
import { useStyles } from "../../../../shared-web/buttons/ButtonStyles";
import { btnColorType, btnSizeType, buttonTypeVariants, buttonVariants } from "../../../../shared-web/enums/Buttons";
import { GridConfiguration } from "./GridConfiguration";
import { useContext, useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";
import * as yup from "yup";
import { FormikFormErrors } from "../../../../shared-web/formik/FormikFormErrors";
import { GridConfigColumns, gridConfiguration } from "../../../services/CreateNewWidgetService";
import { WidgetConfiguration } from "./WidgetConfiguration";
import "../CreateWidget.scss";
import { GraphConfiguration } from "./GraphConfiguration";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import "../../../../portal-web/app-components/accordion/accordionContainer.scss";
import { FormikCheckBox } from "../../../../shared-web/formik/FormikCheckbox";
import { saveGridGraphConfiguration } from "../../../services/widgetService";
import { StepperProviderContext } from "../../../../shared-web/stepper/StepperContextProvider";



// export interface WidgetConfig {
//     widgetTitle: string;
//     accessGroups: string;
//     addSearchTags: string;
//     exportToExcel: boolean;
//     print: boolean;
//     graphType: string;
//     xAxis: string;
//     yAxis: string;
//     exportToImage: boolean;
//     graphPrint: boolean;
//     gridConfig?: [];
//     grid: boolean;
//     graph: boolean;
// }

// const initialValues: WidgetConfig = {
//     widgetTitle: "",
//     accessGroups: "",
//     addSearchTags: "",
//     exportToExcel: false,
//     print: false,
//     graphType: "",
//     xAxis: "",
//     yAxis: "",
//     exportToImage: false,
//     graphPrint: false,
//     grid: true,
//     graph: false
// }

export interface GridConfig {
    columns: {
        columnName: string;
        displayName: string;
        visibility: string;
        filter: string;
        sorting: string;
    }[];
    print: boolean;
    excelExport: boolean;
    grid?: boolean;
}

export interface GraphConfig {
    exportToImage: boolean;
    print: boolean;
    graphType: string;
    xAxis: string;
    yAxis: string;
    graph?: boolean;
}
export interface GridGraphConfig {
    gridConfig: GridConfig;
    graphConfig: GraphConfig;
};
export interface WidgetConfig {
    widgetId: string;
    widgetName: string;
    accessGroups: string;
    tags: string;
    widgetType: string;
    confProperties: GridGraphConfig;
}

const initialValues: WidgetConfig = {
    widgetId: "",
    widgetName: "",
    accessGroups: "",
    tags: "",
    widgetType: "",
    confProperties: {
        gridConfig: {
            columns: [],
            print: false,
            excelExport: false,
            grid: true
        },
        graphConfig: {
            exportToImage: false,
            print: false,
            graphType: "",
            xAxis: "",
            yAxis: "",
            graph: false
        }
    }
}

export const makeSchema = yup.object<WidgetConfig>().shape<Partial<WidgetConfig>>({
    widgetName: yup.string().required("Please enter Widget Title "),
    accessGroups: yup.string().required("Access groups is required"),
    tags: yup.string().required("Please enter Tags"),
    // graphType: yup.string().when("graph", {
    //     is: value => typeof value === "boolean" && value === true,
    //     then: yup.string().required("Graph Type is required")
    // }),
    // xAxis: yup.string().when("graph", {
    //     is: value => typeof value === "boolean" && value === true,
    //     then: yup.string().required("X-axis is required")
    // }),
    // yAxis: yup.string().when("graph", {
    //     is: value => typeof value === "boolean" && value === true,
    //     then: yup.string().required("Y-axis is required")
    // }),
    confProperties: yup.object<GridGraphConfig>().shape<Partial<GridGraphConfig>>({

        graphConfig: yup.object<GraphConfig>().shape<Partial<GraphConfig>>({
            graphType: yup.string().when("graph", {
                is: value => typeof value === "boolean" && value === true,
                then: yup.string().required("Graph Type is required")
            }),
            xAxis: yup.string().when("graph", {
                is: value => typeof value === "boolean" && value === true,
                then: yup.string().required("X-axis is required")
            }),
        }) as yup.ObjectSchema<GraphConfig>,

        gridConfig: yup.object<GridConfig>().shape<Partial<GridConfig | any>>({
            columns: yup.array().of(
                yup.object().shape({
                    visibility: yup.string().required("required"),
                    filter: yup.string().required(),
                    sorting: yup.number().required(),

                })
            ),
        }) as yup.ObjectSchema<GridConfig>,

    }) as yup.ObjectSchema<GridGraphConfig>
});

export const CreateWidgetStepTwo: React.FC = () => {

    const [gridConfigData, setGridConfigData] = useState<any>();
    const [expanded, setExpanded] = useState<any>("panel1")
    const formikRef = useRef<FormikProps<WidgetConfig>>(null);
    const classes = useStyles();

    const { handleOnNextStep, handleOnBackStep } = useContext(
        StepperProviderContext
    );

    const handleSubmit = useCallback(async (values: WidgetConfig) => {
        values.confProperties.gridConfig.columns = gridConfigData;
        switch (true) {
            case (values.confProperties.gridConfig.grid && values.confProperties.graphConfig.graph):
                values.widgetType = "grid graph";
                break;
            case (values.confProperties.gridConfig.grid):
                values.widgetType = "grid";
                break;
            case (values.confProperties.graphConfig.graph):
                values.widgetType = "graph";
                break;
            default:
                values.widgetType = "";
        }
        console.log(values, "values");
        try {
            await saveGridGraphConfiguration("2", values);
            handleOnNextStep()
        } catch (err) {
            const error = err as any;
        }
    }, [gridConfigData]);


    // const handleChange =
    //     (panel: string) => (event: React.SyntheticEvent, isExpanded: boolean) => {
    //         // setExpanded(isExpanded ? panel : false);
    //         setExpanded(isExpanded ? panel : false);
    //     };

    /*********Set default values to grid dropdowns ************/
    // const visibleColumns: (keyof GridConfigColumns)[] = ["display_name","visibility", "sorting", "filter"];
    // gridConfiguration.gridConfigData.forEach((object: any) => {
    //     visibleColumns.map((key: any) => {          
    //          (key!=="display_name")? object[key] = 'Yes': object[key]="";
    //     })
    // })

    useEffect(() => {
        setGridConfigData(gridConfiguration.gridConfigData);
    }, [gridConfigData])

    const handleReset = (form: FormikProps<WidgetConfig>) => {
        // setGridConfigData(Object.create(gridConfiguration.gridConfigData));
        form.resetForm();
        // setGridConfigData(gridConfiguration.gridConfigData);
        // console.log(gridConfigData,"gridConfigData");
    }

    const onChangeDropdown = (event: Event, tableMeta: any) => {
        if (gridConfigData) {
            gridConfigData[tableMeta.rowIndex][tableMeta.columnData.name] = event;
            setGridConfigData(gridConfigData)
        }
    }

    return (
        <div className="createWidgetStepTwo">
            <Formik initialValues={initialValues} validationSchema={makeSchema} onSubmit={handleSubmit} validateOnChange={false} enableReinitialize>
                {(form): JSX.Element => (
                    <form onSubmit={form.handleSubmit}>
                        {/* <FormikFormErrors form={form} maxDepth={1}/> */}
                        <ErrorMessage name={`confProperties.graphConfig.graphType`} />
                        <ErrorMessage name={`confProperties.gridConfig.columns[0].visibility`} />
                        <WidgetConfiguration />
                        <div className='hraccordions'>
                            <Accordion
                                style={{ backgroundColor: expanded === "panel1" ? "transparent" : "#f7f5f5" }}
                                expanded={form.values.confProperties.gridConfig.grid === true}
                            // expanded={expanded === "panel1" && form.values.ConfProperties.grid_config.grid === true}
                            // onChange={handleChange("panel1")}

                            >
                                <AccordionSummary sx={{ pointerEvents: "none" }}
                                    className='accordioncontainertitle'
                                    expandIcon={<ExpandMoreIcon sx={{ pointerEvents: "auto" }} />}
                                    aria-controls="panel1bh-content"
                                    id="panel1bh-header"
                                >
                                    <Typography className="accordion-header-title"
                                        variant="h5"
                                        sx={{ width: "33%", flexShrink: 0 }}
                                        style={{ marginRight: "30px" }}
                                    >
                                        {/* <FormikCheckBox id="grid" labelText="Grid" sx={{ pointerEvents: "auto" }} /> */}
                                        <div className="checkboxAccordion">
                                            <label style={{ pointerEvents: "auto" }} className="checkboxContainer">
                                                <Field className="checkbox" type="checkbox" name="confProperties.gridConfig.grid" />
                                                Grid
                                                <span className="checkmark"></span>
                                            </label>
                                        </div>
                                    </Typography>
                                </AccordionSummary>
                                <AccordionDetails className="accordianDetailSection">
                                    <Grid container spacing={3} className="gridSection">
                                        <Grid item xs={6}>
                                            {gridConfigData && <GridConfiguration gridConfigData={gridConfigData} onChangeDropdown={onChangeDropdown} />}
                                            {/* {gridConfigData && <GridConfiguration gridConfigData={initialValues.ConfProperties.grid_config.columns.length>0?initialValues.ConfProperties.grid_config.columns:gridConfigData} onChangeDropdown={onChangeDropdown} />} */}
                                        </Grid>
                                    </Grid>
                                </AccordionDetails>
                            </Accordion>

                            <Accordion
                                style={{ backgroundColor: expanded === "panel2" ? "transparent" : "#f7f5f5" }}
                                expanded={form.values.confProperties.graphConfig.graph === true}
                            // expanded={expanded === "panel2" && form.values.ConfProperties.graph_config.graph === true}
                            // onChange={handleChange("panel2")}
                            >
                                <AccordionSummary sx={{ pointerEvents: "none" }}
                                    className='accordioncontainertitle'
                                    expandIcon={<ExpandMoreIcon sx={{ pointerEvents: "auto" }} />}
                                    aria-controls="panel2bh-content"
                                    id="panel2bh-header"
                                >
                                    <Typography className="accordion-header-title"
                                        variant="h5"
                                        sx={{ width: "33%", flexShrink: 0 }}
                                        style={{ marginRight: "30px" }}
                                    >
                                        {/* <FormikCheckBox id="graph" labelText="Graph" sx={{ pointerEvents: "auto" }} /> */}
                                        <div className="checkboxAccordion">
                                            <label style={{ pointerEvents: "auto" }} className="checkboxContainer">
                                                <Field className="checkbox" type="checkbox" name="confProperties.graphConfig.graph" />
                                                Graph
                                                <span className="checkmark"></span>
                                            </label>
                                        </div>
                                    </Typography>
                                </AccordionSummary>
                                <AccordionDetails className="accordianDetailSection">
                                    <Grid container spacing={3} className="graphSection">
                                        <Grid item xs={12}>
                                            <GraphConfiguration form={form as unknown as FormikProps<GraphConfig>} />
                                        </Grid>
                                    </Grid>
                                </AccordionDetails>
                            </Accordion>
                        </div>
                        <div style={{ float: "right" }}>
                            <Buttons buttonList={
                                [
                                    {
                                        variant: buttonVariants.contained,
                                        label: "Back",
                                        toolTipLabel: "Back",
                                        type: "Back",
                                        handleOnBtnClick: handleOnBackStep,
                                        buttonType: buttonTypeVariants.button,
                                        btnColor: btnColorType.inherit,
                                        btnclassName: classes.queryListbtn,
                                        btnSize: btnSizeType.medium,
                                    },
                                    {
                                        variant: buttonVariants.contained,
                                        label: "Reset",
                                        toolTipLabel: "Reset",
                                        type: "reset",
                                        buttonType: buttonTypeVariants.button,
                                        handleOnBtnClick: () => handleReset(form),
                                        // handleOnBtnClick: () =>form.resetForm(),
                                        btnColor: btnColorType.inherit,
                                        btnclassName: classes.btn1,
                                        btnSize: btnSizeType.medium
                                    },
                                    {
                                        variant: buttonVariants.contained,
                                        label: "Save & Next",
                                        toolTipLabel: "Confirm Selection",
                                        type: "submit",
                                        buttonType: buttonTypeVariants.button,
                                        handleOnBtnClick: () => handleSubmit(form.values),
                                        btnColor: btnColorType.primary,
                                        btnclassName: classes.btn1,
                                        btnSize: btnSizeType.medium
                                    },
                                ]
                            } />
                        </div>
                    </form >
                )}
            </Formik >

        </div >
    )
}
