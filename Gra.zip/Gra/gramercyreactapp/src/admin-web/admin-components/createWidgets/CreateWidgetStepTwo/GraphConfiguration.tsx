import { Grid } from "@mui/material"
import { FastField, Field, FormikProps } from "formik"
import { useMemo } from "react"
import { FieldFormik } from '../../../../shared-web/formik/FormikBase';
import { FormikDropdown } from "../../../../shared-web/formik/FormikDropdown"
import { GraphConfig } from "./CreateWidgetStepTwo";

interface Properties {
    form: FormikProps<GraphConfig>;
 }

export const GraphConfiguration: React.FC<Properties> = ({ form }) => {
    const graphTypeList = [
        { id: "Line Chart", text: "Line Chart" },
        { id: "Bar Chart", text: "Bar Chart" },
        { id: "Pie Chart", text: "Pie Chart" }
    ]

    const cloumnList = [
        { id: "Daily AUM ", text: "Daily AUM " },
        { id: "Daily Performance", text: "Daily Performance" },
        { id: "AUM Progress", text: "AUM Progress" }
    ]

    const columns = useMemo(() => cloumnList.map(item => ({ id: item.id, text: item.text })), []);
    const graphType = useMemo(() => graphTypeList.map(item => ({ id: item.id, text: item.text })), []);

    const handleClick=(form: FormikProps<GraphConfig>)=>{
        // form.resetForm();      
    }

    return (
        <>
            <FastField>
                {(fieldFormik: FieldFormik<any>): JSX.Element => (
                    <div className="backgroundColor">
                        <h3 className="configureTitle">Configure graph features:</h3>

                        <Grid container spacing={3} rowSpacing={6}>
                            <Grid item xs={6}>
                                <FormikDropdown id="confProperties.graphConfig.graphType" placeholder="Select Graph Type" menuPlacement="top" className="fieldspacing dropdownField" aria-selected="true" options={graphType} />
                            </Grid>
                            <Grid item xs={6}>
                                <FormikDropdown id="confProperties.graphConfig.xAxis" placeholder="Select X-axis" menuPlacement="top" className="fieldspacing dropdownField" aria-selected="true" options={columns} />
                            </Grid>

                            <Grid item xs={6} className="checkboxField">                              
                               {/* <span className="exportImgCheckbox"><FormikCheckBox id="exportToImage" labelText="Export to image"/></span>  */}
                                {/* <FormikCheckBox id="graphPrint" labelText="Print" /> */}
                                    <label className="exportImgCheckbox checkboxContainer">
                                        <Field className="checkbox" type="checkbox" name="confProperties.graphConfig.exportToImage" onClick={!fieldFormik.field.value.confProperties.graphConfig.graph ? handleClick(form):undefined} />
                                        Export to image
                                        <span className="checkmark"></span>
                                    </label>
                                    <label className="checkboxContainer">
                                        <Field className="checkbox" type="checkbox" name="confProperties.graphConfig.print" />
                                        Print
                                        <span className="checkmark"></span>
                                    </label>
                            </Grid>

                            <Grid item xs={6}>
                                <FormikDropdown id="confProperties.graphConfig.yAxis" placeholder="Select Y-axis" menuPlacement="top" className="fieldspacing dropdownField" aria-selected="true" options={columns} />
                            </Grid>
                        </Grid>                     
                    </div>
                )}
            </FastField>
           
        </>
    )
}