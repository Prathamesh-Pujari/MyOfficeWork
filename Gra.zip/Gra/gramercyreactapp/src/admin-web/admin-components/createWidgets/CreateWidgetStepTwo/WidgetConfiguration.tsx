import { Grid, TextField } from "@mui/material"
import { FastField } from "formik";
import { useMemo } from "react";
import { FieldFormik } from "../../../../shared-web/formik/FormikBase";
import { FormikDropdown } from "../../../../shared-web/formik/FormikDropdown"
import "../CreateWidget.scss";


export const WidgetConfiguration: React.FC = () => {

    const dropdownlist = [
        { id: "Super Admin", text: "Super Admin" },
        { id: "Admin", text: "Admin" },
        { id: "User", text: "User" }
    ]

    const option = useMemo(() => dropdownlist.map(item => ({ id: item.id, text: item.text })), []);

    return (
        <>
            <FastField>
                {(fieldFormik: FieldFormik<string>): JSX.Element => (
                    <div className="widgetTitleSection">                        
                        <Grid container spacing={3}>
                            <Grid item xs={6}>
                                <TextField
                                    id="widgetName"
                                    name="widgetName"                                   
                                    onChange={fieldFormik.field.onChange}
                                    label="Widget Title"
                                    className="fieldspacing w-100"
                                    size="small"
                                    sx={{ mt: "10px" }}
                                />
                            </Grid>
                            <Grid item xs={6}>
                                <FormikDropdown id="accessGroups" placeholder="Select Access Groups" className="fieldspacing dropdownField" aria-selected="true" options={option} />
                            </Grid>
                            <Grid item xs={6}>
                                <TextField
                                    id="tags"
                                    name="tags"
                                    onChange={fieldFormik.field.onChange}
                                    label="Add Search Tags"
                                    className="fieldspacing w-100"
                                    size="small"
                                    sx={{ mt: "10px" }}
                                />
                            </Grid>
                        </Grid>
                    </div>
                )}
            </FastField>
        </>
    )
}
