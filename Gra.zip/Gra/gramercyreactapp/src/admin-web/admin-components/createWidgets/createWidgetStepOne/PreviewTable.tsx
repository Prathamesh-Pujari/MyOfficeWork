import Grid from "@mui/material/Grid";
import React, { PropsWithChildren } from "react"
import { Buttons } from "../../../../shared-web/buttons/Buttons";
import { btnColorType, btnSizeType, buttonTypeVariants, buttonVariants } from "../../../../shared-web/enums/Buttons";
import { MuiDataTable } from "../../../../shared-web/basicTable/DataTable";
import { useStyles } from "../../../../shared-web/buttons/ButtonStyles";
import TextField from "@mui/material/TextField";
import "../CreateWidget.scss";

interface Properties {
    tableColumns: string[];
    tableData: string[];
}
export const PreviewTable: React.FC<Properties> = (props) => {
    const classes = useStyles();
    return (
        <div className="previewTableMain">
            <Grid container spacing={2}>
                <Grid item xs={8} className="tablePreviewCountMain">
                    <p className="fontWeight600 fontSize17">Preview:</p>
                </Grid>
                <Grid item xs={2} direction="row-reverse">
                    <p>Columns #:<span className="tableCount fontWeight600">{props.tableColumns.length}</span></p>
                </Grid>
                <Grid item xs={2} direction="row-reverse" sx={{ justifyContent: 'flex-end' }}>
                    <p>Records #:<span className="tableCount fontWeight600">{props.tableData.length}</span></p>
                </Grid>
            </Grid>
            <MuiDataTable
                id={'lineDataTable'}
                className={'previewinnerTable'}
                title={''}
                tableType={'mui'}
                titleFontSize={24}
                titleColor={""}
                tableData={props.tableData}
                tableColumn={props.tableColumns}
                tableOptions={{
                    print: false,
                    pagination: false,
                    filter: false,
                    sort: false,
                    search: false,
                    download: false,
                    viewColumns: false,
                    selectableRowsHideCheckboxes: true,
                }}
            />

        </div>
    );


}

