
import React, { useCallback, useContext, useMemo, useRef, useState } from "react";

import TextareaAutosize from "@mui/material/TextareaAutosize";
import TextField from "@mui/material/TextField";
import { btnColorType, btnSizeType, buttonTypeVariants, buttonVariants } from "../../../../shared-web/enums/Buttons";
import { Buttons } from "../../../../shared-web/buttons/Buttons";
import { useStyles } from "../../../../shared-web/buttons/ButtonStyles";
import { FastField, Formik } from "formik";
import { FormikDropdown } from "../../../../shared-web/formik/FormikDropdown";
import Grid from "@mui/material/Grid";
import "../CreateWidget.scss";
import { PreviewTable } from "./PreviewTable";
import { useEffect } from "react";
import { aumData } from "../../../../portal-web/services/dashboardServices";
import { FormikFormErrors } from "../../../../shared-web/formik/FormikFormErrors";
import * as Yup from 'yup';
import { FieldFormik } from "../../../../shared-web/formik/FormikBase";
import Divider from "@mui/material/Divider";
import { creatWidgets, getWidgets, qetQueryData } from "../../../services/widgetService";
import { StepperProviderContext } from "../../../../shared-web/stepper/StepperContextProvider";
import axios from "axios";
import { AddBoxOutlined } from "@material-ui/icons";
import { useAsyncCall } from "../../../../shared-web/hooks/useAsyncCall";
import { GenericOption } from "../../../../shared-web/models/GenericOption";
import { createWidgetStepOne, GetQuery } from "../../../../shared-web/models/WidgetModels";

const initialValues: createWidgetStepOne = {
    widgetSourceQueryName: "",
    widgetSourceQuery: "",
    status: "",
    createdBy: ""
}
const makeSchema = Yup.object<createWidgetStepOne>().shape({
    // TODO add interface 
    // widgetSourceQueryName: Yup.string().required("Please select query name"),
    widgetSourceQuery: Yup.string().required("Please  enter query"),
    widgetName: Yup.string().trim().required('Enter query name is required')
})


export const CreateWidgetStepOne: React.FC = () => {
    const { handleOnNextStep } = useContext(
        StepperProviderContext
    );

    const classes = useStyles();
    const inputRef = useRef<any>();
    const [widgetDetailsResponse, setWidgetDetailsResponse] = useState<any>();
    const [selectedQueryData, setSelectedQueryData] = useState();
    const [selectedQueryColumns, setSelectedQueryColumns] = useState();
    const [defaultQuery, setDefaultQuery] = useState<string>();

    const loader = useAsyncCall(async () => {
        return await getWidgets()
    }, []);

    const widgetDetailsData: any = useMemo(() => (loader.completed ? loader.result : undefined), [loader]);

    useEffect(() => {
        // const querydata = JSON.stringify(initialValues.inputRef);
        // setDefaultQuery(querydata);
    }, []);

    const option = widgetDetailsData?.map((item: any) => ({ id: item.widgetSourceDetailId, text: item.widgetSourceQueryName })) ?? [];

    const handleRunQuery = async (values: GetQuery) => {
        try {
            const tableData = await qetQueryData(values);
            if (tableData) {
                setSelectedQueryColumns(tableData.columns);
                setSelectedQueryData(tableData.data);
            }
        } catch (err) {
            const error = err as any;
        }

    }

    const handleSubmit = useCallback(async (formValues: createWidgetStepOne) => {
        try {
            const res = creatWidgets(formValues);
            handleOnNextStep();
        } catch (err) {
            const error = err as any;
        } finally {
        }
    }, [])

    const onChangeDropdown = (event: any) => {
        widgetDetailsData.map((item: any) => {
            if (item.widgetSourceDetailId === event) {
                setDefaultQuery(item.widgetSourceQuery)
            }
        })

    };

    return (
        <div>
            {loader.loading ? (
                // <LoadingScreen show={true} />
                <div>loader...</div>
            ) : (
                <div className="createWidgetStepOne formStepWidth">
                    <Formik initialValues={initialValues} validationSchema={makeSchema} onSubmit={handleSubmit} validateOnChange={false} enableReinitialize>
                        {(form): JSX.Element => (
                            <form onSubmit={form.handleSubmit}>
                                <FormikFormErrors form={form} />
                                <Grid container spacing={3}>
                                    <Grid item xs={6} className="blockOne">
                                        <FormikDropdown id="widgetSourceQueryName" className="fieldspacing" aria-selected="true" options={option} onChange={onChangeDropdown} />
                                        <Divider className="fontWeight600" sx={{ pb: 2, pt: 1 }}>OR</Divider>
                                        <TextareaAutosize
                                            id="widgetSourceQuery"
                                            name="widgetSourceQuery"
                                            defaultValue={defaultQuery}
                                            ref={inputRef}
                                            minRows={15}
                                            placeholder="Enter Query"
                                            className="fieldspacing w-100"
                                            autoFocus={true}
                                            required={true}
                                        />

                                        <Buttons buttonList={
                                            [
                                                {
                                                    variant: buttonVariants.contained,
                                                    label: "Run SQL",
                                                    toolTipLabel: "Run SQL",
                                                    buttonType: buttonTypeVariants.button,
                                                    handleOnBtnClick: () => handleRunQuery(inputRef.current.value),
                                                    btnColor: btnColorType.primary,
                                                    btnclassName: classes.queryListbtn,
                                                    btnSize: btnSizeType.medium
                                                }
                                            ]
                                        } />
                                    </Grid>
                                    {selectedQueryData && selectedQueryColumns && <Grid item xs={6} spacing={3} className="blockTwo">

                                        <PreviewTable tableColumns={selectedQueryColumns} tableData={selectedQueryData} />

                                        <FastField>
                                            {(fieldFormik: FieldFormik<string>): JSX.Element => (
                                                <TextField
                                                    id="widgetSourceQueryName"
                                                    name="widgetSourceQueryName"
                                                    onChange={fieldFormik.field.onChange}
                                                    label="Enter Query Name"
                                                    className="fieldspacing w-100"
                                                    size="small"
                                                    sx={{ mt: "10px" }}
                                                />
                                            )}
                                        </FastField>

                                        <Buttons buttonList={
                                            [

                                                {
                                                    variant: buttonVariants.contained,
                                                    label: "Reset",
                                                    toolTipLabel: "Reset",
                                                    type: "reset",
                                                    buttonType: buttonTypeVariants.button,
                                                    handleOnBtnClick: e => form.resetForm(),
                                                    btnColor: btnColorType.inherit,
                                                    btnclassName: classes.btn1,
                                                    btnSize: btnSizeType.medium
                                                },
                                                {
                                                    variant: buttonVariants.contained,
                                                    label: "Save & Next",
                                                    toolTipLabel: "Save & Next",
                                                    type: "submit",
                                                    handleOnBtnClick: () => handleSubmit(form.values),
                                                    buttonType: buttonTypeVariants.button,
                                                    btnColor: btnColorType.primary,
                                                    btnclassName: classes.queryListbtn,
                                                    btnSize: btnSizeType.medium
                                                },
                                            ]
                                        } />

                                    </Grid>}

                                </Grid>
                            </form>
                        )}
                    </Formik>
                </div>
            )}
        </div>

    );
}
