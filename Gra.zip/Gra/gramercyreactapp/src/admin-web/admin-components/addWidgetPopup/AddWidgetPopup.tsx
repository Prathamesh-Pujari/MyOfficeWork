import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import { PopUp } from "../../../shared-web/popUp/PopUp";
import Grid from "@mui/material/Grid";
import Paper from "@mui/material/Paper";
import { styled } from "@mui/material/styles";
import "./AddWidgetPopup.scss";
import BackupTableIcon from "@mui/icons-material/BackupTable";
import AssignmentIcon from "@mui/icons-material/Assignment";
import { useNavigate } from "react-router-dom";

interface Properties {
  userName?: string;
  onClose: () => void;
}

const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === "dark" ? "#1A2027" : "#fff",
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: "center",
  color: theme.palette.text.secondary,
}));

const PopUpitems = [
  {
    icon: <BackupTableIcon fontSize="large" />,
    itemName: "Grid & Graph",
    id: "GridGraph",
  },

  {
    icon: <AssignmentIcon fontSize="large" />,
    itemName: "Report",
    id: "Report",
  },
];

const AddWidgetPopup: React.FC<Properties> = (props) => {
  const navigate = useNavigate();

  const navigateToWidgetBuilder = (event: any) => {
    navigate("./widgetBuilder", {
      state: event.target.parentElement.textContent,
    });
  };

  return (
    <PopUp
      className="popup-add-widget"
      onClose={props.onClose}
      width="40%"
      height="25%"
      header={"Select type of widget"}
    >
      <Grid className="widget-types" container spacing={5} columns={12}>
        {PopUpitems.map((item, index) => {
          return (
            <Grid item xs={4} key={index} className={item.id}>
              <Button className="widget" onClick={navigateToWidgetBuilder}>
                <div className="GridViewIcon">{item.icon}</div>
                <div className="GridViewIconDescription">{item.itemName}</div>
              </Button>
            </Grid>
          );
        })}
      </Grid>
    </PopUp>
  );
};

export default AddWidgetPopup;
