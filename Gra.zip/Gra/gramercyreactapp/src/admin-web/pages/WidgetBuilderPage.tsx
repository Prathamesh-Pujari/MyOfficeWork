import Steppers from "../../shared-web/stepper/Steppers";
import "./WidgetBuilder.scss";
import { useLocation } from "react-router-dom";
import { CreateWidgetStepOne } from "../admin-components/createWidgets/createWidgetStepOne/CreateWidgetStepOne";
import { CreateWidgetStepTwo } from "../admin-components/createWidgets/CreateWidgetStepTwo/CreateWidgetStepTwo";
import { Grid } from "@mui/material";
import { useActiveSteps } from "../../shared-web/hooks/useActiveSteps";
import { useState } from "react";
import { StepperProvider } from "../../shared-web/stepper/StepperContextProvider";


const WidgetBuilderPage: React.FC = () => {
  const { state } = useLocation();
  const { currentStep } = useActiveSteps();
  let steps: string[] = [];
  let content: React.ReactNode;

  const gridGraphSteps = [
    "Step 1: Select Data",
    "Step 2: Configure Widget",
    "Step 3: Review & Publish",
  ];

  const reportSteps = ["Step 1: Select Data", "Step 2: Review & Publish"];

  const [activeStep, setActiveStep] = useState(0);

  const handleOnNextStep = () => {
    setActiveStep(activeStep + 1);
  };

  const handleOnBackStep = () => {
    setActiveStep(activeStep - 1);
  };
  const deafultStepperValue = {
    activeStep,
    handleOnNextStep,
    handleOnBackStep,
  };

  const gridGraphContent = (step: number) => {
    switch (step) {
      case 0:
        return (
          <CreateWidgetStepOne />
        );
      case 1:
        return (<CreateWidgetStepTwo
        />
        );
      case 2:
        return <CreateWidgetStepOne
        />;
    }
  }


  const reportContent = (step: number) => {
    switch (step) {
      case 0:
        return "Step 1 form";
      case 1:
        return "Step 2 form";
    }
  }

  if (state === "Grid & Graph") {
    steps = gridGraphSteps;
    content = gridGraphContent;
  } else if (state === "Report") {
    steps = reportSteps;
    content = reportContent;
  }

  return (
    <div className="widgetBuilderMain">
      <StepperProvider value={deafultStepperValue}>
        <Steppers selectedSteps={steps} stepsContent={content} />
      </StepperProvider>
    </div>
  );
};

export default WidgetBuilderPage;
