import { Box, Grid, TextField, useTheme } from "@mui/material";
import { useState } from "react";
import { filterResultDataSet } from "../../portal-web/app-components/rightSidebar/rightSidebarTabs/WidgetsTab";
import MainCard from "../../portal-web/app-components/cards/MainCard";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import { gridSpacing } from "../../shared-web/constant/theme-constant";
import "./AdminDashboard.scss";
import AddIcon from "@mui/icons-material/Add";
import { usePopup } from "../../shared-web/popUp/usePopup";
import AddWidgetPopup from "../admin-components/addWidgetPopup/AddWidgetPopup";

const AdminDashboardPage: React.FC = () => {
  const [addUserVisible, showAddUserPopUp, hideAddUserPopUp] = usePopup();
  const [query, setQuery] = useState("");
  const theme: any = useTheme();

  return (
    <>
      <Grid
        container
        direction="row"
        alignItems="center"
        justifyContent="between"
        columns={15}
        className="AdminTitleContainer"
      >
        <Grid item md={13}>
          <h2>Widget Builder</h2>
        </Grid>
        <Grid item md={2} sx={{ textAlign: "right" }}>
          <TextField
            size="small"
            label="Search"
            className="searchField"
            onChange={(event) => setQuery(event.target.value)}
          />
        </Grid>
      </Grid>

      <Grid
        container
        spacing={gridSpacing}
        direction="row"
        justifyContent="between"
        alignItems="center"
        style={{ width: "100vw!important" }}
        columns={15}
      >
        <Grid
          item
          xs={3}
          className="AddWidgetCard"
          direction="column"
          justifyContent="center"
          alignItems="center"
        >
          <MainCard
            content={true}
            border={false}
            elevation={16}
            boxShadow
            shadow={theme.shadows[16]}
            sx={{
              display: "flex",
              justifyContent: "space-between",
              flexDirection: "column",
              height: "180px",
            }}
            contentSX={{
              display: "flex",
              justifyContent: "center",
              flexDirection: "column",
              alignItems: "center",
              height: "100%",
              backgroundColor: "rgb(194, 194, 194)",
            }}
          >
            <Box
              sx={{ width: "100%", display: 'flex', justifyContent: 'center', alignItems: 'center' }}
              onClick={showAddUserPopUp}
            >
              <AddIcon
                sx={{ fontSize: "50px" }}
                className="AddWidgetIconColor"
              />
            </Box>
            {addUserVisible && <AddWidgetPopup onClose={hideAddUserPopUp} />}
          </MainCard>
        </Grid>

        {filterResultDataSet
          .filter((item) => {
            if (query === "") {
              return item;
            } else if (
              item.chartName.toLowerCase().includes(query.toLowerCase())
            ) {
              return item;
            }
          })
          .map((item, index) => (
            <Grid
              item
              xs={3}
              direction="column"
              justifyContent="center"
              alignItems="center"
              key={index}
            >
              <MainCard
                title={[
                  <EditIcon sx={{ fontSize: "large" }} />,
                  <DeleteIcon sx={{ fontSize: "large" }} />,
                ]}
                content={true}
                border={false}
                elevation={16}
                boxShadow
                shadow={theme.shadows[16]}
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  flexDirection: "column",
                  height: "180px",
                }}
                contentSX={{
                  display: "flex",
                  justifyContent: "center",
                  flexDirection: "column",
                  alignItems: "center",
                  height: "100%",
                }}
              >
                <p>{item.chartName}</p>
              </MainCard>
            </Grid>
          ))}
      </Grid>
    </>
  );
};

export default AdminDashboardPage;
