
export const gridConfiguration: any = {
    gridConfigData: [
        {
            "columnName": "Alternatives"

        },
        {
            "columnName": "Capital Solutions"
        },
        {

            "columnName": "EMD Long-Only"
        },
        {
            "columnName": "Multi Asset"
        },
        {
            "columnName": "Special Situations"
        }
    ]
}
export interface GridConfigColumns {
    columnName: string;
    displayName: string;
    visibility: string;
    sorting: string;
    filter: string
}