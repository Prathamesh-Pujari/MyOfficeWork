import { apiGet, apiPost } from "../../shared-web/baseServices/BaseService";
import { createWidgetStepOne, GetQuery } from "../../shared-web/models/WidgetModels";
import { WidgetConfig } from "../admin-components/createWidgets/CreateWidgetStepTwo/CreateWidgetStepTwo";

export const getWidgets = (): Promise<void> => {
    return apiGet(`/widgets/getQueryDetails`);
};

export const qetQueryData = (values: any): Promise<any> => {
    const data: GetQuery = {
        query: values
    }
    return apiPost('/widgets/runQuery', data)
};


export const creatWidgets = (values: createWidgetStepOne): Promise<createWidgetStepOne> => {
    const data: createWidgetStepOne = {
        widgetSourceQueryName: values.widgetSourceQueryName,
        widgetSourceQuery: "select * from tableName",
        status: "Draft",
        createdBy: "Admin"
    }
    return apiPost("/widgets/saveGridGraphData", data);
}

export const saveGridGraphConfiguration = (widgetId: string, widgetConfig: WidgetConfig): Promise<void> => {
    const data: WidgetConfig = {
        widgetId: widgetId,
        widgetType: widgetConfig.widgetType,
        widgetName: widgetConfig.widgetName,
        tags: widgetConfig.tags,
        accessGroups: widgetConfig.accessGroups,
        confProperties: {
            gridConfig: {
                columns: widgetConfig.confProperties?.gridConfig.columns,
                print: widgetConfig.confProperties?.gridConfig.print,
                excelExport: widgetConfig.confProperties?.gridConfig.excelExport,

            },
            graphConfig: {
                graphType: widgetConfig.confProperties?.graphConfig.graphType,
                xAxis: widgetConfig.confProperties?.graphConfig.xAxis,
                yAxis: widgetConfig.confProperties?.graphConfig.yAxis,
                exportToImage: widgetConfig.confProperties?.graphConfig.exportToImage,
                print: widgetConfig.confProperties?.graphConfig.print,

            },
        }
    };
    return apiPost(`/widgets/saveGridGraphConfiguration`, data);
};