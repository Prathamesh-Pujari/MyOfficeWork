/**
 * Dashboard types
 */

import { ComponentClass } from "react";
import { Layout } from "react-grid-layout";

export interface DashboardState {
    // layoutsDataTwo: any;
    layoutsData: { [string: string]: Layout[] };
    currentBreakPoint: string;
    gridLayoutDisplay: any[];
    updatedDragWidgetSiderbar: any;
    updateDashoboardGridLayout: any;
}

export interface DashboardComponentState {
    showChart?: boolean;
    showGridLayout?: boolean;
}
export interface DashboardActions {
    updateLayout(layout: Array<Layout>): void;
    updateBreakpoint(breakpoint: string): void;
    updateGridLayout(item: any): void;
    updatedDragWidgetSiderbar(item: any): void;
    updateDashoboardGridLayout(item: any): void;
}

export interface DashboardActionData {

}

export interface DashboardProps extends DashboardState {
    actions: DashboardActions;
    sideMenuStatus: boolean;
}

export interface DashboardActionSetDataPayload {

}

export interface DashboardActionResetDataPayload {

}