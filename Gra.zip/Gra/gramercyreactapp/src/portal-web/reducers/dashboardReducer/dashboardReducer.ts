/**
 * Dashboard reducer changes
 */

import { handleActions, Action } from "redux-actions";

import {
  DashboardState
} from './types';
import * as DashboardActions from "./dashboardActions";
import { gridLayoutDisplay, layoutsData } from '../../services/dashboardServices';

const dashboardInitialState: DashboardState = {
  layoutsData: layoutsData,
  currentBreakPoint: 'lg',
  updateDashoboardGridLayout: 2,
  updatedDragWidgetSiderbar: gridLayoutDisplay,
  gridLayoutDisplay: gridLayoutDisplay
};

const localStorageState = localStorage.getItem("updateLayout");

const initialState = localStorageState != undefined && localStorageState != null ? JSON.parse(localStorageState) : dashboardInitialState;

if (localStorageState != undefined && localStorageState != null) {
  localStorage.setItem("updateLayout", JSON.stringify(dashboardInitialState));
}

export const dashboardReducer = handleActions<DashboardState, any>(
  {
    [DashboardActions.Type.UPDATE_LAYOUT]: (
      state,
      action
    ) => {
      localStorage.setItem("updateLayout", JSON.stringify({
        ...state,
        layoutsData: {
          ...state.layoutsData,
          [state.currentBreakPoint]: action.payload
        }
      }));
      return {
        ...state,
        layoutsData: {
          ...state.layoutsData,
          [state.currentBreakPoint]: action.payload
        }
      };
    },

    [DashboardActions.Type.UPDATE_BREAKPOINT]: (
      state,
      action
    ) => {
      localStorage.setItem("updateLayout", JSON.stringify({
        ...state,
        currentBreakPoint: action.payload
      }));
      return {
        ...state,
        currentBreakPoint: action.payload
      };
    },

    [DashboardActions.Type.UPDATE_GRID_LAYOUT]: (
      state,
      action
    ) => {
      localStorage.setItem("updateLayout", JSON.stringify({
        ...state,
        gridLayoutDisplay: action.payload
      }));
      return {
        ...state,
        gridLayoutDisplay: action.payload
      };
    },

    [DashboardActions.Type.UPDATE_DRAG_WIDGET_SIDEBAR]: (
      state,
      action
    ) => {
      localStorage.setItem("updateLayout", JSON.stringify({
        ...state,
        updatedDragWidgetSiderbar: action.payload
      }));
      return {
        ...state,
        updatedDragWidgetSiderbar: action.payload
      };
    },

    [DashboardActions.Type.SET_DASHBOARD_GRID_LAYOUT]: (
      state,
      action
    ) => {
      localStorage.setItem("updateLayout", JSON.stringify({
        ...state,
        layoutsData: {
          ...state.layoutsData
        },
        updateDashoboardGridLayout: action.payload
      }));
      return {
        ...state,
        layoutsData: { ...state.layoutsData },
        updateDashoboardGridLayout: action.payload
      };
    }
  },
  initialState
);