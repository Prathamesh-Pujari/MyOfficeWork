import { createSelector } from 'reselect'
import { RootState } from '../../../shared-web/reducers/ReducerMain';
// selector
const getData = (state: RootState) => state.dashboard
// reselect function
export const getDahboardState = createSelector(
  [getData],
  (data) => {
    // localStorage.setItem("updateLayout", JSON.stringify(data));
    return data
  }
)