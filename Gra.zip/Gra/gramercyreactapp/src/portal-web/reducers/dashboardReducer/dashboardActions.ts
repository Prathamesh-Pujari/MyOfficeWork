/**
 * Dashboard Actions
 */

import { createAction } from "redux-actions";


export const Type = {
  UPDATE_LAYOUT: "UPDATE_LAYOUT",
  UPDATE_BREAKPOINT: "UPDATE_BREAKPOINT",
  UPDATE_GRID_LAYOUT: "UPDATE_GRID_LAYOUT",
  UPDATE_DRAG_WIDGET_SIDEBAR: "UPDATE_DRAG_WIDGET_SIDEBAR",
  SET_DASHBOARD_GRID_LAYOUT: "SET_DASHBOARD_GRID_LAYOUT"
};


export const updateLayout = createAction(
  Type.UPDATE_LAYOUT
);
export const updateBreakpoint = createAction(
  Type.UPDATE_BREAKPOINT
);
export const updateGridLayout = createAction(
  Type.UPDATE_GRID_LAYOUT
);
export const updatedDragWidgetSiderbar = createAction(
  Type.UPDATE_DRAG_WIDGET_SIDEBAR
);
export const updateDashoboardGridLayout = createAction(
  Type.SET_DASHBOARD_GRID_LAYOUT
);