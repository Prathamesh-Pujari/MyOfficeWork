/**
 * Analytics related reducer state
 */

import { handleActions } from 'redux-actions';

import {
    HrState
} from './hrTypes';
import * as HrActions from './hrAction';


const initialState = {
    showChart: true
};
export const hrReducer = handleActions<HrState, any>(
    {
        [HrActions.Type.RELOAD_HR_DATA]: (
            state,
            action
        ) => {
            return {
                ...state
            };
        }
    },
    initialState
);