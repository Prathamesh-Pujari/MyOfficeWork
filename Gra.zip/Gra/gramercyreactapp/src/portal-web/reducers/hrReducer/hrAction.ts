/**
 * Analytics related actions
 */

import { createAction } from "redux-actions";


export const Type = {
    RELOAD_HR_DATA: "RELOAD_HR_DATA"
};


export const reloadHrData = createAction(
    Type.RELOAD_HR_DATA
);