/**
 * Hr related types
 */

export interface HrState {

}

export interface HrProps extends HrState {

}

export interface HrComponentState {
    expanded:string|boolean
}