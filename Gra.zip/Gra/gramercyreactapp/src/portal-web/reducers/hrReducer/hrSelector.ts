/**
 * Analytics related selector
 */

import { createSelector } from 'reselect'
import { RootState } from '../../../shared-web/reducers/ReducerMain';
// selector
const getData = (state: RootState) => state.hr
// reselect function
export const getHrState = createSelector(
    [getData],
    (data) => data
)