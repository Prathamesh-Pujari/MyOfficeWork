/**
 * Analytics related selector
 */

import { createSelector } from 'reselect'
import { RootState } from '../../../shared-web/reducers/ReducerMain';
// selector
const getData = (state: RootState) => state.analytics
// reselect function
export const getAnalyticsState = createSelector(
    [getData],
    (data) => data
)