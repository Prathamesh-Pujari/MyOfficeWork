/**
 * Analytics related types
 */

export interface AnalyticsState {

}

export interface AnalyticsProps extends AnalyticsState {

}

export interface AnalyticsComponentState {

}