/**
 * Analytics related actions
 */

import { createAction } from "redux-actions";


export const Type = {
    RELOAD_DATA: "RELOAD_DATA"
};


export const reloadData = createAction(
    Type.RELOAD_DATA
);