/**
 * Analytics related reducer state
 */

import { handleActions } from 'redux-actions';

import {
    AnalyticsState
} from './EmuTypes';
import * as AnalyticsActions from './EmuAction';


const initialState = {
    showChart: true
};
export const analyticsReducer = handleActions<AnalyticsState, any>(
    {
        [AnalyticsActions.Type.RELOAD_DATA]: (
            state,
            action
        ) => {
            return {
                ...state
            };
        }
    },
    initialState
);