/**
 * Analytics Container
 */

import React from "react";
import { connect } from "react-redux";
import { bindActionCreators, Dispatch } from "redux";
import { RootState } from "../../../shared-web/reducers/ReducerMain";
import {
  AnalyticsComponentState,
  AnalyticsProps,
} from "../../reducers/emuReducer/EmuTypes";
import * as analyticsActions from "../../reducers/emuReducer/EmuAction";
import { getAnalyticsState } from "../../reducers/emuReducer/EmuSelector";

import "./EmuDetails.scss";
import TabsData from "./TabsData";
interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}
class EmuDetailsPage extends React.Component<
  AnalyticsProps,
  AnalyticsComponentState
> {

  render() {
    return (
      <TabsData />
    );
  }
}

function mapStateToProps(state: RootState) {
  return {
    ...getAnalyticsState(state),
  };
}
function mapDispatchToProps(dispatch: Dispatch) {
  return {
    actions: bindActionCreators(
      Object.assign({}, analyticsActions) as any,
      dispatch
    ),
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(EmuDetailsPage);
