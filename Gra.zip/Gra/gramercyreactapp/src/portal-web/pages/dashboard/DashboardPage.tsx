/**
 * App Dashboard 
 */
import React from "react";
import { connect } from "react-redux";
import { bindActionCreators, Dispatch } from "redux";
import { Layout } from "react-grid-layout";
import { Grid } from '@mui/material';

// Project imports
import { RootState } from "../../../shared-web/reducers/ReducerMain";
import * as dashboardActions from "../../reducers/dashboardReducer/dashboardActions";
import { DashboardProps, DashboardComponentState } from '../../reducers/dashboardReducer/types';
import { getDahboardState } from '../../reducers/dashboardReducer/dashboardSelector';
import './dashboardStyles.scss';
import GridWidget from "../../app-components/dashboard/GridWidget";
import { gridSpacing } from "../../../shared-web/constant/theme-constant";
// third-party
// material-ui
import { getSideMenuOpenStatus } from "../../../shared-web/reducers/layoutReducer/layoutSelector";

class DashboardPage extends React.Component<DashboardProps, DashboardComponentState> {
  constructor(props: DashboardProps) {
    super(props);
    this.state = {
      showChart: true,
      showGridLayout: true,

    };
    this.changeAUMMap = this.changeAUMMap.bind(this);
  }

  public render() {
    let savedLayouts: { [breakpoint: string]: Layout[] } = {};
    if (typeof window !== "undefined") {
      const hasSavedLayouts =
        window.localStorage && window.localStorage.getItem("gridLayoutConfig");
      savedLayouts = hasSavedLayouts ? JSON.parse(hasSavedLayouts) : {};
    }

    return (
      <Grid container className="dashboardDragMain" spacing={gridSpacing}>
        <Grid item xs={12}>


          <Grid className="customDragwidget" item lg={12} md={12} sm={12} xs={12}>
            <GridWidget
              data={this.props.gridLayoutDisplay}
              layouts={this.props.layoutsData}
              updateLayout={this.props.actions.updateLayout}
              updateBreakpoint={this.props.actions.updateBreakpoint}
              sideMenuStatus={this.props.sideMenuStatus}
              updateGridLayout={this.props.actions.updateGridLayout}
              updatedDragWidgetSiderbar={this.props.actions.updatedDragWidgetSiderbar}
              updateDashoboardGridLayout={this.props.updateDashoboardGridLayout}

            />
          </Grid>
        </Grid>
      </Grid>
    );
  }

  changeAUMMap() {
    this.setState({ showChart: !this.state.showChart });
  }
}

function mapStateToProps(state: RootState) {
  return {
    ...getDahboardState(state),
    sideMenuStatus: getSideMenuOpenStatus(state)
  };
}
function mapDispatchToProps(dispatch: Dispatch) {
  return {
    actions: bindActionCreators(Object.assign({}, dashboardActions) as any, dispatch)
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(DashboardPage);