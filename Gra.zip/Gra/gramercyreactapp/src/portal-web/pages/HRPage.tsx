/**
 * Hr Container
 */

import React from "react";
import { connect } from "react-redux";
import { bindActionCreators, Dispatch } from "redux";
import { RootState } from "../../shared-web/reducers/ReducerMain";
import { HrComponentState, HrProps } from "../reducers/hrReducer/hrTypes";
import * as hrActions from "../reducers/hrReducer/hrAction";
import { getHrState } from "../reducers/hrReducer/hrSelector";

import { AccordionContainer } from "../app-components/accordion/AccordionContainer";

class HRPage extends React.Component<HrProps, HrComponentState> {
  constructor(props: any) {
    super(props);
  }
  render() {

    return (
      <div className="hrMain">
        <AccordionContainer />
      </div>
    );
  }
}

function mapStateToProps(state: RootState) {
  return {
    ...getHrState(state),
  };
}
function mapDispatchToProps(dispatch: Dispatch) {
  return {
    actions: bindActionCreators(Object.assign({}, hrActions) as any, dispatch),
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(HRPage);
