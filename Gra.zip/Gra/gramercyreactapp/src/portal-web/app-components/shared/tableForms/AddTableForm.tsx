import { Grid, IconButton, TextField } from '@mui/material';
import { Formik } from 'formik';
import CheckIcon from "@mui/icons-material/Check";
import ClearIcon from "@mui/icons-material/Clear";

interface Properties {
  initialValue: any,
  handleOnSave(values: any): void;
  onClose(): void,
  validationSchema: any
  title: string
}

export const AddTableForm = (props: Properties) => {

  const { onClose, title, initialValue, validationSchema, handleOnSave } = props
  const dataFields = Object.keys(initialValue)
  const colNo: number = dataFields[4] == "StartTime" ? 5 : 4;
  return (
    <Formik
      initialValues={initialValue}
      validationSchema={validationSchema}
      onSubmit={(values) => {
        handleOnSave(values)
      }}
    >

      {formik => (
        <form onSubmit={formik.handleSubmit}>
          <Grid container spacing={2}>
            {dataFields.map((value, index) => {
              return <Grid item key={index} xs={6} className="inputFormElements">
                {index === 3 || index === colNo ?
                  <TextField type={'date'} id={value} className='formInputField' InputLabelProps={{ shrink: { ...formik.getFieldProps(value) } ? true : false }} variant="standard" label={value} {...formik.getFieldProps(value)} />
                  :
                  <TextField id={value} variant="standard" label={value} {...formik.getFieldProps(value)} />
                }
              </Grid>
            })
            }
          </Grid>
          <div className="saveAndCancel">
            <IconButton type='submit' className='savebtn'><CheckIcon /></IconButton>
            <IconButton onClick={onClose} className='cancelbtn'><ClearIcon /></IconButton>
          </div>
        </form>
      )}
    </Formik>
  )
}