import { Grid, IconButton, TextField } from '@mui/material';
import { Formik } from 'formik';
import CheckIcon from "@mui/icons-material/Check";
import ClearIcon from "@mui/icons-material/Clear";
import * as React from "react";

interface Properties {
  initialValue: any,
  handleOnUpdate(values: any): void;
  onClose(): void,
  validationSchema: any
  title: string
}

export const EditTableForm = (props: Properties) => {

  const { handleOnUpdate, onClose, title, initialValue, validationSchema } = props
  const dataFields = Object.keys(initialValue)
  console.log(dataFields);
  const colNo: number = dataFields[0] == "id" ? 4 : 3;
  const colNo1: number = dataFields[colNo == 4 ? 5 : 4] == "StartTime" ? (colNo == 4 ? 6 : 5) : 4;

  return (
    <Formik
      initialValues={initialValue}
      validationSchema={validationSchema}
      onSubmit={(values) => {
        console.log(values);
        handleOnUpdate(values)
      }}
    >

      {formik => (
        <form onSubmit={formik.handleSubmit}>
          <Grid container spacing={2}>
            {
              dataFields.map((value, index) => {
                return <Grid item key={index} xs={6} className="inputFormElements">
                  {index === colNo || index === colNo1 ?
                    <TextField type={'date'} className='formInputField' InputLabelProps={{ shrink: true }} id={value} variant="standard" label={value} {...formik.getFieldProps(value)} />
                    :
                    <TextField id={value} variant="standard" label={value} {...formik.getFieldProps(value)} />
                  }
                </Grid>
              })
            }
          </Grid>
          <div className="saveAndCancel">
            <IconButton type='submit' className='savebtn'><CheckIcon /></IconButton>
            <IconButton onClick={onClose} className='cancelbtn'><ClearIcon /></IconButton>
          </div>
        </form>
      )}
    </Formik>
  )
}