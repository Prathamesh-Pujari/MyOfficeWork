import { Dialog, Typography } from '@mui/material';
import React, { ReactElement } from 'react'
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import './dialogBox.scss';
import { Zoom } from '@material-ui/core';
import colors from '@styles/_themes-vars.module.scss';

interface Properties {
    openModel: boolean;
    HeaderTitle?: string;
    handleOnCloseBtn(): void;
    ModelCloseicon?: ReactElement;
}
const DialogBox: React.FunctionComponent<Properties> = (props) => {
    const { openModel, children, handleOnCloseBtn, HeaderTitle, ModelCloseicon } = props
    return (
        <Dialog open={openModel} maxWidth={"lg"} fullWidth={true} TransitionComponent={Zoom}>
            <DialogTitle className='ModelHeader' sx={{ backgroundColor: colors.cPopupWidgetTitleBgColor, borderBottom: colors.borderWithColor }}>
                <Typography style={{ color: colors.sTextColor, fontSize: colors.fontSize18, fontWeight: colors.fontWeight }} >{HeaderTitle}</Typography>
                <div className='ModelCloseBtn' onClick={handleOnCloseBtn}>{ModelCloseicon}</div>
            </DialogTitle>
            <DialogContent>{children}</DialogContent>
        </Dialog>
    )
}

export default DialogBox