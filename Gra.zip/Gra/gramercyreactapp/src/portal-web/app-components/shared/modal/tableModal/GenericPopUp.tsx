import React, { ReactElement } from "react";
import { Dialog, useMediaQuery, useTheme } from "@material-ui/core";
import {
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
} from "@mui/material";
import "./tableModal.scss";
import CloseIcon from "@mui/icons-material/Close";
import CheckIcon from "@mui/icons-material/Check";
import ClearIcon from "@mui/icons-material/Clear";

interface Properties {
  title: string;
  open: boolean;
  handleonClose(): void;
  handleOnConfirm(data: any): void;
  showActionBtn?: boolean;
  children: ReactElement;
}
export const GenericPopUp: React.FC<Properties> = (props) => {
  const {
    title,
    open,
    handleonClose,
    handleOnConfirm,
    showActionBtn = false,
    children,
  } = props;
  const theme = useTheme();
  const fullscreen = useMediaQuery(theme.breakpoints.down("md"));
  return (
    <div className="tableFormPopUp">
      <Dialog className="editDialogMain" fullScreen={fullscreen} open={open}>
        <DialogTitle className="inputFormTitle">
          {title}
          <IconButton className="closeIconbtn" onClick={handleonClose}>
            <CloseIcon />
          </IconButton>
        </DialogTitle>
        <DialogContent className="dialogContent">{children}</DialogContent>
        {showActionBtn && (
          <DialogActions className="saveAndCancel">
            <IconButton
              type="submit"
              onClick={handleOnConfirm}
              className="savebtn"
            >
              <CheckIcon />
            </IconButton>
            <IconButton onClick={handleonClose} className="cancelbtn">
              <ClearIcon />
            </IconButton>
          </DialogActions>
        )}
      </Dialog>
    </div>
  );
};
