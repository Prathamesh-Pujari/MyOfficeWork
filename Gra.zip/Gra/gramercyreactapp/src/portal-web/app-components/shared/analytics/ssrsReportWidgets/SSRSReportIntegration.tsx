import Samples from './ScriptTag';

const bounds = { height: '400px', width: '95%', margin: '10px auto' };

Samples.myFunction();

function SSRSReportIntegration() {
  return (
    <div className="ssrsReports" style={bounds}>
         <embed
        width={'100%'}
        height={'400px'}
        type="text/html"
        src="http://ssrs.aitglobalindia.com/ReportServer/Pages/ReportViewer.aspx?%2fSalesReports%2fRptSales&rs:Command=Render&rs:Embed=true">
      </embed>
    </div>
  );
}

export default SSRSReportIntegration;