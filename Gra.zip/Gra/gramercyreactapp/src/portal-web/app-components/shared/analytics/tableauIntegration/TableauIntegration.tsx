import React from 'react'
import TableauReport from 'tableau-react'

export const TableauIntegration = () => {

  const url = 'https://public.tableau.com/views/OneMinuteDashboard/OneMinuteDashboard'
  return (
    <div>

      <TableauReport
        url={url}
        options={{ height: '68vh', width: '75vw' }}
        query="?:embed=y&:loadOrderID=0&:display_count=y&:origin=viz_share_link"
      />
    </div>
  )
}
