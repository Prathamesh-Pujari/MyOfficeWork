function myFunction() {
    var newwindow=window.open('http://administrator:Report@123@ssrs.aitglobalindia.com/ReportServer/Pages/ReportViewer.aspx?%2fSalesReports%2fRptSales&rs:Command=Render',
    '',
    'titlebar=no, menubar=no, status=no, toolbar=no, height=10, width=10, left=5000, top=5000');
    setTimeout(() => {  newwindow.close(); }, 100);
    
} 

export default {
    myFunction
};