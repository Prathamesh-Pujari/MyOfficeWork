/**
 * Line chart
 */
import React from "react";
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';

const options: Highcharts.Options = {
    chart: {
        type: 'bar',
        height: 365
    },
    title: {
        text: ' '
    },
    credits: {
        enabled: false
    },
    xAxis: {
        categories: ['PEEF', 'OTPP', 'PRH', 'VENSS', 'Tract', 'TEXAS', 'RBSPTL', 'MORANG', 'SBCERA']
    },
    yAxis: {
        min: 0,
        max: 4,
        title: {
            text: 'Percentage'
        }
    },
    legend: {
        itemStyle: {
            show: true,
            fontSize: "14px",
            fontFamily: `'Roboto', sans-serif`,
            position: "bottom",
            fontWeight: "normal"
        }
    },
    plotOptions: {
        series: {
            stacking: 'normal'
        }

    },
    series: [{
        name: 'New',
        color: '#455e67',
        // @ts-ignore
        data: [0, 0, 0, 0, 0, 0, 0, 2.9, 0]
    }, {
        name: 'Progress',
        color: '#a9d18e',
        // @ts-ignore
        data: [1.7, 2.1, 2.1, 2.3, 1.9, 2.8, 2, 0, 0]
    }, {
        name: 'Hold',
        color: '#7f7f7f',
        // @ts-ignore
        data: [0, 0, 0, 0, 0, 0, 0, 0, 3.6]
    }]
};
interface ChartMixedProps extends HighchartsReact.Props {
    getRef(ref: any): void;
}

class ChartMixed extends React.Component<ChartMixedProps>{
    chartComponentRef: any;
    constructor(props: ChartMixedProps) {
        super(props);
        this.chartComponentRef = React.createRef();
        this.setRef = this.setRef.bind(this);
    }

    render() {
        return (
            <HighchartsReact
                highcharts={Highcharts}
                options={options}
                ref={this.setRef}
                containerProps={{ style: { width: "100%", height: "100%" } }}
                {...this.props}
            />
        );
    }

    setRef(ref: any) {
        this.props.getRef(ref);
    }
}

export default ChartMixed;