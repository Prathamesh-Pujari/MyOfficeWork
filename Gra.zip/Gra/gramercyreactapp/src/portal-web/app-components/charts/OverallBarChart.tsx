/**
 * Overall data
 */
import React from 'react';
import Chart from 'react-apexcharts';


interface OverallDataProps {
    chartData: any
}
const OverallData: React.FC<OverallDataProps> = ({ chartData }) => (
    <div className="overallPieChart" >
        <Chart {...chartData} height={'350px'} />
    </div>
);


export default OverallData;