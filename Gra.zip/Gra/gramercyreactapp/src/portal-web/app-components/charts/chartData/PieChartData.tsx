export const OverAllChartData = (data?: any, names?: any) => ({
    type: 'pie',
    series: data ? data : [20, 70, 10],
    options: {
        chart: {
            type: 'pie',
            toolbar: {
                show: true,

            }
        },
        colors: ['#7f7f7f', '#a9d18e', "#849db1", "#455e67", "#007934"],
        labels: names ? names : ["New", "Completed", "Hold"],
        theme: {
            monochrome: {
                enabled: false
            }
        },
        plotOptions: {
            pie: {
                customScale: 1.07,
                dataLabels: {
                    offset: 0
                }
            }
        },
        // title: {
        //     text: "Overall Project Status"
        // },
        dataLabels: {

            formatter(val: number, opts: any) {
                // const name = opts.w.globals.labels[opts.seriesIndex]
                return [val.toFixed(1) + '%']
            }
        },
        legend: {
            show: true,
            fontSize: "14px",
            fontFamily: `'Roboto', sans-serif`,
            position: 'bottom'

        },
        responsive: [{
            breakpoint: 480,
            options: {
                chart: {
                    width: 200
                },
                legend: {
                    position: 'bottom'
                }
            }
        }]
    }
});

export const DonutPieChartData = (data?: any, names?: any) => ({
    type: 'donut',
    series: data ? data : [4, 5, 5, 5, 11, 70],
    options: {
        chart: {
            width: '100%',
            height: '20%',
            type: 'donut',
            toolbar: {
                show: true,

            },
        },
        colors: ['#7f7f7f', '#a9d18e', '#e2f0d9', "#849db1", "#455e67", "#007934"],
        labels: names ? names : ["Pension", "Insurance", "Family Office/HNW", "Sovereign Wealth Fund", "Foundation", "Fund of Funds"],
        theme: {
            monochrome: {
                enabled: false
            }
        },
        plotOptions: {
            pie: {
                size: '100%',
                dataLabels: {
                    offset: -5
                }
            }
        },
        dataLabels: {

            formatter(val: number, opts: any) {
                return [val.toFixed(1) + '%']
            }
        },
        legend: {
            show: true,
            fontSize: "14px",
            fontFamily: `'Roboto', sans-serif`
        },
        responsive: [{
            breakpoint: 480,
            options: {
                chart: {
                    width: 200
                },
                legend: {
                    position: 'bottom'
                }
            }
        }]
    }
});

