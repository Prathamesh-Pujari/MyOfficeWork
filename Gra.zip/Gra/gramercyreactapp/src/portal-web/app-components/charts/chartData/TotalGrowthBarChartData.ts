// ===========================|| DASHBOARD - TOTAL GROWTH BAR CHART ||=========================== //

const chartData = {
  height: 480,
  type: "bar",
  options: {
    chart: {
      id: "bar-chart",
      stacked: true,
      toolbar: {
        show: true,
      },
      zoom: {
        enabled: true,
      },
      credits: {
        enabled: false,
      },
    },
    responsive: [
      {
        breakpoint: 480,
        options: {
          legend: {
            position: "bottom",
            offsetX: -10,
            offsetY: 0,
          },
        },
      },
    ],
    plotOptions: {
      bar: {
        horizontal: false,
        columnWidth: "50%",
      },
    },
    colors: ['#7f7f7f', '#a9d18e', "#849db1", "#455e67", "#007934"],
    xaxis: {
      type: "category",
      categories: [
        "Tract",
        "VENSS Direct Drawn",
        "Texas tech consolidated",
        "RBSPTL",
        "PRH Direct Drawn",
        "PEEF",
        "OTPP",
        "Nationalwide Mutual",
        "Nationalwide Life",
        "Nationalwide Fire",
        "Nationalwide Insurance",
      ],
    },
    legend: {
      show: true,
      fontSize: "14px",
      fontFamily: `'Roboto', sans-serif`,
      position: "bottom",
      offsetX: 20,
      labels: {
        useSeriesColors: false,
      },
      markers: {
        width: 16,
        height: 16,
        radius: 5,
      },
      itemMargin: {
        horizontal: 15,
        vertical: 8,
      },
    },
    fill: {
      type: "solid",
    },
    dataLabels: {
      enabled: false,
    },
    grid: {
      show: true,
    },
  },
  series: [
    {
      name: "Daily",
      data: [20, 5, 30, 40, 10, 25, 58, 60, 80, 75, 45],
    },
    {
      name: "MTD",
      data: [40, 25, 70, 80, 60, 75, 10, 10, 80, 75, 43],
    },
    {
      name: "YTD",
      data: [90, 45, 52, 36, 28, 98, 93, 44, 68, 88, 41],
    },
    {
      color: "#59b359",
      name: "ITD Ann",
      data: [45, 27, 80, 70, 90, 7, 10, 70, 90, 85, 55],
    },
    {
      name: "ITD Cum",
      data: [14.03, 190.29, 100, 50, 50.24, 80, 15.32, 31.45, 31.29, 17.96, 82],
    },
  ],
};

export const dailyTableData = {
  column: [
    {
      name: "name",
      label: "Name",
      width: 200,
      options: { filter: true, sort: true },
    },
    { name: "daily", label: "Daily", options: { filter: true, sort: true } },
    { name: "mtd", label: "MTD", options: { filter: true, sort: true } },
    { name: "ytd", label: "YTD", options: { filter: true, sort: true } },
    { name: "itdann", label: "ITD Ann", options: { filter: true, sort: true } },
    { name: "itdcum", label: "ITD Cum", options: { filter: true, sort: true } },
  ],
  rows: [
    {
      id: 1,
      name: "TRACT",
      daily: "0.20%",
      mtd: "-1.10%",
      ytd: "-7.15%",
      itdann: "1.36%",
      itdcum: "14.03%",
    },
    {
      id: 2,
      name: "VENSS Direct Drawn",
      daily: "0%",
      mtd: "-0.05%",
      ytd: "-0.05%",
      itdann: "36.95%",
      itdcum: "190.29%",
    },
    {
      id: 3,
      name: "TEXAS TECH Consolidated",
      daily: "0.32%",
      mtd: "0.73%",
      ytd: "4.12%",
      itdann: "-1.58%",
      itdcum: "-11.24%",
    },
    {
      id: 4,
      name: "VENSS Direct Drawn",
      daily: "0%",
      mtd: "-0.05%",
      ytd: "-0.05%",
      itdann: "36.95%",
      itdcum: "190.29%",
    },
    {
      id: 5,
      name: "SBCERA MCA Consolidated",
      daily: "0.06%",
      mtd: "0.43%",
      ytd: "0.90%",
      itdann: "5.81%",
      itdcum: "75.55%",
    },
    {
      id: 6,
      name: "SBCERA Fiscal Year",
      daily: "0.06%",
      mtd: "0.43%",
      ytd: "1.43%",
      itdann: "NA",
      itdcum: "NA",
    },
    {
      id: 7,
      name: "RBSPTL",
      daily: "0.07%",
      mtd: "0.22%",
      ytd: "-3.49%",
      itdann: "-2.94%",
      itdcum: "-8.27%",
    },
    {
      id: 8,
      name: "PRH Direct Drawn",
      daily: "0.0%",
      mtd: "0.0%",
      ytd: "0.36%",
      itdann: "12.76%",
      itdcum: "50.24%",
    },
    {
      id: 9,
      name: "PEEF",
      daily: "0.0%",
      mtd: "-0.07%",
      ytd: "-0.31%",
      itdann: "-8.26%",
      itdcum: "-54.87%",
    },
    {
      id: 10,
      name: "OTPP",
      daily: "0.07%",
      mtd: "0.54%",
      ytd: "1.89%",
      itdann: "10.72%",
      itdcum: "15.32%",
    },
    {
      id: 11,
      name: "National Mutual",
      daily: "0.31%",
      mtd: "-1.21%",
      ytd: "-7.61%",
      itdann: "4.02%",
      itdcum: "31.45%",
    },
    {
      id: 12,
      name: "National Life",
      daily: "0.33%",
      mtd: "-1.13%",
      ytd: "-7.73%",
      itdann: "4.0%",
      itdcum: "31.29%",
    },
    {
      id: 13,
      name: "National Fire",
      daily: "0.31%",
      mtd: "-1.20%",
      ytd: "-7.49%",
      itdann: "3.12%",
      itdcum: "17.96%",
    },
    {
      id: 13,
      name: "MORANG",
      daily: "0%",
      mtd: "-0.4%",
      ytd: "-0.14%",
      itdann: "-0.62%",
      itdcum: "-1.56%",
    },
  ],
};
export const dailyTableOptions = () => {
  return {
    selectableRowsHideCheckboxes: true,
    print: false,
    searchable: false,
    pagination: true,
    // count: 20,
    filter: false,
    download: false,
    fixedHeader: false,
    fixedSelectColumn: false,
    // rowsPerPage: 10,
    rowsPerPageOptions: [10, 20],
    search: false,
    viewColumns: false,
    draggableColumns: {
      enable: true,
    },
  };
};
export default chartData;
