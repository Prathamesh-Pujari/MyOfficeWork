
import React from 'react';

// material-ui
import { Grid, IconButton, Tooltip } from '@mui/material';

// third-party
import Chart from 'react-apexcharts';

// project imports
import SkeletonTotalGrowthBarChart from '../cards/Skeleton/TotalGrowthBarChart';
import MainCard from '../cards/MainCard';
import { gridSpacing } from '../../../shared-web/constant/theme-constant';
import colors from '@styles/_themes-vars.module.scss';

// chart data
import chartData, { dailyTableData, dailyTableOptions } from './chartData/TotalGrowthBarChartData';
import TableChartIcon from '@mui/icons-material/TableChart';
import { MuiDataTable } from "../../../shared-web/basicTable/DataTable";

const color = colors;

// ==============================|| DASHBOARD DEFAULT - TOTAL GROWTH BAR CHART ||============================== //

interface TotalGrowthBarChartProps {
    isLoading: boolean;
    showTotalChart?: boolean;
    handleShowTotalChartBtn(): void
}

const TotalGrowthBarChart: React.FC<TotalGrowthBarChartProps> = ({ isLoading, showTotalChart, handleShowTotalChartBtn }) => {
    return (
        <>
            {isLoading ? (
                <SkeletonTotalGrowthBarChart />
            ) : (
                <MainCard border={false}>
                    <Grid container spacing={gridSpacing} >
                        <Grid item xs={12} className="paddingTop0">
                            <Grid container alignItems="center" justifyContent="space-between">
                                <Grid item>
                                    <Grid container direction="column" spacing={0}>
                                        <Grid item>
                                        </Grid>
                                    </Grid>
                                </Grid>
                                <Grid item>
                                    <Tooltip title={showTotalChart ? "Display Table" : "Display Chart"}>
                                        <IconButton aria-label={showTotalChart ? "Display Table" : "Display Chart"} component="span" onClick={() => handleShowTotalChartBtn()}>
                                            <TableChartIcon />
                                        </IconButton>
                                    </Tooltip>
                                </Grid>
                            </Grid>
                        </Grid>
                        <Grid item xs={12} className="paddingTop0">
                            {showTotalChart ? <>
                                {/**@ts-ignore */}
                                < Chart {...chartData} />
                            </>

                                :

                                <MuiDataTable
                                    id="totalGrowthTable"
                                    title={''}
                                    className={'innerDataTableMain'}
                                    tableType={'mui'}
                                    titleFontSize={24}
                                    titleColor={color.themeColor200}
                                    tableData={dailyTableData.rows}
                                    tableColumn={dailyTableData.column}
                                    tableOptions={dailyTableOptions()}
                                />
                            }
                        </Grid>
                    </Grid>
                </MainCard>
            )
            }
        </>
    );
};

export default TotalGrowthBarChart;
