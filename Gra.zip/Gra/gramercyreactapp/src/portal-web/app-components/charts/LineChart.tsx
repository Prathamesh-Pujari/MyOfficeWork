/**
 * Line chart
 */
import React from "react";
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';

const options: Highcharts.Options = {
  chart: {
    height: 365
  },
  title: {
    text: ' '
  },
  credits: {
    enabled: false
  },
  xAxis: {
    categories: ['Dec', 'Jan', 'Feb', 'Mar', 'Apr']
  },
  yAxis: {
    title: {
      text: 'Performance'
    }
  },
  legend: {
    itemStyle: {
      show: true,
      fontSize: "14px",
      fontFamily: `'Roboto', sans-serif`,
      position: "bottom",
      fontWeight: "normal"
    }
  },

  series: [{
    type: 'line',
    name: 'Growth',
    data: [1, 2, 3, 2, 2],
    color: '#455e67'
  }],




}
interface LineCharProps extends HighchartsReact.Props {
  getRef(ref: any): void;
  showChart?: boolean;
}

class LineChart extends React.Component<LineCharProps>{
  chartComponentRef: any;
  constructor(props: LineCharProps) {
    super(props);
    this.chartComponentRef = React.createRef();
    this.setRef = this.setRef.bind(this);


  }

  render() {  
    return (<>
      <div>
          <HighchartsReact
          highcharts={Highcharts}
          options={options}
          ref={this.setRef}
          containerProps={{ style: { width: "100%", height: "100%" } }}
          {...this.props}
        />
      </div>
    </>
    );
  }

  setRef(ref: any) {
    this.props.getRef(ref);
  }
}

export default LineChart;