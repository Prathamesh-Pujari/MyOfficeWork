/**
 * Line chart
 */
import React from "react";
import HighchartsReact from 'highcharts-react-official';
import { aumData, aumOptions } from "../../services/dashboardServices";
import colors from '@styles/_themes-vars.module.scss';
import { IconButton, Tooltip } from "@mui/material";
import TableChartIcon from '@mui/icons-material/TableChart';
import OverallData from "./OverallBarChart";
import { OverAllChartData } from "./chartData/PieChartData";
import { MuiDataTable } from "../../../shared-web/basicTable/DataTable";

interface DailyAumTableChartProps extends HighchartsReact.Props {
  getRef(ref: any): void;
  showChart?: boolean;
  handleShowChart(): void
}

const color = colors;

class DailyAumTableChart extends React.Component<DailyAumTableChartProps>{
  chartComponentRef: any;
  constructor(props: DailyAumTableChartProps) {
    super(props);
    this.chartComponentRef = React.createRef();
    this.setRef = this.setRef.bind(this);
  }

  render() {
    const toggleButtonComponent = () => {
      return <Tooltip title="Display chart">
        <IconButton aria-label="Display chart" component="span" onClick={() => this.props.handleShowChart()}>
          <TableChartIcon />
        </IconButton>
      </Tooltip>
    }

    const pieChartData = aumData.data.map(value => {
      return parseInt(value.per)
    });

    const pieChartDataNam = aumData.data.map(value => {
      return value.name
    });


    return (

      <>
        {this.props.showChart ?
          <MuiDataTable
            id={'lineDataTable'}
            className={'innerDataTableMain'}
            title={''}
            tableType={'mui'}
            titleFontSize={24}
            titleColor={color.themeColor200}
            tableData={aumData.data}
            tableColumn={aumData.columns}
            tableOptions={aumOptions(toggleButtonComponent())}
          /> :
          <div>
            <Tooltip title="Display Table">
              <IconButton className="toggleTableIconBtn" onClick={() => this.props.handleShowChart()}>
                <TableChartIcon />
              </IconButton>
            </Tooltip>

            <OverallData chartData={OverAllChartData(pieChartData, pieChartDataNam)} />
          </div>
        }
      </>
    );
  }

  setRef(ref: any) {
    this.props.getRef(ref);
  }
}

export default DailyAumTableChart;