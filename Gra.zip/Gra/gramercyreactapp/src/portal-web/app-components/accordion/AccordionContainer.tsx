import React, { useState } from 'react'
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { Accordion, AccordionDetails, AccordionSummary, Typography } from '@mui/material';
import { EmuDetails } from '../tables/EmuDetails';
import { InvoiceDetails } from '../tables/InvoiceDetails';
import "./accordionContainer.scss";

export const AccordionContainer = () => {

  const [expanded, setExpanded] = useState<any>("panel1")

  const handleChange =
    (panel: string) => (event: React.SyntheticEvent, isExpanded: boolean) => {
      setExpanded(isExpanded ? panel : false);
    };

  return (
    <div className='hraccordions'>
      <Accordion
        style={{ backgroundColor: expanded === "panel1" ? "transparent" : "#f7f5f5" }}
        expanded={expanded === "panel1"}
        onChange={handleChange("panel1")}
      >
        <AccordionSummary
          className='accordioncontainertitle'
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1bh-content"
          id="panel1bh-header"

        >
          <Typography className="accordion-header-title"
            variant="h5"
            sx={{ width: "33%", flexShrink: 0 }}
            style={{ marginRight: "30px" }}
          >
            HR Details
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <EmuDetails title={'HR Details'} />
        </AccordionDetails>
      </Accordion>
      <Accordion
        style={{ backgroundColor: expanded === "panel2" ? "transparent" : "#f7f5f5" }}
        expanded={expanded === "panel2"}
        onChange={handleChange("panel2")}
      >
        <AccordionSummary
          className='accordioncontainertitle'
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel2bh-content"
          id="panel2bh-header"
        >
          <Typography className="accordion-header-title"
            variant="h5"
            sx={{ width: "33%", flexShrink: 0 }}
            style={{ marginRight: "30px" }}
          >
            Invoice Summary
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <InvoiceDetails title={'Invoice Summary'} />
        </AccordionDetails>
      </Accordion>
      <Accordion
        style={{ backgroundColor: expanded === "panel3" ? "transparent" : "#f7f5f5" }}
        expanded={expanded === "panel3"}
        onChange={handleChange("panel3")}
      >
        <AccordionSummary
          className='accordioncontainertitle'
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel3bh-content"
          id="panel3bh-header"
        >
          <Typography className="accordion-header-title"
            variant="h5"
            sx={{ width: "33%", flexShrink: 0 }}

          >
            Employee Summary
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <EmuDetails title={"Employee Summary"} />
        </AccordionDetails>
      </Accordion>
    </div>
  )
}
