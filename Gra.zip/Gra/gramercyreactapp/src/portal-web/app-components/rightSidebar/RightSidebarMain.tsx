import React, { useEffect, useRef, useState } from "react";
// material-ui
import { styled, useTheme } from "@mui/material/styles";
import { Divider, Drawer, IconButton, Tooltip } from "@mui/material";
import { IconSettings } from "@tabler/icons";
import CalendarMonthIcon from "@mui/icons-material/CalendarMonth";
import WidgetsIcon from "@mui/icons-material/Widgets";
import AddLinkIcon from "@mui/icons-material/AddLink";
import ChevronLeftIcon from "@mui/icons-material/ChevronLeft";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";

// third-party
import PerfectScrollbar from "react-perfect-scrollbar";

// project imports
import { CustomTabs } from "../tabs/CustomTabs";
import WidgetTab from "./rightSidebarTabs/WidgetsTab";
import QuickLinksTab from "./rightSidebarTabs/QuickLinksTab";
import CalendarComponent from "../calendar/Calendar";
import ClickAwayListener from '@mui/base/ClickAwayListener';


// ==============================|| LIVE CUSTOMIZATION ||============================== //

const RightSidebarMain: React.FC = () => {
  // const refOne = useRef<HTMLInputElement>(null);
  const theme = useTheme();
  // drawer on/off
  const [open, setOpen] = useState(false);

  const handleToggle = () => {
    setOpen((p) => !p);

  };

  const handleClickAway = (e: any) => {
    setOpen(false);
  }

  const DrawerHeader = styled("div")(({ theme }) => ({
    display: "flex",
    alignItems: "center",
    padding: theme.spacing(0, 1),
    // necessary for content to be below app bar
    ...theme.mixins.toolbar,
    justifyContent: "flex-start",
  }));
  return (
    <ClickAwayListener onClickAway={handleClickAway} mouseEvent="onMouseDown"
      touchEvent="onTouchStart" >
      <div>
        <Tooltip title="Live Customize">
          <IconButton
            onClick={handleToggle}
            className="gridLayoutIcons"
            color="inherit"
            size="small"
            disableRipple
          >
            <IconSettings />
          </IconButton>
        </Tooltip>
        <Drawer
          className="customOverideModel"
          anchor="right"
          onClose={handleToggle}
          open={open}
          elevation={16}
          PaperProps={{
            sx: {
              width: 280,
            },
          }}
        >
          {open ?
            (
              <PerfectScrollbar component="div">
                <CustomTabs
                  tabData={[
                    {
                      tabHeader: <CalendarMonthIcon />,
                      tabLabel: "Tab 1",
                      tabComponent: <CalendarComponent />,
                    },
                    {
                      tabHeader: <AddLinkIcon />,
                      tabLabel: "Tab 2",
                      tabComponent: <QuickLinksTab />,
                    },
                    {
                      tabHeader: <WidgetsIcon />,
                      tabLabel: "Tab 4",
                      tabComponent: <WidgetTab />,
                    },
                  ]} />
              </PerfectScrollbar>
            ) : null}
          <DrawerHeader>
            <IconButton className="circleBtnWithIcon" onClick={handleToggle}>
              {theme.direction === "rtl" ? (
                <ChevronLeftIcon />
              ) : (
                <ChevronRightIcon />
              )}
            </IconButton>
          </DrawerHeader>
          <Divider />
        </Drawer>
      </div>
    </ClickAwayListener>
  );
};

export default RightSidebarMain;
