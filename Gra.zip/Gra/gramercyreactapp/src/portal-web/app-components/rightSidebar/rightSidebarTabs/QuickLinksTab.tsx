import { Grid, Typography, TextField, Alert } from "@mui/material";
import { ReactElement, useState, useCallback, ChangeEvent } from "react";
import AddCircleOutlineIcon from "@mui/icons-material/AddCircleOutline";
import "../../../app-components/shared/modal/tableModal/tableModal.scss";
import StickySnackBar from "../../../../shared-web/stickySnackBar/StickySnackBar";
import { GenericPopUp } from "../../shared/modal/tableModal/GenericPopUp";
import { QuickLinks } from "./QuickLinks";
import React from "react";

interface Properties {
  ref?: any;

}

export interface UpdateQuickLinks {
  favourite?: number;
  label?: string;
  link?: string;
  id?: string;
  ref?: any;
}

const QuickLinksTab: React.FunctionComponent<Properties> = (
  props
): ReactElement => {
  const Links = [
    {
      id: "Salesforce",
      label: "Salesforce",
      link: "https://gramercy.my.salesforce.com/",
      favourite: 0,
    },

    {
      id: " Global Relay",
      label: " Global Relay",
      link: "https://compliance.login.globalrelay.com/cc/getToken",
      favourite: 0,
    },

    {
      id: "Deal Dashboard",
      label: "Deal Dashboard",
      link: " https://jira.gramercy.com/secure/Dashboard.jspa",
      favourite: 0,
    },

    {
      id: "Reporting Websites",
      label: "Reporting Websites",
      link: "http://reporting.gramercy.com/Reports/browse/Users%20Folders/GRAMERCY%20aitadmin/My%20Reports ",
      favourite: 0,
    },
  ];

  const [showPopUp, setShowPopup] = useState(false);

  const [addEditQuickLink, setAddEditQuickLink] = useState<UpdateQuickLinks>({
    label: "",
    link: "",
    favourite: 0,
    id: "",
  });
  const [data, setData] = useState<any>(Links);
  const [isEdit, setIsEdit] = useState({ edit: false, index: 0 });
  const [showDeleteSnackBar, setshowDeleteSnacBar] = useState(false);
  const [showAddSnackBar, setShowAddSnackBar] = useState(false);
  const [showEditSnackBar, setShowEditSnackBar] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  const handleOnAddBtnClick = () => {
    setShowPopup(true);
  };

  const handleonClose = () => {
    setErrorMessage("");
    setShowPopup(false);
    setAddEditQuickLink({ favourite: 0, label: "", link: "", id: "" });
    setIsEdit({ edit: false, index: 0 });
  };

  const handleOnChangeTitle = useCallback(
    (event: ChangeEvent<HTMLInputElement>) => {
      setAddEditQuickLink({ ...addEditQuickLink, label: event.target.value });
    },
    [addEditQuickLink]
  );

  const handleOnChangelink = useCallback(
    (event: ChangeEvent<HTMLInputElement>) => {
      setAddEditQuickLink({
        ...addEditQuickLink,
        link: event.target.value.trim(),
      });
    },
    [addEditQuickLink]
  );

  const handleOnAddConfirmBtn = () => {
    if (addEditQuickLink.label && addEditQuickLink.link) {
      setAddEditQuickLink(addEditQuickLink);
      setData([...data, { ...addEditQuickLink, id: addEditQuickLink.label }]);
      setShowPopup(false);
      setAddEditQuickLink({ favourite: 0, label: "", link: "", id: "" });
      setShowAddSnackBar(true);
      setErrorMessage("");
    } else {
      const { label, link } = addEditQuickLink;
      setErrorMessage(
        !label && !link
          ? "label and link are required"
          : !label
            ? "label is required"
            : !link
              ? "link is required"
              : ""
      );
    }
  };

  const handleOnClickEditBtn = (data: UpdateQuickLinks, index: number) => {
    setShowPopup(true);
    setAddEditQuickLink({
      favourite: data.favourite,
      label: data.label,
      link: data.link,
      id: data.label,
    });

    setIsEdit({ edit: true, index });
  };

  const handleOnEditConfirmBtn = () => {
    if (addEditQuickLink.label && addEditQuickLink.link) {
      data.splice(isEdit.index, 1, addEditQuickLink);
      setData(data);
      setIsEdit({ edit: false, index: 0 });
      setShowPopup(false);
      setAddEditQuickLink({ favourite: 0, label: "", link: "", id: "" });
      setShowEditSnackBar(true);
      setErrorMessage("");
    } else {
      const { label, link } = addEditQuickLink;
      setErrorMessage(
        !label && !link
          ? "label and link are required"
          : !label
            ? "label is required"
            : !link
              ? "link is required"
              : ""
      );
    }
  };

  const handleOnClickDeleteBtn = (index: any) => {
    data.splice(index, 1);
    setData(data);
    setshowDeleteSnacBar(true);
  };

  const handleOnChangeFav = (link: UpdateQuickLinks, index: number) => {
    if (link.favourite === 0) {
      data[index] = {
        favourite: 1,
        label: link.label,
        link: link.link,
        id: link.id,
      };
      setData([...data]);
    } else {
      data[index] = {
        favourite: 0,
        label: link.label,
        link: link.link,
        id: link.id,
      };
      setData([...data]);
    }
  };

  const handleCloseSnackBar = () => {
    setShowAddSnackBar(false);
    setshowDeleteSnacBar(false);
    setShowEditSnackBar(false);
  };

  return (
    <Typography component="div" className="quickLinks">
      <Grid item xs={12}>
        <Typography component="h2">
          Quick Links
          <Typography component="span" className="addQuickLinksBtn">
            <AddCircleOutlineIcon onClick={handleOnAddBtnClick} />
          </Typography>
        </Typography>
        <QuickLinks
          data={data}
          handleOnChangeFav={handleOnChangeFav}
          handleOnClickEditBtn={handleOnClickEditBtn}
          handleOnClickDeleteBtn={handleOnClickDeleteBtn}
        />
        <GenericPopUp
          title={isEdit.edit ? "Edit QuickLink" : "Add New QuickLink"}
          open={showPopUp}
          handleonClose={handleonClose}
          handleOnConfirm={
            isEdit.edit ? handleOnEditConfirmBtn : handleOnAddConfirmBtn
          }
          showActionBtn={true}
        >
          <>
            {errorMessage && (
              <Alert
                sx={{
                  backgroundColor: "#fdf4f4 !important",

                  mb: "10px",
                }}
                severity="error"
                onClose={() => {
                  setErrorMessage("");
                }}
              >
                {errorMessage}
              </Alert>
            )}
            <TextField
              sx={{ width: "450px", marginBottom: "15px" }}
              label="label"
              id="outlined-basic"
              value={addEditQuickLink.label}
              variant="standard"
              onChange={handleOnChangeTitle}
            />
            <TextField
              sx={{ width: "450px" }}
              label="Link"
              id="outlined-basic"
              name="Link"
              value={addEditQuickLink.link}
              variant="standard"
              onChange={handleOnChangelink}
            />
          </>
        </GenericPopUp>
      </Grid>
      <StickySnackBar
        showSnackBar={showAddSnackBar}
        onClose={handleCloseSnackBar}
        message={"Row added succesfully"}
      />
      <StickySnackBar
        showSnackBar={showEditSnackBar}
        onClose={handleCloseSnackBar}
        message={"Row edited succesfully"}
      />
      <StickySnackBar
        severity="error"
        showSnackBar={showDeleteSnackBar}
        onClose={handleCloseSnackBar}
        message=" Row deleted succesfully"
      />
    </Typography>
  );
};
export default QuickLinksTab;
function refOne(refOne: any) {
  throw new Error("Function not implemented.");
}

