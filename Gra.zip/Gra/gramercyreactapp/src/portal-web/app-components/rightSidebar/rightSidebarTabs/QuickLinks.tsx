import { Rating } from "@mui/material";
import React from "react";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import { UpdateQuickLinks } from "./QuickLinksTab";
interface Properties {
  data: any;
  handleOnChangeFav(data: any, index: number): void;
  handleOnClickEditBtn(data: any, index: number): void;
  handleOnClickDeleteBtn(index: number): void;
}
export const QuickLinks: React.FunctionComponent<Properties> = (
  props
): JSX.Element => {
  const {
    data,
    handleOnChangeFav,
    handleOnClickEditBtn,
    handleOnClickDeleteBtn,
  } = props;

  return (
    <div>
      {data
        .sort((a: any, b: any) => b.favourite - a.favourite)
        .map((link: UpdateQuickLinks, index: number) => (
          <ul>
            <li className="newlinks" key={index}>
              <span className="myrating" style={{ marginTop: "5px" }}>
                <Rating
                  className="Rating"
                  size="large"
                  max={1}
                  onChange={() => handleOnChangeFav(link, index)}
                  value={link.favourite}
                />

                <a
                  className="QuickLinks"
                  href={link.link}
                  target={"_blank"}
                  rel="noreferrer"
                >
                  {link.label}
                </a>
              </span>

              <span className="myicons">
                <EditIcon
                  className="editDeleteQuickLinksBtn"
                  onClick={() => handleOnClickEditBtn(link, index)}
                />
                <DeleteIcon
                  className="editDeleteQuickLinksBtn"
                  remove-Links={link.label}
                  onClick={() => handleOnClickDeleteBtn(index)}
                />
              </span>
            </li>
          </ul>
        ))}
    </div>
  );
};
