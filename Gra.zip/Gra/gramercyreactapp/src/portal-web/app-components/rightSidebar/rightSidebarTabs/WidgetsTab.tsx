import { TextField } from "@mui/material";
import React, { useState } from "react";
import { useSelector } from "react-redux";
import { RootState } from "../../../../shared-web/reducers/ReducerMain";
import ShowChartIcon from '@mui/icons-material/ShowChart';
import PieChartIcon from '@mui/icons-material/PieChart';
import NewspaperIcon from '@mui/icons-material/Newspaper';
import AnalyticsIcon from '@mui/icons-material/Analytics';
import AddchartIcon from '@mui/icons-material/Addchart';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import StackedBarChartIcon from '@mui/icons-material/StackedBarChart';
import AlignHorizontalLeftIcon from '@mui/icons-material/AlignHorizontalLeft';


export const filterResultDataSet = [
  {
    chartName: "Daily Performance",
    icon: StackedBarChartIcon,
    id: 'graph1',
    desc: "Daily Performance"
  },
  {
    chartName: "Daily AUM",
    icon: PieChartIcon,
    id: 'graph2',
    desc: "Daily AUM"
  },
  {
    chartName: "AUM Progress",
    icon: AlignHorizontalLeftIcon,
    id: 'graph3',
    desc: "AUM Progress"
  },
  {
    chartName: "Employee Growth",
    icon: ShowChartIcon,
    id: 'graph5',
    desc: "Shows employee growth per year"
  },
  {
    chartName: "Calendar",
    icon: CalendarMonthIcon,
    id: "graph9",
    desc: "Shows your work calender"
  },
  {
    chartName: "Tableau Report",
    icon: AnalyticsIcon,
    id: "graph10",
    desc: "Yearly sales report"
  },
  {
    chartName: "Company News",
    icon: NewspaperIcon,
    id: "CompanyNews",
    desc: "Shows latest company news"
  }
  ,
  {
    chartName: "SSRS Report",
    icon: AddchartIcon,
    id: "SSRSReport",
    desc: "Performance overview sales dashboard"
  },
  {
    chartName: "Client Type",
    icon: PieChartIcon,
    id: "graph11",
    desc: "Client Type"
  }
];
const WidgetTab: React.FC = () => {
  const [query, setQuery] = useState("");
  const [elements, setElement] = useState();

  const dragedElements = useSelector(
    (state: RootState) => state.dashboard.updatedDragWidgetSiderbar
  );

  const graphExists = (graphType: string) => {
    let result: boolean = false;
    let j: number = 0;
    for (j = 0; j < dragedElements.length; j++) {
      if (dragedElements[j].graphType == undefined) {
        if (dragedElements[j].i == graphType) {
          result = true;
          break;
        }
      }
      else {
        if (dragedElements[j].graphType == graphType) {
          result = true;
          break;
        }
      }
    }
    return result;
  }

  return (
    <>
      <TextField
        size="small"
        label="Search"
        className="searchField"
        onChange={(event) => setQuery(event.target.value)}
      />
      {filterResultDataSet
        .filter((item) => {
          if (query === "") {
            return item;
          } else if (
            item.chartName.toLowerCase().includes(query.toLowerCase())
          ) {
            return item;
          }
        })
        .map((item, index) => (
          <div className="box" key={index}>
            <div
              className={
                graphExists(item.id)
                  ? "disabled rightSideMenu"
                  : "rightSideMenu"
              }
              draggable={graphExists(item.id) ? false : true}
              unselectable="on"
              onDragStart={(e) =>
                e.dataTransfer.setData("text/plain", JSON.stringify(item))
              }
              onDragEnd={(e: any) => {
                setElement(e);
              }}
            >
              <div className="colorContainer"></div>
              <div className="imgContainer">
                <item.icon sx={{ fontSize: "40px" }} style={{ cursor: "pointer" }} />
              </div>
              <div className="textContainer">
                <div className="chartText">{item.chartName}</div>
                <div className="chartDesc">{item.desc}</div>
              </div>
            </div>
          </div>
        ))}
    </>
  );
};

export default WidgetTab;
