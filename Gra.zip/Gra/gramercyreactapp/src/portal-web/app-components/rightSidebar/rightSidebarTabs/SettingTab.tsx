
import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
    Grid,
    IconButton,
    Tooltip
} from '@mui/material';
import SubCard from '../../cards/SubCard';
import { gridSpacing } from '../../../../shared-web/constant/theme-constant';
// material-ui
import { useTheme } from '@mui/material/styles';
import { RootState } from '../../../../shared-web/reducers/ReducerMain';
import * as dashboardActions from '../../../reducers/dashboardReducer/dashboardActions';
import GridViewIcon from '@mui/icons-material/GridView';
import CalendarViewMonthIcon from '@mui/icons-material/CalendarViewMonth';

const SettingTab: React.FC = () => {

    const theme = useTheme();
    const dispatch = useDispatch();
    const customization = useSelector((state: RootState) => state.layout);
    const selectedDashboardGridLayout = useSelector((state: RootState) => state.dashboard.updateDashoboardGridLayout);

    // state - border radius
    const [borderRadius, setBorderRadius] = useState(customization.borderRadius);
    const handleBorderRadius = (event: Event, newValue: number | Array<number>) => {
        typeof (newValue) === 'number' && setBorderRadius(newValue);
    };

    let initialFont;
    switch (customization.fontFamily) {
        case `'Inter', sans-serif`:
            initialFont = 'Inter';
            break;
        case `'Poppins', sans-serif`:
            initialFont = 'Poppins';
            break;
        case `'Roboto', sans-serif`:
        default:
            initialFont = 'Roboto';
            break;
    }

    // state - font family
    const [fontFamily, setFontFamily] = useState(initialFont);

    const handleChangeDashboardLayout = (columns: any) => {
        dispatch({ type: dashboardActions.Type.SET_DASHBOARD_GRID_LAYOUT, payload: columns });
    }

    return (

        <div>
            <Grid container spacing={gridSpacing} sx={{ p: 3 }}>
                <Grid item xs={12}>
                    <SubCard title="Select Dashboard Layout">
                        <Tooltip title="2x3 Grid Layout">
                            <IconButton onClick={() => handleChangeDashboardLayout(2)}>
                                <GridViewIcon className="gridLayoutIcons" sx={selectedDashboardGridLayout === 2 ? { color: theme.palette.primary.main } : {}} />
                            </IconButton>
                        </Tooltip>
                        <Tooltip title="3x2 Grid Layout" >
                            <IconButton onClick={() => handleChangeDashboardLayout(3)}>
                                <CalendarViewMonthIcon className="gridLayoutIcons" sx={selectedDashboardGridLayout === 3 ? { color: theme.palette.primary.main } : {}} />
                            </IconButton>
                        </Tooltip>
                    </SubCard>
                </Grid>
            </Grid>
        </div>);
}
export default SettingTab;