import React from 'react';
// material-ui
import { Link, Typography, Stack } from '@mui/material';

// ==============================|| FOOTER - AUTHENTICATION 2 & 3 ||============================== //

const AuthFooter: React.FC = () => (
    <Stack direction="row" justifyContent="space-between">
        <Typography variant="subtitle2" component={Link} href="https://www.linkedin.com/in/aitglobalindia/?trk=public-profile-badge-profile-badge-view-profile-cta&originalSubdomain=in" target="_blank" underline="hover">
            AIT linkedin
        </Typography>
        <Typography variant="subtitle2" component={Link} href="https://aitglobalindia.com/" target="_blank" underline="hover">
            &copy; aitglobalindia.com
        </Typography>
    </Stack>
);

export default AuthFooter;
