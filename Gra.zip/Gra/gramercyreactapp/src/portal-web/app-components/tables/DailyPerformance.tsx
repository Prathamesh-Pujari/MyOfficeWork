import { BasicDataTable } from '../../../shared-web/basicTable/BasicDataTable'
import * as Yup from 'yup'


export const DailyPerformance = () => {
   const DailyPerformanceData = JSON.parse(JSON.stringify({
      "data": [
         {
            "id": "1001",
            "DisplayName": "SPC AGG",
            "Daily": "SPC",
            "MTD": "AGG",
            "YTD": "ALT",
            "Vertical": "Alternatives",
            "EstimatedAUM": "1,174,846,182"
         },
         {
            "id": "1002",
            "DisplayName": "Subtotal",
            "Daily": "AGG",
            "MTD": "SPC",
            "YTD": "ALT",
            "Vertical": "Capital Solution",
            "EstimatedAUM": "1,184,946,172"
         },
         {
            "id": "1003",
            "DisplayName": "BFH Drawn (86%)",
            "Daily": "SPC",
            "MTD": "ALT",
            "YTD": "AGG",
            "Vertical": "EMD Long-Only",
            "EstimatedAUM": "1,124,776,142"
         },
         {
            "id": "1004",
            "DisplayName": "Subtotal",
            "Daily": "ALT",
            "MTD": "AGG",
            "YTD": "SPC",
            "Vertical": "Multi-Asset",
            "EstimatedAUM": "1,284,946,192"
         },
         {
            "id": "1001",
            "DisplayName": "SPC AGG",
            "Daily": "SPC",
            "MTD": "AGG",
            "YTD": "ALT",
            "Vertical": "Alternatives",
            "EstimatedAUM": "1,174,846,182"
         },
         {
            "id": "1002",
            "DisplayName": "Subtotal",
            "Daily": "AGG",
            "MTD": "SPC",
            "YTD": "ALT",
            "Vertical": "Capital Solution",
            "EstimatedAUM": "1,184,946,172"
         },
         {
            "id": "1003",
            "DisplayName": "BFH Drawn (86%)",
            "Daily": "SPC",
            "MTD": "ALT",
            "YTD": "AGG",
            "Vertical": "EMD Long-Only",
            "EstimatedAUM": "1,124,776,142"
         },
         {
            "id": "1004",
            "DisplayName": "Subtotal",
            "Daily": "ALT",
            "MTD": "AGG",
            "YTD": "SPC",
            "Vertical": "Multi-Asset",
            "EstimatedAUM": "1,284,946,192"
         },
         {
            "id": "1001",
            "DisplayName": "SPC AGG",
            "Daily": "SPC",
            "MTD": "AGG",
            "YTD": "ALT",
            "Vertical": "Alternatives",
            "EstimatedAUM": "1,174,846,182"
         },
         {
            "id": "1002",
            "DisplayName": "Subtotal",
            "Daily": "AGG",
            "MTD": "SPC",
            "YTD": "ALT",
            "Vertical": "Capital Solution",
            "EstimatedAUM": "1,184,946,172"
         },
         {
            "id": "1003",
            "DisplayName": "BFH Drawn (86%)",
            "Daily": "SPC",
            "MTD": "ALT",
            "YTD": "AGG",
            "Vertical": "EMD Long-Only",
            "EstimatedAUM": "1,124,776,142"
         },
         {
            "id": "1004",
            "DisplayName": "Subtotal",
            "Daily": "ALT",
            "MTD": "AGG",
            "YTD": "SPC",
            "Vertical": "Multi-Asset",
            "EstimatedAUM": "1,284,946,192"
         },
         {
            "id": "1001",
            "DisplayName": "SPC AGG",
            "Daily": "SPC",
            "MTD": "AGG",
            "YTD": "ALT",
            "Vertical": "Alternatives",
            "EstimatedAUM": "1,174,846,182"
         },
         {
            "id": "1002",
            "DisplayName": "Subtotal",
            "Daily": "AGG",
            "MTD": "SPC",
            "YTD": "ALT",
            "Vertical": "Capital Solution",
            "EstimatedAUM": "1,184,946,172"
         },
         {
            "id": "1003",
            "DisplayName": "BFH Drawn (86%)",
            "Daily": "SPC",
            "MTD": "ALT",
            "YTD": "AGG",
            "Vertical": "EMD Long-Only",
            "EstimatedAUM": "1,124,776,142"
         },
         {
            "id": "1004",
            "DisplayName": "Subtotal",
            "Daily": "ALT",
            "MTD": "AGG",
            "YTD": "SPC",
            "Vertical": "Multi-Asset",
            "EstimatedAUM": "1,284,946,192"
         },
         {
            "id": "1001",
            "DisplayName": "SPC AGG",
            "Daily": "SPC",
            "MTD": "AGG",
            "YTD": "ALT",
            "Vertical": "Alternatives",
            "EstimatedAUM": "1,174,846,182"
         },
         {
            "id": "1002",
            "DisplayName": "Subtotal",
            "Daily": "AGG",
            "MTD": "SPC",
            "YTD": "ALT",
            "Vertical": "Capital Solution",
            "EstimatedAUM": "1,184,946,172"
         },
         {
            "id": "1003",
            "DisplayName": "BFH Drawn (86%)",
            "Daily": "SPC",
            "MTD": "ALT",
            "YTD": "AGG",
            "Vertical": "EMD Long-Only",
            "EstimatedAUM": "1,124,776,142"
         },
         {
            "id": "1004",
            "DisplayName": "Subtotal",
            "Daily": "ALT",
            "MTD": "AGG",
            "YTD": "SPC",
            "Vertical": "Multi-Asset",
            "EstimatedAUM": "1,284,946,192"
         },
         {
            "id": "1001",
            "DisplayName": "SPC AGG",
            "Daily": "SPC",
            "MTD": "AGG",
            "YTD": "ALT",
            "Vertical": "Alternatives",
            "EstimatedAUM": "1,174,846,182"
         },
         {
            "id": "1002",
            "DisplayName": "Subtotal",
            "Daily": "AGG",
            "MTD": "SPC",
            "YTD": "ALT",
            "Vertical": "Capital Solution",
            "EstimatedAUM": "1,184,946,172"
         },
         {
            "id": "1003",
            "DisplayName": "BFH Drawn (86%)",
            "Daily": "SPC",
            "MTD": "ALT",
            "YTD": "AGG",
            "Vertical": "EMD Long-Only",
            "EstimatedAUM": "1,124,776,142"
         },
         {
            "id": "1004",
            "DisplayName": "Subtotal",
            "Daily": "ALT",
            "MTD": "AGG",
            "YTD": "SPC",
            "Vertical": "Multi-Asset",
            "EstimatedAUM": "1,284,946,192"
         },
         {
            "id": "1001",
            "DisplayName": "SPC AGG",
            "Daily": "SPC",
            "MTD": "AGG",
            "YTD": "ALT",
            "Vertical": "Alternatives",
            "EstimatedAUM": "1,174,846,182"
         },
         {
            "id": "1002",
            "DisplayName": "Subtotal",
            "Daily": "AGG",
            "MTD": "SPC",
            "YTD": "ALT",
            "Vertical": "Capital Solution",
            "EstimatedAUM": "1,184,946,172"
         },
         {
            "id": "1003",
            "DisplayName": "BFH Drawn (86%)",
            "Daily": "SPC",
            "MTD": "ALT",
            "YTD": "AGG",
            "Vertical": "EMD Long-Only",
            "EstimatedAUM": "1,124,776,142"
         },
         {
            "id": "1004",
            "DisplayName": "Subtotal",
            "Daily": "ALT",
            "MTD": "AGG",
            "YTD": "SPC",
            "Vertical": "Multi-Asset",
            "EstimatedAUM": "1,284,946,192"
         },
         {
            "id": "1001",
            "DisplayName": "SPC AGG",
            "Daily": "SPC",
            "MTD": "AGG",
            "YTD": "ALT",
            "Vertical": "Alternatives",
            "EstimatedAUM": "1,174,846,182"
         },
         {
            "id": "1002",
            "DisplayName": "Subtotal",
            "Daily": "AGG",
            "MTD": "SPC",
            "YTD": "ALT",
            "Vertical": "Capital Solution",
            "EstimatedAUM": "1,184,946,172"
         },
         {
            "id": "1003",
            "DisplayName": "BFH Drawn (86%)",
            "Daily": "SPC",
            "MTD": "ALT",
            "YTD": "AGG",
            "Vertical": "EMD Long-Only",
            "EstimatedAUM": "1,124,776,142"
         },
         {
            "id": "1004",
            "DisplayName": "Subtotal",
            "Daily": "ALT",
            "MTD": "AGG",
            "YTD": "SPC",
            "Vertical": "Multi-Asset",
            "EstimatedAUM": "1,284,946,192"
         },
         {
            "id": "1001",
            "DisplayName": "SPC AGG",
            "Daily": "SPC",
            "MTD": "AGG",
            "YTD": "ALT",
            "Vertical": "Alternatives",
            "EstimatedAUM": "1,174,846,182"
         },
         {
            "id": "1002",
            "DisplayName": "Subtotal",
            "Daily": "AGG",
            "MTD": "SPC",
            "YTD": "ALT",
            "Vertical": "Capital Solution",
            "EstimatedAUM": "1,184,946,172"
         },
         {
            "id": "1003",
            "DisplayName": "BFH Drawn (86%)",
            "Daily": "SPC",
            "MTD": "ALT",
            "YTD": "AGG",
            "Vertical": "EMD Long-Only",
            "EstimatedAUM": "1,124,776,142"
         },
         {
            "id": "1004",
            "DisplayName": "Subtotal",
            "Daily": "ALT",
            "MTD": "AGG",
            "YTD": "SPC",
            "Vertical": "Multi-Asset",
            "EstimatedAUM": "1,284,946,192"
         },
         {
            "id": "1001",
            "DisplayName": "SPC AGG",
            "Daily": "SPC",
            "MTD": "AGG",
            "YTD": "ALT",
            "Vertical": "Alternatives",
            "EstimatedAUM": "1,174,846,182"
         },
         {
            "id": "1002",
            "DisplayName": "Subtotal",
            "Daily": "AGG",
            "MTD": "SPC",
            "YTD": "ALT",
            "Vertical": "Capital Solution",
            "EstimatedAUM": "1,184,946,172"
         },
         {
            "id": "1003",
            "DisplayName": "BFH Drawn (86%)",
            "Daily": "SPC",
            "MTD": "ALT",
            "YTD": "AGG",
            "Vertical": "EMD Long-Only",
            "EstimatedAUM": "1,124,776,142"
         },
         {
            "id": "1004",
            "DisplayName": "Subtotal",
            "Daily": "ALT",
            "MTD": "AGG",
            "YTD": "SPC",
            "Vertical": "Multi-Asset",
            "EstimatedAUM": "1,284,946,192"
         }
      ]
   }))

   const initialValues = {
      id: "",
      DisplayName: "",
      Daily: "",
      MTD: "",
      YTD: "",
      Vertical: "",
      EstimatedAUM: "",
   }
   const validationSchema = Yup.object({
      id: Yup.string(),
      DisplayName: Yup.string(),
      Daily: Yup.string(),
      MTD: Yup.string(),
      YTD: Yup.string(),
      Vertical: Yup.string(),
      EstimatedAUM: Yup.string(),
   })

   return (
      <div><BasicDataTable title={"EMU Deatils"} data={DailyPerformanceData.data} columns={[

         {
            label: "Id",
            name: "id",
            options: {
               filter: false,
               sort: true,
            }
         },

         {
            label: "Display Name",
            name: "DisplayName",
            options: {
               filter: true,
               sort: true,
            }
         },

         {
            label: "Daily",
            name: "Daily",
            options: {
               filter: true,
               sort: true,
            }
         },
         {
            label: "MTD",
            name: "MTD",
            options: {
               filter: false,
               sort: true,
            }
         },
         {
            label: "YTD",
            name: "YTD",
            options: {
               filter: true,
               sort: true,
            },
         },
         {
            label: "Vertical",
            name: "Vertical",
            options: {
               filter: false,
               sort: true,
            },
         },
         {
            label: "Estimated AUM",
            name: "EstimatedAUM",
            options: {
               filter: false,
               sort: true,
            },
         }
      ]} initialValues={initialValues} validationSchema={validationSchema} id="dailyPerformanceDatatable" />

      </div>
   )
}
