import { BasicDataTable } from '../../../shared-web/basicTable/BasicDataTable'
import { TableBadge } from '../../../shared-web/basicTable/TableBadge';
import * as Yup from 'yup'
import moment from "moment";
import Box from '@mui/material/Box';
import { Typography } from '@mui/material';



interface Properties {
    title: string;
}
export const MonthlyPerformance = (props: Properties) => {
    const { title } = props
    const MonthlyPerformance = JSON.parse(JSON.stringify({
        data: [
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 23,
                "dDate": "2020-09-30 00:00:00",
                "ModifiedDateTime": "2020-10-01 12:37:59.880000000",
                "Performance": 0.000800,
                "MonthlyPerformanceId": 41043
            },
            {
                "Final": "True",
                "ModifiedUserId": "TMahoney",
                "IndexID": 355,
                "dDate": "2020-09-30 00:00:00",
                "ModifiedDateTime": "2021-04-12 08:38:40.577000000",
                "Performance": -0.000830,
                "MonthlyPerformanceId": 41044
            },
            {
                "Final": "False",
                "ModifiedUserId": "Admin",
                "IndexID": 401,
                "dDate": "2020-09-30 00:00:00",
                "ModifiedDateTime": "2021-04-15 09:01:14.263000000",
                "Performance": -0.009435,
                "MonthlyPerformanceId": 41045
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 209,
                "dDate": "2020-09-30 00:00:00",
                "ModifiedDateTime": "2020-10-01 12:37:59.867000000",
                "Performance": -0.003597,
                "MonthlyPerformanceId": 41046
            },
            {
                "Final": "True",
                "ModifiedUserId": "AGeitz",
                "IndexID": 232,
                "dDate": "2020-09-30 00:00:00",
                "ModifiedDateTime": "2020-11-03 11:20:13.093000000",
                "Performance": -0.014231,
                "MonthlyPerformanceId": 41047
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 278,
                "dDate": "2020-09-30 00:00:00",
                "ModifiedDateTime": "",
                "Performance": -0.002076,
                "MonthlyPerformanceId": 41048
            },
            {
                "Final": "True",
                "ModifiedUserId": "AGeitz",
                "IndexID": 438,
                "dDate": "2020-09-30 00:00:00",
                "ModifiedDateTime": "2020-11-03 11:20:13.127000000",
                "Performance": -0.016705,
                "MonthlyPerformanceId": 41049
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 89,
                "dDate": "2020-09-30 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 41050
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 3,
                "dDate": "2020-09-30 00:00:00",
                "ModifiedDateTime": "2020-10-01 12:37:59.850000000",
                "Performance": -0.019524,
                "MonthlyPerformanceId": 41051
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 295,
                "dDate": "2020-09-30 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 41052
            },
            {
                "Final": "True",
                "ModifiedUserId": "AGeitz",
                "IndexID": 229,
                "dDate": "2020-09-30 00:00:00",
                "ModifiedDateTime": "2020-11-03 11:20:13.140000000",
                "Performance": -0.007987,
                "MonthlyPerformanceId": 41053
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 6,
                "dDate": "2020-09-30 00:00:00",
                "ModifiedDateTime": "2020-10-01 12:37:59.850000000",
                "Performance": -0.039228,
                "MonthlyPerformanceId": 41054
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 49,
                "dDate": "2020-09-30 00:00:00",
                "ModifiedDateTime": "2020-10-01 12:37:59.867000000",
                "Performance": -0.009352,
                "MonthlyPerformanceId": 41055
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 238,
                "dDate": "2020-09-30 00:00:00",
                "ModifiedDateTime": "2020-10-01 12:38:00.020000000",
                "Performance": -0.023730,
                "MonthlyPerformanceId": 41056
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 138,
                "dDate": "2020-09-30 00:00:00",
                "ModifiedDateTime": "2020-10-01 12:37:59.867000000",
                "Performance": -0.004426,
                "MonthlyPerformanceId": 41057
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 384,
                "dDate": "2020-09-30 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 41058
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 284,
                "dDate": "2020-09-30 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 41059
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 29,
                "dDate": "2020-09-30 00:00:00",
                "ModifiedDateTime": "2020-10-01 12:37:59.880000000",
                "Performance": -0.037997,
                "MonthlyPerformanceId": 41060
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 344,
                "dDate": "2020-09-30 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 41061
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 9,
                "dDate": "2020-09-30 00:00:00",
                "ModifiedDateTime": "2020-10-01 12:37:59.880000000",
                "Performance": 0.002339,
                "MonthlyPerformanceId": 41062
            },
            {
                "Final": "True",
                "ModifiedUserId": "AGeitz",
                "IndexID": 636,
                "dDate": "2020-09-30 00:00:00",
                "ModifiedDateTime": "2020-11-03 11:20:13.157000000",
                "Performance": -0.018319,
                "MonthlyPerformanceId": 41063
            },
            {
                "Final": "True",
                "ModifiedUserId": "AGeitz",
                "IndexID": 427,
                "dDate": "2020-09-30 00:00:00",
                "ModifiedDateTime": "2020-11-03 11:20:13.157000000",
                "Performance": -0.009902,
                "MonthlyPerformanceId": 41064
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 3,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:20.990000000",
                "Performance": -0.112895,
                "MonthlyPerformanceId": 47715
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 4,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.010000000",
                "Performance": -0.029399,
                "MonthlyPerformanceId": 47716
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 5,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.017000000",
                "Performance": -0.034304,
                "MonthlyPerformanceId": 47717
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 6,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.030000000",
                "Performance": -0.031361,
                "MonthlyPerformanceId": 47718
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 7,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.030000000",
                "Performance": -0.035275,
                "MonthlyPerformanceId": 47719
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 8,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.083000000",
                "Performance": 0.000128,
                "MonthlyPerformanceId": 47720
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 9,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.087000000",
                "Performance": 0.005043,
                "MonthlyPerformanceId": 47721
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 16,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.040000000",
                "Performance": -0.030557,
                "MonthlyPerformanceId": 47722
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 17,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.043000000",
                "Performance": -0.019506,
                "MonthlyPerformanceId": 47723
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 18,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.053000000",
                "Performance": -0.011157,
                "MonthlyPerformanceId": 47724
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 23,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.087000000",
                "Performance": 0.000700,
                "MonthlyPerformanceId": 47725
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 36,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.060000000",
                "Performance": -0.055048,
                "MonthlyPerformanceId": 47726
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 37,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.047000000",
                "Performance": -0.030222,
                "MonthlyPerformanceId": 47727
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 39,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.050000000",
                "Performance": -0.021999,
                "MonthlyPerformanceId": 47728
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 48,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.057000000",
                "Performance": -0.048825,
                "MonthlyPerformanceId": 47729
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 49,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.057000000",
                "Performance": -0.030011,
                "MonthlyPerformanceId": 47730
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 50,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.050000000",
                "Performance": -0.029770,
                "MonthlyPerformanceId": 47731
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 51,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.050000000",
                "Performance": -0.029890,
                "MonthlyPerformanceId": 47732
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 57,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.053000000",
                "Performance": 0.214257,
                "MonthlyPerformanceId": 47733
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 90,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.043000000",
                "Performance": -0.001085,
                "MonthlyPerformanceId": 47734
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 99,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.063000000",
                "Performance": -0.050005,
                "MonthlyPerformanceId": 47735
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 101,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.060000000",
                "Performance": -0.049844,
                "MonthlyPerformanceId": 47736
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 102,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.063000000",
                "Performance": -0.054032,
                "MonthlyPerformanceId": 47737
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 103,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.063000000",
                "Performance": -0.052232,
                "MonthlyPerformanceId": 47738
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 123,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.070000000",
                "Performance": -0.051304,
                "MonthlyPerformanceId": 47739
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 124,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.070000000",
                "Performance": -0.048412,
                "MonthlyPerformanceId": 47740
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 125,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.043000000",
                "Performance": 0.004992,
                "MonthlyPerformanceId": 47741
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 138,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.067000000",
                "Performance": -0.054254,
                "MonthlyPerformanceId": 47742
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 139,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.067000000",
                "Performance": -0.063729,
                "MonthlyPerformanceId": 47743
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 140,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.070000000",
                "Performance": -0.053138,
                "MonthlyPerformanceId": 47744
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 141,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.070000000",
                "Performance": -0.065466,
                "MonthlyPerformanceId": 47745
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 153,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.090000000",
                "Performance": 0.004771,
                "MonthlyPerformanceId": 47746
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 190,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.043000000",
                "Performance": 0.004477,
                "MonthlyPerformanceId": 47747
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 209,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.053000000",
                "Performance": -0.011886,
                "MonthlyPerformanceId": 47748
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 222,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47749
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 223,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47750
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 224,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 17:46:50.210000000",
                "Performance": -0.049492,
                "MonthlyPerformanceId": 47751
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 225,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 17:46:50.227000000",
                "Performance": -0.050117,
                "MonthlyPerformanceId": 47752
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 227,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.093000000",
                "Performance": 0.010676,
                "MonthlyPerformanceId": 47753
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 228,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.090000000",
                "Performance": -0.031301,
                "MonthlyPerformanceId": 47754
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 229,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 17:46:50.227000000",
                "Performance": -0.043261,
                "MonthlyPerformanceId": 47755
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 230,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 17:46:50.243000000",
                "Performance": -0.043844,
                "MonthlyPerformanceId": 47756
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 231,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 17:46:50.243000000",
                "Performance": -0.050801,
                "MonthlyPerformanceId": 47757
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 232,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 17:46:50.260000000",
                "Performance": -0.051593,
                "MonthlyPerformanceId": 47758
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 233,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47759
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 234,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47760
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 237,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.093000000",
                "Performance": -0.025473,
                "MonthlyPerformanceId": 47761
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 238,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.097000000",
                "Performance": -0.023511,
                "MonthlyPerformanceId": 47762
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 239,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.097000000",
                "Performance": -0.020152,
                "MonthlyPerformanceId": 47763
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 240,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.093000000",
                "Performance": -0.011737,
                "MonthlyPerformanceId": 47764
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 241,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47765
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 242,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47766
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 245,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47767
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 246,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47768
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 262,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.063000000",
                "Performance": -0.050076,
                "MonthlyPerformanceId": 47769
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 278,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": -0.046504,
                "MonthlyPerformanceId": 47770
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 284,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47771
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 285,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47772
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 295,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47773
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 296,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47774
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 341,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47775
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 342,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47776
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 343,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47777
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 344,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47778
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 345,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47779
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 346,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47780
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 350,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47781
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 352,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-04-01 16:20:28.007000000",
                "Performance": 0.003282,
                "MonthlyPerformanceId": 47782
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 354,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-04-01 16:20:28.017000000",
                "Performance": -0.047270,
                "MonthlyPerformanceId": 47783
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 355,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-05-02 17:01:42.460000000",
                "Performance": -0.000295,
                "MonthlyPerformanceId": 47784
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 357,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47785
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 358,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47786
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 371,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.073000000",
                "Performance": -0.046507,
                "MonthlyPerformanceId": 47787
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 383,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47788
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 384,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47789
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 392,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.087000000",
                "Performance": 0.003066,
                "MonthlyPerformanceId": 47790
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 393,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47791
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 394,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47792
            },
            {
                "Final": "False",
                "ModifiedUserId": "Admin",
                "IndexID": 401,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-06-15 09:00:55.340000000",
                "Performance": -0.027093,
                "MonthlyPerformanceId": 47793
            },
            {
                "Final": "False",
                "ModifiedUserId": "Admin",
                "IndexID": 402,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-06-15 09:00:55.347000000",
                "Performance": 0.008732,
                "MonthlyPerformanceId": 47794
            },
            {
                "Final": "False",
                "ModifiedUserId": "Admin",
                "IndexID": 403,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-06-15 09:00:55.350000000",
                "Performance": -0.028288,
                "MonthlyPerformanceId": 47795
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 404,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-29 11:14:39.767000000",
                "Performance": 0.040801,
                "MonthlyPerformanceId": 47796
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 405,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.097000000",
                "Performance": -0.052526,
                "MonthlyPerformanceId": 47797
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 418,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47798
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 419,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47799
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 420,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47800
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 421,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47801
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 422,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.077000000",
                "Performance": -0.050275,
                "MonthlyPerformanceId": 47802
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 426,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-04-01 16:20:28.030000000",
                "Performance": -0.001068,
                "MonthlyPerformanceId": 47803
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 427,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-04-01 16:20:28.040000000",
                "Performance": 0.004069,
                "MonthlyPerformanceId": 47804
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 428,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47805
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 429,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47806
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 430,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47807
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 435,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47808
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 436,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47809
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 437,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.073000000",
                "Performance": -0.046521,
                "MonthlyPerformanceId": 47810
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 438,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47811
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 451,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47812
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 452,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47813
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 453,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47814
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 454,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47815
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 540,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47816
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 542,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-29 11:34:42.627000000",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47817
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 547,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47818
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 548,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47819
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 563,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47820
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 565,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47821
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 568,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47822
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 586,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-23 12:36:57.847000000",
                "Performance": -0.000462,
                "MonthlyPerformanceId": 47823
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 596,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47824
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 597,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-04-01 16:20:28.050000000",
                "Performance": -0.038037,
                "MonthlyPerformanceId": 47825
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 598,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.077000000",
                "Performance": -0.039220,
                "MonthlyPerformanceId": 47826
            },
            {
                "Final": "True",
                "ModifiedUserId": "ngoldberg",
                "IndexID": 617,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-31 11:01:08.673000000",
                "Performance": 0.011842,
                "MonthlyPerformanceId": 47827
            },
            {
                "Final": "True",
                "ModifiedUserId": "ngoldberg",
                "IndexID": 618,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-31 11:01:08.690000000",
                "Performance": 0.011737,
                "MonthlyPerformanceId": 47828
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 621,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47829
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 622,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47830
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 623,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47831
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 626,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.080000000",
                "Performance": -0.024928,
                "MonthlyPerformanceId": 47832
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 634,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.083000000",
                "Performance": -0.054630,
                "MonthlyPerformanceId": 47833
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 635,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 15:00:21.080000000",
                "Performance": -0.056937,
                "MonthlyPerformanceId": 47834
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 636,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-01 17:46:50.320000000",
                "Performance": -0.050757,
                "MonthlyPerformanceId": 47835
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 637,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-09 11:53:58.597000000",
                "Performance": 0.004595,
                "MonthlyPerformanceId": 47836
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 645,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47837
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 647,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-28 10:34:52.717000000",
                "Performance": -0.014205,
                "MonthlyPerformanceId": 47838
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 648,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-28 10:35:17.820000000",
                "Performance": -0.017098,
                "MonthlyPerformanceId": 47839
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 649,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-28 10:35:17.837000000",
                "Performance": -0.018494,
                "MonthlyPerformanceId": 47840
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 673,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-04-01 16:20:28.060000000",
                "Performance": -0.041906,
                "MonthlyPerformanceId": 47841
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 682,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-25 11:15:51.783000000",
                "Performance": 0.007854,
                "MonthlyPerformanceId": 47842
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 702,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47843
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 714,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-04-01 16:20:28.070000000",
                "Performance": -0.018393,
                "MonthlyPerformanceId": 47844
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 719,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-05-02 16:12:51.573000000",
                "Performance": 0.004595,
                "MonthlyPerformanceId": 47845
            },
            {
                "Final": "True",
                "ModifiedUserId": "ngoldberg",
                "IndexID": 619,
                "dDate": "2022-01-31 00:00:00",
                "ModifiedDateTime": "2022-03-31 11:08:08.590000000",
                "Performance": 0.032500,
                "MonthlyPerformanceId": 48060
            },
            {
                "Final": "True",
                "ModifiedUserId": "ngoldberg",
                "IndexID": 620,
                "dDate": "2022-01-31 00:00:00",
                "ModifiedDateTime": "2022-03-31 10:50:12.163000000",
                "Performance": 0.027300,
                "MonthlyPerformanceId": 48061
            },
            {
                "Final": "True",
                "ModifiedUserId": "ngoldberg",
                "IndexID": 619,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-31 11:03:49.643000000",
                "Performance": 0.007600,
                "MonthlyPerformanceId": 48062
            },
            {
                "Final": "True",
                "ModifiedUserId": "ngoldberg",
                "IndexID": 620,
                "dDate": "2022-02-28 00:00:00",
                "ModifiedDateTime": "2022-03-31 11:04:28.623000000",
                "Performance": 0.007430,
                "MonthlyPerformanceId": 48063
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 3,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.933000000",
                "Performance": -0.017187,
                "MonthlyPerformanceId": 48064
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 4,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.933000000",
                "Performance": -0.022182,
                "MonthlyPerformanceId": 48065
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 5,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.937000000",
                "Performance": 0.034114,
                "MonthlyPerformanceId": 48066
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 6,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.937000000",
                "Performance": 0.035773,
                "MonthlyPerformanceId": 48067
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 7,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.937000000",
                "Performance": 0.023184,
                "MonthlyPerformanceId": 48068
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 8,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.980000000",
                "Performance": 0.000308,
                "MonthlyPerformanceId": 48069
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 9,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.980000000",
                "Performance": 0.009616,
                "MonthlyPerformanceId": 48070
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 16,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.940000000",
                "Performance": -0.025203,
                "MonthlyPerformanceId": 48071
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 17,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.940000000",
                "Performance": 0.001161,
                "MonthlyPerformanceId": 48072
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 18,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.950000000",
                "Performance": -0.027784,
                "MonthlyPerformanceId": 48073
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 23,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.980000000",
                "Performance": 0.003200,
                "MonthlyPerformanceId": 48074
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 36,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.957000000",
                "Performance": -0.011162,
                "MonthlyPerformanceId": 48075
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 37,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.947000000",
                "Performance": -0.005352,
                "MonthlyPerformanceId": 48076
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 39,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.947000000",
                "Performance": -0.020323,
                "MonthlyPerformanceId": 48077
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 48,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.953000000",
                "Performance": -0.044718,
                "MonthlyPerformanceId": 48078
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 49,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.957000000",
                "Performance": -0.000971,
                "MonthlyPerformanceId": 48079
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 50,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.950000000",
                "Performance": -0.022239,
                "MonthlyPerformanceId": 48080
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 51,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.950000000",
                "Performance": -0.022585,
                "MonthlyPerformanceId": 48081
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 57,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.950000000",
                "Performance": -0.318076,
                "MonthlyPerformanceId": 48082
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 90,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.943000000",
                "Performance": 0.006271,
                "MonthlyPerformanceId": 48083
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 99,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.960000000",
                "Performance": -0.015316,
                "MonthlyPerformanceId": 48084
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 101,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.957000000",
                "Performance": -0.028511,
                "MonthlyPerformanceId": 48085
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 102,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.960000000",
                "Performance": -0.018295,
                "MonthlyPerformanceId": 48086
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 103,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.963000000",
                "Performance": -0.018321,
                "MonthlyPerformanceId": 48087
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 123,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.967000000",
                "Performance": -0.030973,
                "MonthlyPerformanceId": 48088
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 124,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.970000000",
                "Performance": -0.025476,
                "MonthlyPerformanceId": 48089
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 125,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.943000000",
                "Performance": 0.031962,
                "MonthlyPerformanceId": 48090
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 138,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.963000000",
                "Performance": -0.033338,
                "MonthlyPerformanceId": 48091
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 139,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.967000000",
                "Performance": -0.023608,
                "MonthlyPerformanceId": 48092
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 140,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.967000000",
                "Performance": -0.013624,
                "MonthlyPerformanceId": 48093
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 141,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.970000000",
                "Performance": -0.008987,
                "MonthlyPerformanceId": 48094
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 153,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.983000000",
                "Performance": 0.004896,
                "MonthlyPerformanceId": 48095
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 190,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.947000000",
                "Performance": 0.017573,
                "MonthlyPerformanceId": 48096
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 209,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.953000000",
                "Performance": -0.030453,
                "MonthlyPerformanceId": 48097
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 222,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48098
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 223,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48099
            },
            {
                "Final": "True",
                "ModifiedUserId": "MHarris",
                "IndexID": 224,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-05-10 11:45:55.033000000",
                "Performance": 0.003017,
                "MonthlyPerformanceId": 48100
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 225,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 16:17:16.873000000",
                "Performance": 0.002392,
                "MonthlyPerformanceId": 48101
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 227,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.987000000",
                "Performance": 0.012446,
                "MonthlyPerformanceId": 48102
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 228,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.987000000",
                "Performance": 0.065084,
                "MonthlyPerformanceId": 48103
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 229,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 16:17:16.883000000",
                "Performance": -0.007635,
                "MonthlyPerformanceId": 48104
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 230,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 16:17:16.893000000",
                "Performance": -0.008218,
                "MonthlyPerformanceId": 48105
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 231,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 16:17:16.900000000",
                "Performance": -0.000097,
                "MonthlyPerformanceId": 48106
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 232,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 16:17:16.910000000",
                "Performance": -0.000889,
                "MonthlyPerformanceId": 48107
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 233,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48108
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 234,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48109
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 237,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.990000000",
                "Performance": 0.016491,
                "MonthlyPerformanceId": 48110
            },
            {
                "Final": "False",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 702,
                "dDate": "2021-09-30 00:00:00",
                "ModifiedDateTime": "2022-02-22 15:48:14.013000000",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47713
            },
            {
                "Final": "False",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 702,
                "dDate": "2021-10-31 00:00:00",
                "ModifiedDateTime": "2022-02-22 15:48:26.167000000",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 47714
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 371,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.973000000",
                "Performance": -0.025761,
                "MonthlyPerformanceId": 48137
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 383,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48138
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 384,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48139
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 392,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.983000000",
                "Performance": 0.003235,
                "MonthlyPerformanceId": 48140
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 393,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48141
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 394,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48142
            },
            {
                "Final": "False",
                "ModifiedUserId": "Admin",
                "IndexID": 401,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-06-15 09:00:55.340000000",
                "Performance": -0.027503,
                "MonthlyPerformanceId": 48143
            },
            {
                "Final": "False",
                "ModifiedUserId": "Admin",
                "IndexID": 402,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-06-15 09:00:55.347000000",
                "Performance": 0.013961,
                "MonthlyPerformanceId": 48144
            },
            {
                "Final": "False",
                "ModifiedUserId": "Admin",
                "IndexID": 403,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-06-15 09:00:55.353000000",
                "Performance": -0.015772,
                "MonthlyPerformanceId": 48145
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 404,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-29 15:02:15.753000000",
                "Performance": 0.026180,
                "MonthlyPerformanceId": 48146
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 405,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.993000000",
                "Performance": -0.013239,
                "MonthlyPerformanceId": 48147
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 418,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48148
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 419,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48149
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 420,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48150
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 421,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48151
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 422,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.973000000",
                "Performance": -0.016236,
                "MonthlyPerformanceId": 48152
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 426,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-05-02 16:17:04.953000000",
                "Performance": -0.000743,
                "MonthlyPerformanceId": 48153
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 427,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-05-02 16:17:04.963000000",
                "Performance": 0.002625,
                "MonthlyPerformanceId": 48154
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 428,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48155
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 429,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48156
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 430,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48157
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 435,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48158
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 436,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48159
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 437,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.970000000",
                "Performance": -0.036578,
                "MonthlyPerformanceId": 48160
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 438,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48161
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 451,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48162
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 452,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48163
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 453,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48164
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 454,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48165
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 540,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48166
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 542,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-29 15:21:23.900000000",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48167
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 547,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48168
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 548,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48169
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 563,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48170
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 565,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48171
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 568,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48172
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 586,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-20 09:32:13.540000000",
                "Performance": -0.000880,
                "MonthlyPerformanceId": 48173
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 596,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48174
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 597,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-05-02 16:17:04.973000000",
                "Performance": 0.010670,
                "MonthlyPerformanceId": 48175
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 598,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.973000000",
                "Performance": 0.037568,
                "MonthlyPerformanceId": 48176
            },
            {
                "Final": "True",
                "ModifiedUserId": "ngoldberg",
                "IndexID": 617,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-27 14:37:41.620000000",
                "Performance": 0.039044,
                "MonthlyPerformanceId": 48177
            },
            {
                "Final": "True",
                "ModifiedUserId": "ngoldberg",
                "IndexID": 618,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-27 14:37:41.630000000",
                "Performance": 0.038940,
                "MonthlyPerformanceId": 48178
            },
            {
                "Final": "True",
                "ModifiedUserId": "ngoldberg",
                "IndexID": 619,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-27 14:37:41.637000000",
                "Performance": 0.040589,
                "MonthlyPerformanceId": 48179
            },
            {
                "Final": "True",
                "ModifiedUserId": "ngoldberg",
                "IndexID": 620,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-27 14:37:41.647000000",
                "Performance": 0.037659,
                "MonthlyPerformanceId": 48180
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 621,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48181
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 622,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48182
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 623,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48183
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 626,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.977000000",
                "Performance": 0.650498,
                "MonthlyPerformanceId": 48184
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 634,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.980000000",
                "Performance": -0.016593,
                "MonthlyPerformanceId": 48185
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 635,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 11:32:18.977000000",
                "Performance": -0.017238,
                "MonthlyPerformanceId": 48186
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 636,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-01 16:17:16.957000000",
                "Performance": 0.003084,
                "MonthlyPerformanceId": 48187
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 637,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-14 11:15:33.110000000",
                "Performance": 0.009672,
                "MonthlyPerformanceId": 48188
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 645,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48189
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 647,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-28 16:04:26.423000000",
                "Performance": -0.001369,
                "MonthlyPerformanceId": 48190
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 648,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-28 16:04:45.783000000",
                "Performance": 0.005744,
                "MonthlyPerformanceId": 48191
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 649,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-28 16:04:39.900000000",
                "Performance": 0.004633,
                "MonthlyPerformanceId": 48192
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 673,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-05-02 16:17:04.980000000",
                "Performance": 0.019359,
                "MonthlyPerformanceId": 48193
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 682,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-04-14 11:18:18.747000000",
                "Performance": 0.009575,
                "MonthlyPerformanceId": 48194
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 702,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48195
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 714,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-05-02 16:17:04.990000000",
                "Performance": 0.009003,
                "MonthlyPerformanceId": 48196
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 719,
                "dDate": "2022-03-31 00:00:00",
                "ModifiedDateTime": "2022-05-02 16:38:20.663000000",
                "Performance": 0.009672,
                "MonthlyPerformanceId": 48197
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 305,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:05",
                "Performance": -0.004661,
                "MonthlyPerformanceId": 48198
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 306,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:05",
                "Performance": -0.004369,
                "MonthlyPerformanceId": 48199
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 372,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:06",
                "Performance": -0.000275,
                "MonthlyPerformanceId": 48200
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 373,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:06",
                "Performance": -0.000433,
                "MonthlyPerformanceId": 48201
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 485,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:06",
                "Performance": -0.000219,
                "MonthlyPerformanceId": 48202
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 486,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:06",
                "Performance": -0.000582,
                "MonthlyPerformanceId": 48203
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 449,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:06",
                "Performance": -0.000479,
                "MonthlyPerformanceId": 48204
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 450,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:06",
                "Performance": -0.000642,
                "MonthlyPerformanceId": 48205
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 445,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:06",
                "Performance": -0.005071,
                "MonthlyPerformanceId": 48206
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 446,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:06",
                "Performance": -0.004781,
                "MonthlyPerformanceId": 48207
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 460,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:06",
                "Performance": 0.000244,
                "MonthlyPerformanceId": 48208
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 461,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:06",
                "Performance": -0.000082,
                "MonthlyPerformanceId": 48209
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 470,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:06",
                "Performance": 0.001577,
                "MonthlyPerformanceId": 48210
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 471,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:06",
                "Performance": 0.001949,
                "MonthlyPerformanceId": 48211
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 321,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:06",
                "Performance": -0.000193,
                "MonthlyPerformanceId": 48212
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 322,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:06",
                "Performance": -0.000621,
                "MonthlyPerformanceId": 48213
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 319,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:07",
                "Performance": -0.000672,
                "MonthlyPerformanceId": 48214
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 320,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:07",
                "Performance": -0.000621,
                "MonthlyPerformanceId": 48215
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 397,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:07",
                "Performance": 0.000562,
                "MonthlyPerformanceId": 48216
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 398,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:07",
                "Performance": 0.000444,
                "MonthlyPerformanceId": 48217
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 462,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:07",
                "Performance": -0.049595,
                "MonthlyPerformanceId": 48218
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 463,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:07",
                "Performance": -0.049942,
                "MonthlyPerformanceId": 48219
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 399,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:07",
                "Performance": -0.000470,
                "MonthlyPerformanceId": 48220
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 400,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:07",
                "Performance": -0.000671,
                "MonthlyPerformanceId": 48221
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 543,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:08",
                "Performance": -0.049595,
                "MonthlyPerformanceId": 48222
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 544,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:08",
                "Performance": -0.049501,
                "MonthlyPerformanceId": 48223
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 545,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:08",
                "Performance": -0.002509,
                "MonthlyPerformanceId": 48224
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 546,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:08",
                "Performance": -0.002527,
                "MonthlyPerformanceId": 48225
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 474,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:08",
                "Performance": -0.000268,
                "MonthlyPerformanceId": 48226
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 475,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:08",
                "Performance": 0.000045,
                "MonthlyPerformanceId": 48227
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 455,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:08",
                "Performance": 0.001318,
                "MonthlyPerformanceId": 48228
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 456,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:08",
                "Performance": 0.001735,
                "MonthlyPerformanceId": 48229
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 569,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:08",
                "Performance": 0.003712,
                "MonthlyPerformanceId": 48230
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 570,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:08",
                "Performance": 0.004224,
                "MonthlyPerformanceId": 48231
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 447,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:08",
                "Performance": -0.000161,
                "MonthlyPerformanceId": 48232
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 448,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:08",
                "Performance": -0.000367,
                "MonthlyPerformanceId": 48233
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 483,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:08",
                "Performance": -0.000220,
                "MonthlyPerformanceId": 48234
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 484,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:08",
                "Performance": -0.000574,
                "MonthlyPerformanceId": 48235
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 406,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:09",
                "Performance": -0.000462,
                "MonthlyPerformanceId": 48236
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 407,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:09",
                "Performance": -0.000746,
                "MonthlyPerformanceId": 48237
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 307,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:09",
                "Performance": -0.002974,
                "MonthlyPerformanceId": 48238
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 308,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:09",
                "Performance": -0.003122,
                "MonthlyPerformanceId": 48239
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 408,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:09",
                "Performance": -0.000217,
                "MonthlyPerformanceId": 48240
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 409,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:09",
                "Performance": -0.000621,
                "MonthlyPerformanceId": 48241
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 487,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:09",
                "Performance": -0.000214,
                "MonthlyPerformanceId": 48242
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 488,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:09",
                "Performance": -0.000618,
                "MonthlyPerformanceId": 48243
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 489,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:09",
                "Performance": 0.000440,
                "MonthlyPerformanceId": 48244
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 490,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:09",
                "Performance": 0.000219,
                "MonthlyPerformanceId": 48245
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 423,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:09",
                "Performance": 0.000151,
                "MonthlyPerformanceId": 48246
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 424,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:09",
                "Performance": -0.000006,
                "MonthlyPerformanceId": 48247
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 317,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:09",
                "Performance": -0.000649,
                "MonthlyPerformanceId": 48248
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 318,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:09",
                "Performance": -0.000323,
                "MonthlyPerformanceId": 48249
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 472,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:10",
                "Performance": -0.000267,
                "MonthlyPerformanceId": 48250
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 473,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:10",
                "Performance": 0.000045,
                "MonthlyPerformanceId": 48251
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 468,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:10",
                "Performance": -0.000268,
                "MonthlyPerformanceId": 48252
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 469,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:10",
                "Performance": 0.000042,
                "MonthlyPerformanceId": 48253
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 309,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:10",
                "Performance": -0.000217,
                "MonthlyPerformanceId": 48254
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 310,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:10",
                "Performance": -0.000621,
                "MonthlyPerformanceId": 48255
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 441,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:10",
                "Performance": -0.019195,
                "MonthlyPerformanceId": 48256
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 442,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:10",
                "Performance": 0.002151,
                "MonthlyPerformanceId": 48257
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 443,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:10",
                "Performance": -0.003154,
                "MonthlyPerformanceId": 48258
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 444,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:10",
                "Performance": 0.000841,
                "MonthlyPerformanceId": 48259
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 478,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:10",
                "Performance": 0.001157,
                "MonthlyPerformanceId": 48260
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 479,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:10",
                "Performance": 0.000685,
                "MonthlyPerformanceId": 48261
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 571,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:11",
                "Performance": 0.003712,
                "MonthlyPerformanceId": 48262
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 572,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:11",
                "Performance": 0.004224,
                "MonthlyPerformanceId": 48263
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 476,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:11",
                "Performance": -0.000211,
                "MonthlyPerformanceId": 48264
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 477,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:11",
                "Performance": -0.000547,
                "MonthlyPerformanceId": 48265
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 313,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:11",
                "Performance": 0.001254,
                "MonthlyPerformanceId": 48266
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 314,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:11",
                "Performance": 0.001470,
                "MonthlyPerformanceId": 48267
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 374,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:11",
                "Performance": -0.001983,
                "MonthlyPerformanceId": 48268
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 375,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:11",
                "Performance": -0.001680,
                "MonthlyPerformanceId": 48269
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 376,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:11",
                "Performance": -0.003677,
                "MonthlyPerformanceId": 48270
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 377,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:11",
                "Performance": -0.003445,
                "MonthlyPerformanceId": 48271
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 561,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:11",
                "Performance": 0.001813,
                "MonthlyPerformanceId": 48272
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 562,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:11",
                "Performance": 0.002054,
                "MonthlyPerformanceId": 48273
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 557,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:11",
                "Performance": 0.001889,
                "MonthlyPerformanceId": 48274
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 558,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:11",
                "Performance": 0.002140,
                "MonthlyPerformanceId": 48275
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 559,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:12",
                "Performance": 0.001817,
                "MonthlyPerformanceId": 48276
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 560,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:12",
                "Performance": 0.002058,
                "MonthlyPerformanceId": 48277
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 299,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:12",
                "Performance": -0.000256,
                "MonthlyPerformanceId": 48278
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 300,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:12",
                "Performance": -0.000660,
                "MonthlyPerformanceId": 48279
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 439,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:12",
                "Performance": -0.001120,
                "MonthlyPerformanceId": 48280
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 440,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:12",
                "Performance": -0.000949,
                "MonthlyPerformanceId": 48281
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 573,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:12",
                "Performance": 0.003712,
                "MonthlyPerformanceId": 48282
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 574,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:12",
                "Performance": 0.004224,
                "MonthlyPerformanceId": 48283
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 458,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:12",
                "Performance": 0.000520,
                "MonthlyPerformanceId": 48284
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 459,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:12",
                "Performance": 0.000172,
                "MonthlyPerformanceId": 48285
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 315,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:12",
                "Performance": -0.000216,
                "MonthlyPerformanceId": 48286
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 316,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 13:26:12",
                "Performance": -0.000621,
                "MonthlyPerformanceId": 48287
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 679,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:18",
                "Performance": -0.013165,
                "MonthlyPerformanceId": 48288
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 680,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:18",
                "Performance": -0.013998,
                "MonthlyPerformanceId": 48289
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 205,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-24 17:03:28.343000000",
                "Performance": -0.003360,
                "MonthlyPerformanceId": 48290
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 206,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-24 17:03:35.450000000",
                "Performance": -0.003935,
                "MonthlyPerformanceId": 48291
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 291,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-24 16:38:12.400000000",
                "Performance": -0.009068,
                "MonthlyPerformanceId": 48292
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 292,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-24 16:37:56.540000000",
                "Performance": -0.009866,
                "MonthlyPerformanceId": 48293
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 553,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:21",
                "Performance": -0.002269,
                "MonthlyPerformanceId": 48294
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 554,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:21",
                "Performance": -0.003082,
                "MonthlyPerformanceId": 48295
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 580,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:22",
                "Performance": -0.024876,
                "MonthlyPerformanceId": 48296
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 581,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:22",
                "Performance": -0.024876,
                "MonthlyPerformanceId": 48297
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 643,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 14:20:38.603000000",
                "Performance": -0.009803,
                "MonthlyPerformanceId": 48298
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 644,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 14:20:38.620000000",
                "Performance": -0.010839,
                "MonthlyPerformanceId": 48299
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 646,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 14:20:38.630000000",
                "Performance": -0.004564,
                "MonthlyPerformanceId": 48300
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 651,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 14:20:38.643000000",
                "Performance": 0.009672,
                "MonthlyPerformanceId": 48301
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 652,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 14:20:38.653000000",
                "Performance": 0.007658,
                "MonthlyPerformanceId": 48302
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 656,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 14:20:38.663000000",
                "Performance": -0.061067,
                "MonthlyPerformanceId": 48303
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 657,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 14:20:38.673000000",
                "Performance": -0.062193,
                "MonthlyPerformanceId": 48304
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 692,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 14:20:38.683000000",
                "Performance": 0.013148,
                "MonthlyPerformanceId": 48305
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 693,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 14:20:38.693000000",
                "Performance": 0.009205,
                "MonthlyPerformanceId": 48306
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 704,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 14:20:38.703000000",
                "Performance": -0.029339,
                "MonthlyPerformanceId": 48307
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 707,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 14:20:38.713000000",
                "Performance": -0.023037,
                "MonthlyPerformanceId": 48308
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 705,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 14:20:38.723000000",
                "Performance": -0.072388,
                "MonthlyPerformanceId": 48309
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 708,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 14:20:38.737000000",
                "Performance": -0.072626,
                "MonthlyPerformanceId": 48310
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 706,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 14:20:38.747000000",
                "Performance": 0.114657,
                "MonthlyPerformanceId": 48311
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 709,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 14:20:38.763000000",
                "Performance": 0.114420,
                "MonthlyPerformanceId": 48312
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 710,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 14:20:38.780000000",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48313
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 711,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 14:20:38.790000000",
                "Performance": -0.000788,
                "MonthlyPerformanceId": 48314
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 725,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:23",
                "Performance": -0.063580,
                "MonthlyPerformanceId": 48315
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 541,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:23",
                "Performance": -0.008726,
                "MonthlyPerformanceId": 48316
            },
            {
                "Final": "True",
                "ModifiedUserId": "ngoldberg",
                "IndexID": 641,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 10:30:37.233000000",
                "Performance": 0.000034,
                "MonthlyPerformanceId": 48317
            },
            {
                "Final": "True",
                "ModifiedUserId": "ngoldberg",
                "IndexID": 642,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 10:30:37.247000000",
                "Performance": -0.000763,
                "MonthlyPerformanceId": 48318
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 603,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:23",
                "Performance": -0.000064,
                "MonthlyPerformanceId": 48319
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 604,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:23",
                "Performance": -0.001314,
                "MonthlyPerformanceId": 48320
            },
            {
                "Final": "True",
                "ModifiedUserId": "ngoldberg",
                "IndexID": 166,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 10:40:07.943000000",
                "Performance": -0.006998,
                "MonthlyPerformanceId": 48321
            },
            {
                "Final": "True",
                "ModifiedUserId": "ngoldberg",
                "IndexID": 167,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 10:40:07.953000000",
                "Performance": -0.008262,
                "MonthlyPerformanceId": 48322
            },
            {
                "Final": "True",
                "ModifiedUserId": "ngoldberg",
                "IndexID": 381,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 10:38:52.290000000",
                "Performance": -0.012126,
                "MonthlyPerformanceId": 48323
            },
            {
                "Final": "True",
                "ModifiedUserId": "ngoldberg",
                "IndexID": 382,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 10:38:52.303000000",
                "Performance": -0.013280,
                "MonthlyPerformanceId": 48324
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 389,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-06-03 08:44:16.703000000",
                "Performance": -0.023010,
                "MonthlyPerformanceId": 48325
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 390,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-06-03 08:44:16.703000000",
                "Performance": -0.023646,
                "MonthlyPerformanceId": 48326
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 385,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-06-03 08:44:16.700000000",
                "Performance": -0.002768,
                "MonthlyPerformanceId": 48327
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 386,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-06-03 08:44:16.700000000",
                "Performance": -0.004022,
                "MonthlyPerformanceId": 48328
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 387,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-06-03 08:44:16.703000000",
                "Performance": -0.035434,
                "MonthlyPerformanceId": 48329
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 388,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-06-03 08:44:16.700000000",
                "Performance": -0.035692,
                "MonthlyPerformanceId": 48330
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 578,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-11 16:31:21.880000000",
                "Performance": -0.061991,
                "MonthlyPerformanceId": 48331
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 579,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-11 16:31:13.877000000",
                "Performance": -0.062622,
                "MonthlyPerformanceId": 48332
            },
            {
                "Final": "True",
                "ModifiedUserId": "ngoldberg",
                "IndexID": 653,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 10:34:06.263000000",
                "Performance": -0.024681,
                "MonthlyPerformanceId": 48333
            },
            {
                "Final": "True",
                "ModifiedUserId": "ngoldberg",
                "IndexID": 654,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 10:34:06.273000000",
                "Performance": -0.025117,
                "MonthlyPerformanceId": 48334
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 183,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:25",
                "Performance": -0.035579,
                "MonthlyPerformanceId": 48335
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 184,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:25",
                "Performance": -0.036204,
                "MonthlyPerformanceId": 48336
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 593,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:28",
                "Performance": -0.020390,
                "MonthlyPerformanceId": 48337
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 594,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:25",
                "Performance": -0.020868,
                "MonthlyPerformanceId": 48338
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 587,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-16 08:31:42.827000000",
                "Performance": -0.032752,
                "MonthlyPerformanceId": 48339
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 588,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-16 08:31:36.517000000",
                "Performance": -0.032995,
                "MonthlyPerformanceId": 48340
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 589,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:25",
                "Performance": -0.008763,
                "MonthlyPerformanceId": 48341
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 590,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:25",
                "Performance": -0.009055,
                "MonthlyPerformanceId": 48342
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 276,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:25",
                "Performance": -0.003108,
                "MonthlyPerformanceId": 48343
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 277,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:25",
                "Performance": -0.003541,
                "MonthlyPerformanceId": 48344
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 359,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:26",
                "Performance": -0.020848,
                "MonthlyPerformanceId": 48345
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 360,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:26",
                "Performance": -0.021531,
                "MonthlyPerformanceId": 48346
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 361,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:26",
                "Performance": -0.021040,
                "MonthlyPerformanceId": 48347
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 362,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:26",
                "Performance": -0.021723,
                "MonthlyPerformanceId": 48348
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 410,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:27",
                "Performance": -0.021451,
                "MonthlyPerformanceId": 48349
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 411,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:27",
                "Performance": -0.022100,
                "MonthlyPerformanceId": 48350
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 464,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:27",
                "Performance": 0.008045,
                "MonthlyPerformanceId": 48351
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 465,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:27",
                "Performance": 0.005707,
                "MonthlyPerformanceId": 48352
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 466,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:27",
                "Performance": 0.008045,
                "MonthlyPerformanceId": 48353
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 467,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:27",
                "Performance": 0.005707,
                "MonthlyPerformanceId": 48354
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 674,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:27",
                "Performance": 0.008804,
                "MonthlyPerformanceId": 48355
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 675,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:27",
                "Performance": 0.007303,
                "MonthlyPerformanceId": 48356
            },
            {
                "Final": "True",
                "ModifiedUserId": "ngoldberg",
                "IndexID": 415,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 10:41:49.823000000",
                "Performance": 0.005798,
                "MonthlyPerformanceId": 48357
            },
            {
                "Final": "True",
                "ModifiedUserId": "ngoldberg",
                "IndexID": 416,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 10:41:49.833000000",
                "Performance": 0.004906,
                "MonthlyPerformanceId": 48358
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 257,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:27",
                "Performance": -0.000013,
                "MonthlyPerformanceId": 48359
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 412,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:27",
                "Performance": 0.000002,
                "MonthlyPerformanceId": 48360
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 431,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:27",
                "Performance": 0.000009,
                "MonthlyPerformanceId": 48361
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 582,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-12 15:14:21.717000000",
                "Performance": 0.010204,
                "MonthlyPerformanceId": 48362
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 681,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-12 15:13:41.930000000",
                "Performance": 0.006229,
                "MonthlyPerformanceId": 48363
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 638,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-12 15:14:45.873000000",
                "Performance": 0.010275,
                "MonthlyPerformanceId": 48364
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 639,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-12 15:14:41.347000000",
                "Performance": 0.009122,
                "MonthlyPerformanceId": 48365
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 197,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 08:34:18.440000000",
                "Performance": -0.000026,
                "MonthlyPerformanceId": 48366
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 198,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 08:34:09.273000000",
                "Performance": -0.000484,
                "MonthlyPerformanceId": 48367
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 601,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:28",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48368
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 602,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:28",
                "Performance": -0.000521,
                "MonthlyPerformanceId": 48369
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 555,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-16 11:53:58.837000000",
                "Performance": -0.000060,
                "MonthlyPerformanceId": 48370
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 567,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:28",
                "Performance": 0.003872,
                "MonthlyPerformanceId": 48371
            },
            {
                "Final": "True",
                "ModifiedUserId": "ngoldberg",
                "IndexID": 609,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 10:36:58.797000000",
                "Performance": 0.024908,
                "MonthlyPerformanceId": 48372
            },
            {
                "Final": "True",
                "ModifiedUserId": "ngoldberg",
                "IndexID": 611,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 10:36:58.807000000",
                "Performance": 0.024493,
                "MonthlyPerformanceId": 48373
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 207,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-24 17:03:18.770000000",
                "Performance": -0.007391,
                "MonthlyPerformanceId": 48374
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 247,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 15:24:04.793000000",
                "Performance": -0.000142,
                "MonthlyPerformanceId": 48375
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 255,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 15:23:32.910000000",
                "Performance": -0.046986,
                "MonthlyPerformanceId": 48376
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 256,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 15:23:43.167000000",
                "Performance": -0.000109,
                "MonthlyPerformanceId": 48377
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 396,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-24 17:02:56.383000000",
                "Performance": -0.057359,
                "MonthlyPerformanceId": 48378
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 595,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-24 17:02:07.703000000",
                "Performance": -0.060373,
                "MonthlyPerformanceId": 48379
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 329,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:22",
                "Performance": -0.000450,
                "MonthlyPerformanceId": 48380
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 433,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:22",
                "Performance": -0.047866,
                "MonthlyPerformanceId": 48381
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 395,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:23",
                "Performance": -0.000062,
                "MonthlyPerformanceId": 48382
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 575,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:23",
                "Performance": 0.003732,
                "MonthlyPerformanceId": 48383
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 629,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:25",
                "Performance": -0.036540,
                "MonthlyPerformanceId": 48384
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 591,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:28",
                "Performance": -0.062338,
                "MonthlyPerformanceId": 48385
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 592,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:28",
                "Performance": -0.062815,
                "MonthlyPerformanceId": 48386
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 599,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:28",
                "Performance": 0.035538,
                "MonthlyPerformanceId": 48387
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 600,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:28",
                "Performance": 0.035246,
                "MonthlyPerformanceId": 48388
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 481,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-24 17:02:48.730000000",
                "Performance": 0.007732,
                "MonthlyPerformanceId": 48389
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 417,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:28",
                "Performance": -0.000009,
                "MonthlyPerformanceId": 48390
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 203,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:28",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48391
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 204,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:28",
                "Performance": -0.000800,
                "MonthlyPerformanceId": 48392
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 631,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:28",
                "Performance": 0.000482,
                "MonthlyPerformanceId": 48393
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 274,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:28",
                "Performance": -0.023003,
                "MonthlyPerformanceId": 48394
            },
            {
                "Final": "False",
                "ModifiedUserId": "MHarris",
                "IndexID": 275,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-17 09:43:28",
                "Performance": -0.023436,
                "MonthlyPerformanceId": 48395
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 684,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 14:57:01.943000000",
                "Performance": -0.025270,
                "MonthlyPerformanceId": 48396
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 685,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 14:57:01.957000000",
                "Performance": -0.025616,
                "MonthlyPerformanceId": 48397
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 686,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 14:56:44.507000000",
                "Performance": -0.015122,
                "MonthlyPerformanceId": 48398
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 687,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 14:56:44.520000000",
                "Performance": -0.015357,
                "MonthlyPerformanceId": 48399
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 688,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 14:58:47.133000000",
                "Performance": -0.040337,
                "MonthlyPerformanceId": 48400
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 689,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 14:58:47.147000000",
                "Performance": -0.040350,
                "MonthlyPerformanceId": 48401
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 690,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 14:58:32.727000000",
                "Performance": -0.019533,
                "MonthlyPerformanceId": 48402
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 691,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-25 14:58:32.740000000",
                "Performance": -0.019545,
                "MonthlyPerformanceId": 48403
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 696,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-06-03 08:44:16.700000000",
                "Performance": -0.035434,
                "MonthlyPerformanceId": 48404
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 697,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-06-03 08:44:16.697000000",
                "Performance": -0.035692,
                "MonthlyPerformanceId": 48405
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 694,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-06-03 08:44:16.697000000",
                "Performance": -0.023010,
                "MonthlyPerformanceId": 48406
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 695,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-06-03 08:44:16.697000000",
                "Performance": -0.023646,
                "MonthlyPerformanceId": 48407
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 3,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:38.937000000",
                "Performance": -0.071187,
                "MonthlyPerformanceId": 48408
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 4,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:38.937000000",
                "Performance": -0.057431,
                "MonthlyPerformanceId": 48409
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 5,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:38.940000000",
                "Performance": -0.132617,
                "MonthlyPerformanceId": 48410
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 6,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:38.940000000",
                "Performance": -0.087957,
                "MonthlyPerformanceId": 48411
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 7,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:38.940000000",
                "Performance": -0.049055,
                "MonthlyPerformanceId": 48412
            },
            {
                "Final": "True",
                "ModifiedUserId": "MHarris",
                "IndexID": 8,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-11 11:55:35.343000000",
                "Performance": 0.000141,
                "MonthlyPerformanceId": 48413
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 9,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:39.037000000",
                "Performance": 0.013349,
                "MonthlyPerformanceId": 48414
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 16,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:38.940000000",
                "Performance": -0.057454,
                "MonthlyPerformanceId": 48415
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 17,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:38.943000000",
                "Performance": -0.067807,
                "MonthlyPerformanceId": 48416
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 18,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:38.950000000",
                "Performance": -0.037948,
                "MonthlyPerformanceId": 48417
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 23,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:39.040000000",
                "Performance": 0.003200,
                "MonthlyPerformanceId": 48418
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 36,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:38.950000000",
                "Performance": -0.054803,
                "MonthlyPerformanceId": 48419
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 37,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:38.947000000",
                "Performance": -0.048542,
                "MonthlyPerformanceId": 48420
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 39,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:38.947000000",
                "Performance": -0.022421,
                "MonthlyPerformanceId": 48421
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 48,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48422
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 49,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48423
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 50,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:38.947000000",
                "Performance": -0.055475,
                "MonthlyPerformanceId": 48424
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 51,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:38.950000000",
                "Performance": -0.055627,
                "MonthlyPerformanceId": 48425
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 57,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:38.950000000",
                "Performance": 0.624514,
                "MonthlyPerformanceId": 48426
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 90,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:38.943000000",
                "Performance": -0.007049,
                "MonthlyPerformanceId": 48427
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 99,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:38.963000000",
                "Performance": -0.060262,
                "MonthlyPerformanceId": 48428
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 101,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:38.953000000",
                "Performance": -0.021798,
                "MonthlyPerformanceId": 48429
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 102,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:38.960000000",
                "Performance": -0.017023,
                "MonthlyPerformanceId": 48430
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 103,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:38.983000000",
                "Performance": -0.038471,
                "MonthlyPerformanceId": 48431
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 123,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:39",
                "Performance": -0.021375,
                "MonthlyPerformanceId": 48432
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 124,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:39.007000000",
                "Performance": -0.020603,
                "MonthlyPerformanceId": 48433
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 125,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:38.943000000",
                "Performance": 0.019020,
                "MonthlyPerformanceId": 48434
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 138,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:38.990000000",
                "Performance": -0.021838,
                "MonthlyPerformanceId": 48435
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 139,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:38.993000000",
                "Performance": -0.014331,
                "MonthlyPerformanceId": 48436
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 140,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:38.997000000",
                "Performance": -0.013474,
                "MonthlyPerformanceId": 48437
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 141,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:39.010000000",
                "Performance": -0.055914,
                "MonthlyPerformanceId": 48438
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 153,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:39.050000000",
                "Performance": 0.005049,
                "MonthlyPerformanceId": 48439
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 190,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:38.943000000",
                "Performance": -0.012869,
                "MonthlyPerformanceId": 48440
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 209,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:38.950000000",
                "Performance": -0.054788,
                "MonthlyPerformanceId": 48441
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 222,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48442
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 223,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48443
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 224,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-06-01 15:36:19.467000000",
                "Performance": -0.035579,
                "MonthlyPerformanceId": 48444
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 225,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-06-01 15:36:19.497000000",
                "Performance": -0.036204,
                "MonthlyPerformanceId": 48445
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 227,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:39.057000000",
                "Performance": -0.099109,
                "MonthlyPerformanceId": 48446
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 228,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:39.053000000",
                "Performance": -0.043922,
                "MonthlyPerformanceId": 48447
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 229,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 16:15:36.637000000",
                "Performance": -0.023003,
                "MonthlyPerformanceId": 48448
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 230,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 16:15:36.643000000",
                "Performance": -0.023586,
                "MonthlyPerformanceId": 48449
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 231,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 16:15:36.653000000",
                "Performance": -0.021031,
                "MonthlyPerformanceId": 48450
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 232,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 16:15:36.660000000",
                "Performance": -0.021823,
                "MonthlyPerformanceId": 48451
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 233,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48452
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 234,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48453
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 237,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:39.067000000",
                "Performance": -0.073457,
                "MonthlyPerformanceId": 48454
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 238,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:39.070000000",
                "Performance": -0.068624,
                "MonthlyPerformanceId": 48455
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 239,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:39.073000000",
                "Performance": -0.118221,
                "MonthlyPerformanceId": 48456
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 240,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:39.060000000",
                "Performance": -0.039625,
                "MonthlyPerformanceId": 48457
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 241,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48458
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 242,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48459
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 262,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "2022-05-02 10:34:38.980000000",
                "Performance": -0.014492,
                "MonthlyPerformanceId": 48460
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 278,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "",
                "Performance": -0.001878,
                "MonthlyPerformanceId": 48461
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 284,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48462
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 285,
                "dDate": "2022-04-30 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48463
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 569,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:01",
                "Performance": 0.004453,
                "MonthlyPerformanceId": 48576
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 570,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:01",
                "Performance": 0.003557,
                "MonthlyPerformanceId": 48577
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 447,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:01",
                "Performance": -0.000024,
                "MonthlyPerformanceId": 48578
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 448,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:01",
                "Performance": -0.000448,
                "MonthlyPerformanceId": 48579
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 483,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:01",
                "Performance": -0.000270,
                "MonthlyPerformanceId": 48580
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 484,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:01",
                "Performance": -0.000636,
                "MonthlyPerformanceId": 48581
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 406,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:01",
                "Performance": -0.000362,
                "MonthlyPerformanceId": 48582
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 407,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:01",
                "Performance": -0.000786,
                "MonthlyPerformanceId": 48583
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 307,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:01",
                "Performance": -0.002778,
                "MonthlyPerformanceId": 48584
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 308,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:01",
                "Performance": -0.003043,
                "MonthlyPerformanceId": 48585
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 408,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:01",
                "Performance": -0.000248,
                "MonthlyPerformanceId": 48586
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 409,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:01",
                "Performance": -0.000666,
                "MonthlyPerformanceId": 48587
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 487,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:01",
                "Performance": -0.000244,
                "MonthlyPerformanceId": 48588
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 488,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:01",
                "Performance": -0.000662,
                "MonthlyPerformanceId": 48589
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 489,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:01",
                "Performance": 0.000524,
                "MonthlyPerformanceId": 48590
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 490,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:01",
                "Performance": 0.000076,
                "MonthlyPerformanceId": 48591
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 423,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:02",
                "Performance": 0.000270,
                "MonthlyPerformanceId": 48592
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 424,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:02",
                "Performance": -0.000167,
                "MonthlyPerformanceId": 48593
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 317,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:02",
                "Performance": -0.000196,
                "MonthlyPerformanceId": 48594
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 318,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:02",
                "Performance": -0.000588,
                "MonthlyPerformanceId": 48595
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 472,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:02",
                "Performance": -0.000450,
                "MonthlyPerformanceId": 48596
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 473,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:02",
                "Performance": -0.000449,
                "MonthlyPerformanceId": 48597
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 468,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:02",
                "Performance": -0.000450,
                "MonthlyPerformanceId": 48598
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 469,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:02",
                "Performance": -0.000447,
                "MonthlyPerformanceId": 48599
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 309,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:02",
                "Performance": -0.000247,
                "MonthlyPerformanceId": 48600
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 310,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:02",
                "Performance": -0.000666,
                "MonthlyPerformanceId": 48601
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 441,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:02",
                "Performance": -0.017304,
                "MonthlyPerformanceId": 48602
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 442,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:02",
                "Performance": 0.001603,
                "MonthlyPerformanceId": 48603
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 443,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:02",
                "Performance": -0.002796,
                "MonthlyPerformanceId": 48604
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 444,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:02",
                "Performance": 0.000335,
                "MonthlyPerformanceId": 48605
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 679,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:47",
                "Performance": -0.017129,
                "MonthlyPerformanceId": 48634
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 680,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:47",
                "Performance": -0.017978,
                "MonthlyPerformanceId": 48635
            },
            {
                "Final": "False",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 205,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-08 14:42:03.637000000",
                "Performance": -0.030741,
                "MonthlyPerformanceId": 48636
            },
            {
                "Final": "False",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 206,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-13 15:16:30.427000000",
                "Performance": -0.029809,
                "MonthlyPerformanceId": 48637
            },
            {
                "Final": "False",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 291,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-08 14:47:46.833000000",
                "Performance": -0.036908,
                "MonthlyPerformanceId": 48638
            },
            {
                "Final": "False",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 292,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-08 14:47:53.223000000",
                "Performance": -0.037731,
                "MonthlyPerformanceId": 48639
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 553,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:51",
                "Performance": -0.006035,
                "MonthlyPerformanceId": 48640
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 554,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:51",
                "Performance": -0.006847,
                "MonthlyPerformanceId": 48641
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 580,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:51",
                "Performance": -0.029819,
                "MonthlyPerformanceId": 48642
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 581,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:51",
                "Performance": -0.029819,
                "MonthlyPerformanceId": 48643
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 643,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:51",
                "Performance": -0.008880,
                "MonthlyPerformanceId": 48644
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 644,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:51",
                "Performance": -0.009525,
                "MonthlyPerformanceId": 48645
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 646,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:51",
                "Performance": -0.007246,
                "MonthlyPerformanceId": 48646
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 651,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:51",
                "Performance": 0.010411,
                "MonthlyPerformanceId": 48647
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 652,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:51",
                "Performance": 0.008078,
                "MonthlyPerformanceId": 48648
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 656,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:52",
                "Performance": -0.053337,
                "MonthlyPerformanceId": 48649
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 657,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:52",
                "Performance": -0.054212,
                "MonthlyPerformanceId": 48650
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 692,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:52",
                "Performance": 0.013639,
                "MonthlyPerformanceId": 48651
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 693,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:52",
                "Performance": 0.010821,
                "MonthlyPerformanceId": 48652
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 704,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:52",
                "Performance": 0.047051,
                "MonthlyPerformanceId": 48653
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 707,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:52",
                "Performance": 0.036417,
                "MonthlyPerformanceId": 48654
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 705,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:52",
                "Performance": -0.122054,
                "MonthlyPerformanceId": 48655
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 708,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:52",
                "Performance": -0.122929,
                "MonthlyPerformanceId": 48656
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 706,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:52",
                "Performance": -0.219048,
                "MonthlyPerformanceId": 48657
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 709,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:52",
                "Performance": -0.219923,
                "MonthlyPerformanceId": 48658
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 710,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:52",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48659
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 711,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:52",
                "Performance": -0.000875,
                "MonthlyPerformanceId": 48660
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 725,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:52",
                "Performance": -0.049688,
                "MonthlyPerformanceId": 48661
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 541,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:52",
                "Performance": -0.015591,
                "MonthlyPerformanceId": 48662
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 641,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:52",
                "Performance": 0.000071,
                "MonthlyPerformanceId": 48663
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 642,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:52",
                "Performance": -0.001179,
                "MonthlyPerformanceId": 48664
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 603,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:52",
                "Performance": -0.000075,
                "MonthlyPerformanceId": 48665
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 604,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:52",
                "Performance": -0.001325,
                "MonthlyPerformanceId": 48666
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 166,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:53",
                "Performance": -0.000700,
                "MonthlyPerformanceId": 48667
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 167,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:53",
                "Performance": -0.002600,
                "MonthlyPerformanceId": 48668
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 381,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:53",
                "Performance": -0.034913,
                "MonthlyPerformanceId": 48669
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 382,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:53",
                "Performance": -0.037163,
                "MonthlyPerformanceId": 48670
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 389,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-14 10:25:54.593000000",
                "Performance": -0.039980,
                "MonthlyPerformanceId": 48671
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 390,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-14 10:25:54.610000000",
                "Performance": -0.041025,
                "MonthlyPerformanceId": 48672
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 385,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-14 10:28:09.950000000",
                "Performance": -0.040662,
                "MonthlyPerformanceId": 48673
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 386,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-15 10:23:32.373000000",
                "Performance": -0.042777,
                "MonthlyPerformanceId": 48674
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 387,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-14 10:30:34.537000000",
                "Performance": -0.039512,
                "MonthlyPerformanceId": 48675
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 388,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-15 10:24:33.027000000",
                "Performance": -0.039855,
                "MonthlyPerformanceId": 48676
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 578,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:53",
                "Performance": -0.054119,
                "MonthlyPerformanceId": 48677
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 579,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:53",
                "Performance": -0.054744,
                "MonthlyPerformanceId": 48678
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 653,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:54",
                "Performance": -0.015062,
                "MonthlyPerformanceId": 48679
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 654,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:54",
                "Performance": -0.016335,
                "MonthlyPerformanceId": 48680
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 183,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:54",
                "Performance": -0.007588,
                "MonthlyPerformanceId": 48681
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 184,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:54",
                "Performance": -0.008213,
                "MonthlyPerformanceId": 48682
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 593,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:59",
                "Performance": -0.002257,
                "MonthlyPerformanceId": 48683
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 594,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:54",
                "Performance": -0.002734,
                "MonthlyPerformanceId": 48684
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 587,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-08 10:04:31.613000000",
                "Performance": -0.004698,
                "MonthlyPerformanceId": 48685
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 588,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-08 10:04:25.287000000",
                "Performance": -0.005339,
                "MonthlyPerformanceId": 48686
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 589,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:54",
                "Performance": -0.007418,
                "MonthlyPerformanceId": 48687
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 590,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:54",
                "Performance": -0.007710,
                "MonthlyPerformanceId": 48688
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 276,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:55",
                "Performance": -0.019300,
                "MonthlyPerformanceId": 48689
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 277,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:55",
                "Performance": -0.020634,
                "MonthlyPerformanceId": 48690
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 359,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:55",
                "Performance": -0.014604,
                "MonthlyPerformanceId": 48691
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 360,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:55",
                "Performance": -0.015288,
                "MonthlyPerformanceId": 48692
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 361,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:56",
                "Performance": -0.014443,
                "MonthlyPerformanceId": 48693
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 362,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:56",
                "Performance": -0.015126,
                "MonthlyPerformanceId": 48694
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 410,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:56",
                "Performance": -0.014284,
                "MonthlyPerformanceId": 48695
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 411,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:56",
                "Performance": -0.015000,
                "MonthlyPerformanceId": 48696
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 464,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:56",
                "Performance": -0.017057,
                "MonthlyPerformanceId": 48697
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 465,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:56",
                "Performance": -0.001649,
                "MonthlyPerformanceId": 48698
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 466,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:56",
                "Performance": -0.017057,
                "MonthlyPerformanceId": 48699
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 467,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:56",
                "Performance": -0.001649,
                "MonthlyPerformanceId": 48700
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 674,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:57",
                "Performance": 0.007560,
                "MonthlyPerformanceId": 48701
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 675,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:57",
                "Performance": 0.005651,
                "MonthlyPerformanceId": 48702
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 415,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:58",
                "Performance": -0.074611,
                "MonthlyPerformanceId": 48703
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 416,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:58",
                "Performance": -0.077461,
                "MonthlyPerformanceId": 48704
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 257,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:58",
                "Performance": 0.000004,
                "MonthlyPerformanceId": 48705
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 412,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:58",
                "Performance": -0.000002,
                "MonthlyPerformanceId": 48706
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 431,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:58",
                "Performance": -0.000004,
                "MonthlyPerformanceId": 48707
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 582,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-13 09:58:51.747000000",
                "Performance": 0.010146,
                "MonthlyPerformanceId": 48708
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 681,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:58",
                "Performance": 0.005850,
                "MonthlyPerformanceId": 48709
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 638,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-13 09:59:24.513000000",
                "Performance": 0.010217,
                "MonthlyPerformanceId": 48710
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 639,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-13 09:59:15.677000000",
                "Performance": 0.009179,
                "MonthlyPerformanceId": 48711
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 197,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-14 09:06:44.697000000",
                "Performance": -0.000026,
                "MonthlyPerformanceId": 48712
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 198,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-14 09:06:30.483000000",
                "Performance": -0.000729,
                "MonthlyPerformanceId": 48713
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 601,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:58",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48714
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 602,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:58",
                "Performance": -0.000521,
                "MonthlyPerformanceId": 48715
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 555,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-13 09:25:06.307000000",
                "Performance": -0.152752,
                "MonthlyPerformanceId": 48716
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 567,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:59",
                "Performance": 0.005278,
                "MonthlyPerformanceId": 48717
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 609,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:59",
                "Performance": 0.008694,
                "MonthlyPerformanceId": 48718
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 611,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:59",
                "Performance": 0.008694,
                "MonthlyPerformanceId": 48719
            },
            {
                "Final": "False",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 207,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-08 14:41:51.710000000",
                "Performance": -0.029443,
                "MonthlyPerformanceId": 48720
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 247,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-08 14:39:53.887000000",
                "Performance": -0.000245,
                "MonthlyPerformanceId": 48721
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 255,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-08 14:39:33.383000000",
                "Performance": 0.017032,
                "MonthlyPerformanceId": 48722
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 256,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:48",
                "Performance": -0.000571,
                "MonthlyPerformanceId": 48723
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 396,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:48",
                "Performance": 0.004917,
                "MonthlyPerformanceId": 48724
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 595,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:48",
                "Performance": -0.052348,
                "MonthlyPerformanceId": 48725
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 329,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:52",
                "Performance": -0.000465,
                "MonthlyPerformanceId": 48726
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 433,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:52",
                "Performance": -0.045802,
                "MonthlyPerformanceId": 48727
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 395,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:52",
                "Performance": -0.000086,
                "MonthlyPerformanceId": 48728
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 575,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:52",
                "Performance": 0.004760,
                "MonthlyPerformanceId": 48729
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 629,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:54",
                "Performance": -0.007812,
                "MonthlyPerformanceId": 48730
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 591,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:59",
                "Performance": -0.000142,
                "MonthlyPerformanceId": 48731
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 592,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:59",
                "Performance": -0.000619,
                "MonthlyPerformanceId": 48732
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 599,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:59",
                "Performance": -0.009505,
                "MonthlyPerformanceId": 48733
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 600,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:59",
                "Performance": -0.009797,
                "MonthlyPerformanceId": 48734
            },
            {
                "Final": "False",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 481,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-08 14:40:01.313000000",
                "Performance": -0.054148,
                "MonthlyPerformanceId": 48735
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 417,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:59",
                "Performance": 0.000002,
                "MonthlyPerformanceId": 48736
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 203,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:59",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48737
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 204,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:59",
                "Performance": -0.000800,
                "MonthlyPerformanceId": 48738
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 631,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:59",
                "Performance": 0.000498,
                "MonthlyPerformanceId": 48739
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 274,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:59",
                "Performance": -0.010055,
                "MonthlyPerformanceId": 48740
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 275,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:59",
                "Performance": -0.011389,
                "MonthlyPerformanceId": 48741
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 684,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-15 10:27:39.707000000",
                "Performance": -0.041753,
                "MonthlyPerformanceId": 48742
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 685,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-15 10:21:05.610000000",
                "Performance": -0.042833,
                "MonthlyPerformanceId": 48743
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 686,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-15 10:25:41.650000000",
                "Performance": -0.042003,
                "MonthlyPerformanceId": 48744
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 687,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-15 10:21:09.177000000",
                "Performance": -0.042833,
                "MonthlyPerformanceId": 48745
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 688,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-15 10:27:50.340000000",
                "Performance": -0.045824,
                "MonthlyPerformanceId": 48746
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 689,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-15 10:26:56.703000000",
                "Performance": -0.045837,
                "MonthlyPerformanceId": 48747
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 690,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-15 10:26:21.913000000",
                "Performance": -0.020555,
                "MonthlyPerformanceId": 48748
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 691,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-15 10:26:30.793000000",
                "Performance": -0.020568,
                "MonthlyPerformanceId": 48749
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 696,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-14 10:30:53.053000000",
                "Performance": -0.039512,
                "MonthlyPerformanceId": 48750
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 697,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-15 10:24:43.127000000",
                "Performance": -0.039855,
                "MonthlyPerformanceId": 48751
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 694,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-14 10:26:08.180000000",
                "Performance": -0.039980,
                "MonthlyPerformanceId": 48752
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 695,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-14 10:26:16.380000000",
                "Performance": -0.041025,
                "MonthlyPerformanceId": 48753
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 3,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:38:50.023000000",
                "Performance": 0.012446,
                "MonthlyPerformanceId": 48756
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 4,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:38:50.030000000",
                "Performance": -0.000200,
                "MonthlyPerformanceId": 48757
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 5,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:38:50.030000000",
                "Performance": -0.020532,
                "MonthlyPerformanceId": 48758
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 6,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:38:50.033000000",
                "Performance": 0.000053,
                "MonthlyPerformanceId": 48759
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 7,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:38:50.033000000",
                "Performance": 0.000391,
                "MonthlyPerformanceId": 48760
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 16,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:38:50.037000000",
                "Performance": 0.001375,
                "MonthlyPerformanceId": 48761
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 17,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:38:50.037000000",
                "Performance": 0.002050,
                "MonthlyPerformanceId": 48762
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 90,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:38:50.040000000",
                "Performance": -0.010952,
                "MonthlyPerformanceId": 48763
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 305,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:16:55",
                "Performance": -0.004400,
                "MonthlyPerformanceId": 48544
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 306,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:16:55",
                "Performance": -0.004392,
                "MonthlyPerformanceId": 48545
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 372,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:16:56",
                "Performance": -0.000172,
                "MonthlyPerformanceId": 48546
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 373,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:16:56",
                "Performance": -0.000567,
                "MonthlyPerformanceId": 48547
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 485,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:16:56",
                "Performance": -0.000265,
                "MonthlyPerformanceId": 48548
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 486,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:16:56",
                "Performance": -0.000640,
                "MonthlyPerformanceId": 48549
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 449,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:16:56",
                "Performance": -0.000355,
                "MonthlyPerformanceId": 48550
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 450,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:16:56",
                "Performance": -0.000666,
                "MonthlyPerformanceId": 48551
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 445,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:16:56",
                "Performance": -0.004770,
                "MonthlyPerformanceId": 48552
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 446,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:16:56",
                "Performance": -0.004762,
                "MonthlyPerformanceId": 48553
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 460,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:16:57",
                "Performance": 0.000308,
                "MonthlyPerformanceId": 48554
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 461,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:16:57",
                "Performance": -0.000202,
                "MonthlyPerformanceId": 48555
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 470,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:16:57",
                "Performance": 0.001825,
                "MonthlyPerformanceId": 48556
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 471,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:16:57",
                "Performance": 0.001410,
                "MonthlyPerformanceId": 48557
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 321,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:16:57",
                "Performance": -0.000220,
                "MonthlyPerformanceId": 48558
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 322,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:16:57",
                "Performance": -0.000666,
                "MonthlyPerformanceId": 48559
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 319,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:16:58",
                "Performance": -0.000735,
                "MonthlyPerformanceId": 48560
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 320,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:16:58",
                "Performance": -0.000666,
                "MonthlyPerformanceId": 48561
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 397,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:16:59",
                "Performance": 0.000644,
                "MonthlyPerformanceId": 48562
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 398,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:16:59",
                "Performance": 0.000257,
                "MonthlyPerformanceId": 48563
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 462,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:16:59",
                "Performance": -0.046831,
                "MonthlyPerformanceId": 48564
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 463,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:16:59",
                "Performance": -0.047077,
                "MonthlyPerformanceId": 48565
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 399,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:16:59",
                "Performance": -0.000357,
                "MonthlyPerformanceId": 48566
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 400,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:16:59",
                "Performance": -0.000765,
                "MonthlyPerformanceId": 48567
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 543,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:00",
                "Performance": -0.046831,
                "MonthlyPerformanceId": 48568
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 544,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:00",
                "Performance": -0.046702,
                "MonthlyPerformanceId": 48569
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 545,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:00",
                "Performance": -0.002461,
                "MonthlyPerformanceId": 48570
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 546,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:00",
                "Performance": -0.002478,
                "MonthlyPerformanceId": 48571
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 474,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:00",
                "Performance": -0.000450,
                "MonthlyPerformanceId": 48572
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 475,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:00",
                "Performance": -0.000449,
                "MonthlyPerformanceId": 48573
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 455,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:00",
                "Performance": 0.002259,
                "MonthlyPerformanceId": 48574
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 456,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:00",
                "Performance": 0.001405,
                "MonthlyPerformanceId": 48575
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 478,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:03",
                "Performance": 0.001461,
                "MonthlyPerformanceId": 48606
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 479,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:03",
                "Performance": 0.000510,
                "MonthlyPerformanceId": 48607
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 571,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:03",
                "Performance": 0.004453,
                "MonthlyPerformanceId": 48608
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 572,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:03",
                "Performance": 0.003557,
                "MonthlyPerformanceId": 48609
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 476,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:03",
                "Performance": -0.000241,
                "MonthlyPerformanceId": 48610
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 477,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:03",
                "Performance": -0.000570,
                "MonthlyPerformanceId": 48611
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 313,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:03",
                "Performance": 0.001593,
                "MonthlyPerformanceId": 48612
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 314,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:03",
                "Performance": 0.001141,
                "MonthlyPerformanceId": 48613
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 374,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:03",
                "Performance": -0.001662,
                "MonthlyPerformanceId": 48614
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 375,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:03",
                "Performance": -0.001875,
                "MonthlyPerformanceId": 48615
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 376,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:03",
                "Performance": -0.003397,
                "MonthlyPerformanceId": 48616
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 377,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:03",
                "Performance": -0.003521,
                "MonthlyPerformanceId": 48617
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 561,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:03",
                "Performance": 0.002115,
                "MonthlyPerformanceId": 48618
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 562,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:03",
                "Performance": 0.001654,
                "MonthlyPerformanceId": 48619
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 557,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:03",
                "Performance": 0.002210,
                "MonthlyPerformanceId": 48620
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 558,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:03",
                "Performance": 0.001731,
                "MonthlyPerformanceId": 48621
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 559,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:04",
                "Performance": 0.002120,
                "MonthlyPerformanceId": 48622
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 560,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:04",
                "Performance": 0.001658,
                "MonthlyPerformanceId": 48623
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 299,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:04",
                "Performance": -0.000283,
                "MonthlyPerformanceId": 48624
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 300,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:04",
                "Performance": -0.000701,
                "MonthlyPerformanceId": 48625
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 439,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:04",
                "Performance": -0.000552,
                "MonthlyPerformanceId": 48626
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 440,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:04",
                "Performance": -0.000993,
                "MonthlyPerformanceId": 48627
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 573,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:04",
                "Performance": 0.004453,
                "MonthlyPerformanceId": 48628
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 574,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:04",
                "Performance": 0.003558,
                "MonthlyPerformanceId": 48629
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 458,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:04",
                "Performance": 0.000650,
                "MonthlyPerformanceId": 48630
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 459,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:04",
                "Performance": 0.000021,
                "MonthlyPerformanceId": 48631
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 315,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:04",
                "Performance": -0.000247,
                "MonthlyPerformanceId": 48632
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 316,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:04",
                "Performance": -0.000666,
                "MonthlyPerformanceId": 48633
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 648,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-07 14:17:51",
                "Performance": -0.008120,
                "MonthlyPerformanceId": 48754
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 125,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:38:50.040000000",
                "Performance": -0.012817,
                "MonthlyPerformanceId": 48764
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 190,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:38:50.043000000",
                "Performance": -0.006439,
                "MonthlyPerformanceId": 48765
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 37,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:38:53.680000000",
                "Performance": 0.009101,
                "MonthlyPerformanceId": 48766
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 39,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:38:53.687000000",
                "Performance": -0.002851,
                "MonthlyPerformanceId": 48767
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 50,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:38:53.690000000",
                "Performance": 0.004653,
                "MonthlyPerformanceId": 48768
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 51,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:38:53.690000000",
                "Performance": 0.004403,
                "MonthlyPerformanceId": 48769
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 57,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:38:53.693000000",
                "Performance": -0.215868,
                "MonthlyPerformanceId": 48770
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 18,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:38:53.693000000",
                "Performance": 0.006447,
                "MonthlyPerformanceId": 48771
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 209,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:38:53.697000000",
                "Performance": 0.002729,
                "MonthlyPerformanceId": 48772
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 48,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:38:53.700000000",
                "Performance": -0.001068,
                "MonthlyPerformanceId": 48773
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 49,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:38:53.700000000",
                "Performance": -0.007924,
                "MonthlyPerformanceId": 48774
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 36,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:38:58.070000000",
                "Performance": 0.001890,
                "MonthlyPerformanceId": 48775
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 101,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:38:58.073000000",
                "Performance": -0.006094,
                "MonthlyPerformanceId": 48776
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 102,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:39:04.270000000",
                "Performance": -0.011728,
                "MonthlyPerformanceId": 48777
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 99,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:39:04.270000000",
                "Performance": 0.017631,
                "MonthlyPerformanceId": 48778
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 262,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:39:04.273000000",
                "Performance": 0.013755,
                "MonthlyPerformanceId": 48779
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 103,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:39:04.277000000",
                "Performance": 0.000425,
                "MonthlyPerformanceId": 48780
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 138,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:39:04.277000000",
                "Performance": -0.004738,
                "MonthlyPerformanceId": 48781
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 139,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:39:04.280000000",
                "Performance": -0.013476,
                "MonthlyPerformanceId": 48782
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 140,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:39:04.280000000",
                "Performance": -0.011310,
                "MonthlyPerformanceId": 48783
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 123,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:39:04.283000000",
                "Performance": -0.004921,
                "MonthlyPerformanceId": 48784
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 124,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:39:04.283000000",
                "Performance": -0.005903,
                "MonthlyPerformanceId": 48785
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 141,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:39:04.287000000",
                "Performance": 0.000267,
                "MonthlyPerformanceId": 48786
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 437,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:39:04.287000000",
                "Performance": -0.001633,
                "MonthlyPerformanceId": 48787
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 371,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:39:04.290000000",
                "Performance": -0.016864,
                "MonthlyPerformanceId": 48788
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 422,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:39:04.290000000",
                "Performance": -0.021031,
                "MonthlyPerformanceId": 48789
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 598,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:39:04.290000000",
                "Performance": -0.039626,
                "MonthlyPerformanceId": 48790
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 626,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:39:04.293000000",
                "Performance": -0.051105,
                "MonthlyPerformanceId": 48791
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 635,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:39:04.297000000",
                "Performance": -0.002815,
                "MonthlyPerformanceId": 48792
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 634,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 09:39:04.297000000",
                "Performance": 0.004000,
                "MonthlyPerformanceId": 48793
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 8,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-16 16:06:12.993000000",
                "Performance": 7.336310,
                "MonthlyPerformanceId": 48798
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 9,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-16 16:06:12.997000000",
                "Performance": 0.016107,
                "MonthlyPerformanceId": 48799
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 23,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-16 16:06:12.997000000",
                "Performance": 0.008000,
                "MonthlyPerformanceId": 48800
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 153,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-16 16:06:13",
                "Performance": 0.005202,
                "MonthlyPerformanceId": 48801
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 222,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48802
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 223,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48803
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 224,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 15:55:39.217000000",
                "Performance": -0.007342,
                "MonthlyPerformanceId": 48804
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 225,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 15:55:39.227000000",
                "Performance": -0.007967,
                "MonthlyPerformanceId": 48805
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 227,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-16 16:06:13",
                "Performance": 0.001511,
                "MonthlyPerformanceId": 48806
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 228,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-16 16:06:13",
                "Performance": -0.062349,
                "MonthlyPerformanceId": 48807
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 229,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 15:55:39.233000000",
                "Performance": -0.009997,
                "MonthlyPerformanceId": 48808
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 230,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 15:55:39.240000000",
                "Performance": -0.010580,
                "MonthlyPerformanceId": 48809
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 231,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 15:55:39.257000000",
                "Performance": -0.014476,
                "MonthlyPerformanceId": 48810
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 232,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 15:55:39.263000000",
                "Performance": -0.015267,
                "MonthlyPerformanceId": 48811
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 233,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48812
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 234,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48813
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 237,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-16 16:06:13.003000000",
                "Performance": 0.001467,
                "MonthlyPerformanceId": 48814
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 238,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-16 16:06:13.003000000",
                "Performance": 0.001938,
                "MonthlyPerformanceId": 48815
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 239,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-16 16:06:13.003000000",
                "Performance": 0.002076,
                "MonthlyPerformanceId": 48816
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 240,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-16 16:06:13",
                "Performance": 0.004765,
                "MonthlyPerformanceId": 48817
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 241,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48818
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 242,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48819
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 278,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": -0.015365,
                "MonthlyPerformanceId": 48820
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 284,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48821
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 285,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48822
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 295,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48823
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 296,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48824
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 325,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48825
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 326,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48826
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 327,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48827
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 328,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48828
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 332,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48829
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 341,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48830
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 342,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48831
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 343,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48832
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 344,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48833
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 345,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48834
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 346,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48835
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 350,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48836
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 352,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 15:55:39.273000000",
                "Performance": -0.027540,
                "MonthlyPerformanceId": 48837
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 354,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 15:55:39.280000000",
                "Performance": -0.054744,
                "MonthlyPerformanceId": 48838
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 355,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 15:55:39.290000000",
                "Performance": -0.000373,
                "MonthlyPerformanceId": 48839
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 357,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48840
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 358,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48841
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 383,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48842
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 384,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48843
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 392,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-16 16:06:12.997000000",
                "Performance": 0.003771,
                "MonthlyPerformanceId": 48844
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 393,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48845
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 394,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48846
            },
            {
                "Final": "False",
                "ModifiedUserId": "Admin",
                "IndexID": 401,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-15 09:00:55.340000000",
                "Performance": 0.004427,
                "MonthlyPerformanceId": 48847
            },
            {
                "Final": "False",
                "ModifiedUserId": "Admin",
                "IndexID": 402,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-15 09:00:55.347000000",
                "Performance": -0.007191,
                "MonthlyPerformanceId": 48848
            },
            {
                "Final": "False",
                "ModifiedUserId": "Admin",
                "IndexID": 403,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-15 09:00:55.353000000",
                "Performance": -0.010533,
                "MonthlyPerformanceId": 48849
            },
            {
                "Final": "False",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 404,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-08 14:47:36.197000000",
                "Performance": -0.029817,
                "MonthlyPerformanceId": 48850
            },
            {
                "Final": "True",
                "ModifiedUserId": "Admin",
                "IndexID": 405,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-16 16:06:13.003000000",
                "Performance": 0.009761,
                "MonthlyPerformanceId": 48851
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 418,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48852
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 419,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48853
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 420,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48854
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 421,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48855
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 426,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 15:55:39.297000000",
                "Performance": -0.001179,
                "MonthlyPerformanceId": 48856
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 427,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 15:55:39.303000000",
                "Performance": -0.077474,
                "MonthlyPerformanceId": 48857
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 428,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48858
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 429,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48859
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 430,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48860
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 435,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48861
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 436,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48862
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 438,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48863
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 451,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48864
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 452,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48865
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 453,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48866
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 454,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48867
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 540,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48868
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 542,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-08 14:39:36.580000000",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48869
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 547,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48870
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 548,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48871
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 563,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48872
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 565,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48873
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 568,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48874
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 586,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-13 09:25:06.323000000",
                "Performance": -0.151658,
                "MonthlyPerformanceId": 48875
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 596,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 16:05:31.687000000",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48876
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 597,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 16:05:26.227000000",
                "Performance": -0.005824,
                "MonthlyPerformanceId": 48877
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 621,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48878
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 622,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48879
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 623,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48880
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 636,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 15:56:21.383000000",
                "Performance": -0.007559,
                "MonthlyPerformanceId": 48881
            },
            {
                "Final": "True",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 637,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-13 09:59:02.903000000",
                "Performance": 0.007562,
                "MonthlyPerformanceId": 48882
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 645,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48883
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 647,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48884
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 673,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 15:55:39.320000000",
                "Performance": -0.016253,
                "MonthlyPerformanceId": 48885
            },
            {
                "Final": "False",
                "ModifiedUserId": "pkoumasidis",
                "IndexID": 682,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-02 14:15:55.870000000",
                "Performance": 0.005500,
                "MonthlyPerformanceId": 48886
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 702,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48887
            },
            {
                "Final": "False",
                "ModifiedUserId": "AGeitz",
                "IndexID": 714,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "2022-06-01 15:55:39.327000000",
                "Performance": -0.017941,
                "MonthlyPerformanceId": 48888
            },
            {
                "Final": "False",
                "ModifiedUserId": "",
                "IndexID": 719,
                "dDate": "2022-05-31 00:00:00",
                "ModifiedDateTime": "",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 48889
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 305,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:02",
                "Performance": -0.006559,
                "MonthlyPerformanceId": 48890
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 306,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:02",
                "Performance": -0.006546,
                "MonthlyPerformanceId": 48891
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 372,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:03",
                "Performance": -0.001065,
                "MonthlyPerformanceId": 48892
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 373,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:03",
                "Performance": -0.001199,
                "MonthlyPerformanceId": 48893
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 485,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:03",
                "Performance": -0.000119,
                "MonthlyPerformanceId": 48894
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 486,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:03",
                "Performance": -0.000331,
                "MonthlyPerformanceId": 48895
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 449,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:03",
                "Performance": -0.001417,
                "MonthlyPerformanceId": 48896
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 450,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:03",
                "Performance": -0.001132,
                "MonthlyPerformanceId": 48897
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 445,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:04",
                "Performance": -0.007171,
                "MonthlyPerformanceId": 48898
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 446,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:04",
                "Performance": -0.007156,
                "MonthlyPerformanceId": 48899
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 460,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:04",
                "Performance": -0.000218,
                "MonthlyPerformanceId": 48900
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 461,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:04",
                "Performance": -0.000323,
                "MonthlyPerformanceId": 48901
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 470,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:04",
                "Performance": -0.000464,
                "MonthlyPerformanceId": 48902
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 471,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:04",
                "Performance": -0.000377,
                "MonthlyPerformanceId": 48903
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 321,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:04",
                "Performance": -0.000126,
                "MonthlyPerformanceId": 48904
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 322,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:04",
                "Performance": -0.000364,
                "MonthlyPerformanceId": 48905
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 319,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:05",
                "Performance": -0.000397,
                "MonthlyPerformanceId": 48906
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 320,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:05",
                "Performance": -0.000364,
                "MonthlyPerformanceId": 48907
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 397,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:05",
                "Performance": -0.000270,
                "MonthlyPerformanceId": 48908
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 398,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:05",
                "Performance": -0.000352,
                "MonthlyPerformanceId": 48909
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 462,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:05",
                "Performance": -0.079804,
                "MonthlyPerformanceId": 48910
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 463,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:05",
                "Performance": -0.080143,
                "MonthlyPerformanceId": 48911
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 399,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:05",
                "Performance": -0.001262,
                "MonthlyPerformanceId": 48912
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 400,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:05",
                "Performance": -0.001417,
                "MonthlyPerformanceId": 48913
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 543,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:05",
                "Performance": -0.079804,
                "MonthlyPerformanceId": 48914
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 544,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:05",
                "Performance": -0.079473,
                "MonthlyPerformanceId": 48915
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 545,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:06",
                "Performance": -0.003364,
                "MonthlyPerformanceId": 48916
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 546,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:06",
                "Performance": -0.003387,
                "MonthlyPerformanceId": 48917
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 474,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:06",
                "Performance": -0.000064,
                "MonthlyPerformanceId": 48918
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 475,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:06",
                "Performance": -0.000064,
                "MonthlyPerformanceId": 48919
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 455,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:06",
                "Performance": -0.004130,
                "MonthlyPerformanceId": 48920
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 456,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:06",
                "Performance": -0.003949,
                "MonthlyPerformanceId": 48921
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 569,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:06",
                "Performance": -0.000923,
                "MonthlyPerformanceId": 48922
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 570,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:06",
                "Performance": -0.000738,
                "MonthlyPerformanceId": 48923
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 447,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:06",
                "Performance": -0.001104,
                "MonthlyPerformanceId": 48924
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 448,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:06",
                "Performance": -0.000919,
                "MonthlyPerformanceId": 48925
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 483,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:07",
                "Performance": -0.000118,
                "MonthlyPerformanceId": 48926
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 484,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:07",
                "Performance": -0.000325,
                "MonthlyPerformanceId": 48927
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 406,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:07",
                "Performance": -0.001143,
                "MonthlyPerformanceId": 48928
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 407,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:07",
                "Performance": -0.001320,
                "MonthlyPerformanceId": 48929
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 307,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:07",
                "Performance": -0.004140,
                "MonthlyPerformanceId": 48930
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 308,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:07",
                "Performance": -0.004293,
                "MonthlyPerformanceId": 48931
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 408,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:07",
                "Performance": -0.000127,
                "MonthlyPerformanceId": 48932
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 409,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:07",
                "Performance": -0.000364,
                "MonthlyPerformanceId": 48933
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 487,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:07",
                "Performance": -0.000125,
                "MonthlyPerformanceId": 48934
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 488,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:07",
                "Performance": -0.000362,
                "MonthlyPerformanceId": 48935
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 489,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:07",
                "Performance": -0.000254,
                "MonthlyPerformanceId": 48936
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 490,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:07",
                "Performance": -0.000394,
                "MonthlyPerformanceId": 48937
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 423,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:07",
                "Performance": -0.000736,
                "MonthlyPerformanceId": 48938
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 424,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:07",
                "Performance": -0.000865,
                "MonthlyPerformanceId": 48939
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 317,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:08",
                "Performance": -0.003579,
                "MonthlyPerformanceId": 48940
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 318,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:08",
                "Performance": -0.003487,
                "MonthlyPerformanceId": 48941
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 472,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:08",
                "Performance": -0.000064,
                "MonthlyPerformanceId": 48942
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 473,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:08",
                "Performance": -0.000064,
                "MonthlyPerformanceId": 48943
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 468,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:08",
                "Performance": -0.000064,
                "MonthlyPerformanceId": 48944
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 469,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:08",
                "Performance": -0.000063,
                "MonthlyPerformanceId": 48945
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 309,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:08",
                "Performance": -0.000127,
                "MonthlyPerformanceId": 48946
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 310,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:08",
                "Performance": -0.000364,
                "MonthlyPerformanceId": 48947
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 441,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:08",
                "Performance": -0.030956,
                "MonthlyPerformanceId": 48948
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 442,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:08",
                "Performance": -0.000410,
                "MonthlyPerformanceId": 48949
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 443,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:09",
                "Performance": -0.005540,
                "MonthlyPerformanceId": 48950
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 444,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:09",
                "Performance": -0.000196,
                "MonthlyPerformanceId": 48951
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 478,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:09",
                "Performance": -0.000422,
                "MonthlyPerformanceId": 48952
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 479,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:09",
                "Performance": -0.000423,
                "MonthlyPerformanceId": 48953
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 571,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:09",
                "Performance": -0.000923,
                "MonthlyPerformanceId": 48954
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 572,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:09",
                "Performance": -0.000738,
                "MonthlyPerformanceId": 48955
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 476,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:09",
                "Performance": -0.000125,
                "MonthlyPerformanceId": 48956
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 477,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:09",
                "Performance": -0.000312,
                "MonthlyPerformanceId": 48957
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 313,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:09",
                "Performance": -0.001215,
                "MonthlyPerformanceId": 48958
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 314,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:09",
                "Performance": -0.001120,
                "MonthlyPerformanceId": 48959
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 374,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:10",
                "Performance": -0.004213,
                "MonthlyPerformanceId": 48960
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 375,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:10",
                "Performance": -0.004160,
                "MonthlyPerformanceId": 48961
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 376,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:10",
                "Performance": -0.005662,
                "MonthlyPerformanceId": 48962
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 377,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:10",
                "Performance": -0.005726,
                "MonthlyPerformanceId": 48963
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 561,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:10",
                "Performance": -0.000515,
                "MonthlyPerformanceId": 48964
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 562,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:10",
                "Performance": -0.000419,
                "MonthlyPerformanceId": 48965
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 557,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:10",
                "Performance": -0.000531,
                "MonthlyPerformanceId": 48966
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 558,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:10",
                "Performance": -0.000432,
                "MonthlyPerformanceId": 48967
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 559,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:10",
                "Performance": -0.000515,
                "MonthlyPerformanceId": 48968
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 560,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:10",
                "Performance": -0.000420,
                "MonthlyPerformanceId": 48969
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 299,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:11",
                "Performance": -0.000185,
                "MonthlyPerformanceId": 48970
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 300,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:11",
                "Performance": -0.000422,
                "MonthlyPerformanceId": 48971
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 439,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:11",
                "Performance": -0.004607,
                "MonthlyPerformanceId": 48972
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 440,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:11",
                "Performance": -0.004528,
                "MonthlyPerformanceId": 48973
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 573,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:11",
                "Performance": -0.000924,
                "MonthlyPerformanceId": 48974
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 574,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:11",
                "Performance": -0.000738,
                "MonthlyPerformanceId": 48975
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 458,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:11",
                "Performance": -0.000277,
                "MonthlyPerformanceId": 48976
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 459,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:11",
                "Performance": -0.000346,
                "MonthlyPerformanceId": 48977
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 315,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:11",
                "Performance": -0.000127,
                "MonthlyPerformanceId": 48978
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 316,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:38:11",
                "Performance": -0.000364,
                "MonthlyPerformanceId": 48979
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 465,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:17",
                "Performance": 0.002723,
                "MonthlyPerformanceId": 49046
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 466,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:17",
                "Performance": 0.003714,
                "MonthlyPerformanceId": 49047
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 467,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:17",
                "Performance": 0.002723,
                "MonthlyPerformanceId": 49048
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 674,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:17",
                "Performance": 0.006344,
                "MonthlyPerformanceId": 49049
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 675,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:17",
                "Performance": 0.005190,
                "MonthlyPerformanceId": 49050
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 415,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:17",
                "Performance": 0.001337,
                "MonthlyPerformanceId": 49051
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 416,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:17",
                "Performance": 0.000289,
                "MonthlyPerformanceId": 49052
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 257,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:17",
                "Performance": -0.000006,
                "MonthlyPerformanceId": 49053
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 412,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:17",
                "Performance": 0.000002,
                "MonthlyPerformanceId": 49054
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 431,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:17",
                "Performance": 0.000006,
                "MonthlyPerformanceId": 49055
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 582,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:17",
                "Performance": 0.005588,
                "MonthlyPerformanceId": 49056
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 681,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:17",
                "Performance": 0.004360,
                "MonthlyPerformanceId": 49057
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 638,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:17",
                "Performance": 0.005579,
                "MonthlyPerformanceId": 49058
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 639,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:17",
                "Performance": 0.005102,
                "MonthlyPerformanceId": 49059
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 197,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:18",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 49060
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 198,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:18",
                "Performance": -0.000472,
                "MonthlyPerformanceId": 49061
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 601,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:18",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 49062
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 602,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:18",
                "Performance": -0.000295,
                "MonthlyPerformanceId": 49063
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 555,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:18",
                "Performance": -0.000280,
                "MonthlyPerformanceId": 49064
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 567,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:18",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 49065
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 609,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:18",
                "Performance": 0.005582,
                "MonthlyPerformanceId": 49066
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 611,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:18",
                "Performance": 0.005582,
                "MonthlyPerformanceId": 49067
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 207,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:08",
                "Performance": -0.028211,
                "MonthlyPerformanceId": 49068
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 247,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:08",
                "Performance": 0.000058,
                "MonthlyPerformanceId": 49069
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 255,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:08",
                "Performance": -0.025655,
                "MonthlyPerformanceId": 49070
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 256,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:08",
                "Performance": -0.000003,
                "MonthlyPerformanceId": 49071
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 396,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:08",
                "Performance": -0.229255,
                "MonthlyPerformanceId": 49072
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 595,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:08",
                "Performance": -0.144247,
                "MonthlyPerformanceId": 49073
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 329,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:13",
                "Performance": -0.000255,
                "MonthlyPerformanceId": 49074
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 433,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:13",
                "Performance": -0.079183,
                "MonthlyPerformanceId": 49075
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 395,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:13",
                "Performance": 0.000002,
                "MonthlyPerformanceId": 49076
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 575,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:13",
                "Performance": 0.000000,
                "MonthlyPerformanceId": 49077
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 629,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:15",
                "Performance": -0.041398,
                "MonthlyPerformanceId": 49078
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 591,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:18",
                "Performance": -0.059893,
                "MonthlyPerformanceId": 49079
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 592,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:18",
                "Performance": -0.060163,
                "MonthlyPerformanceId": 49080
            },
            {
                "Final": "False",
                "ModifiedUserId": "jivic",
                "IndexID": 599,
                "dDate": "2022-06-30 00:00:00",
                "ModifiedDateTime": "2022-06-17 13:39:18",
                "Performance": 0.031409,
                "MonthlyPerformanceId": 49081
            }
        ]
    }))

    const initialValues = {
        Final: "",
        ModifiedUserId: "",
        IndexID: "",
        dDate: "",
        ModifiedDateTime: "",
        Performance: "",
        MonthlyPerformanceId: "",
        // ExpenseType: "",
        // Amount: "",
        // AmountToPay: "",
    }
    const validationSchema = Yup.object({
        Final: Yup.string(),
        ModifiedUserId: Yup.string(),
        IndexID: Yup.string(),
        dDate: Yup.date(),
        ModifiedDateTime: Yup.date(),
        Performance: Yup.string(),
        MonthlyPerformanceId: Yup.string(),
        // Amount: Yup.string(),
        // AmountToPay: Yup.string(),
    })

    const formatDate = (value: Date | string, format = "L"): string => {
        return moment(value).format(format);
    }

    return (
        <Box sx={{ width: "100%" }}>
            <BasicDataTable title={title} data={MonthlyPerformance.data} columns={[
                {
                    label: "Final",
                    name: "Final",
                    options: {
                        filter: true,
                        sort: true,
                    }
                },
                {
                    label: "Modified User Id",
                    name: "ModifiedUserId",
                    options: {
                        filter: true,
                        sort: true,
                    }
                },
                // {
                //   label: "Status",
                //   name: "Status",
                //   options: {
                //     filter: true,
                //     sort: true,
                //     customBodyRender: (value: any, tableMeta: any, updateValue: any) => {


                //       return value == "Open" ? <TableBadge itemColor={value == "Open" ? "tablebage_success" : "tablebage_warning"} columnValue={value} />
                //         : <TableBadge itemColor={value == "Open" ? "tablebage_success" : "tablebage_warning"} columnValue={value} />

                //     }
                //   }
                // },
                {
                    label: "Index ID",
                    name: "IndexID",
                    options: {
                        filter: false,
                        sort: true,
                    }
                },
                {
                    label: "Date",
                    name: "dDate",
                    options: {
                        filter: false,
                        sort: true,
                        customBodyRender: (value: any) => {
                            return (
                                (value ? formatDate(value) : "-")
                            )
                        }
                    }

                },

                {
                    label: "Modified Date Time",
                    name: "ModifiedDateTime",
                    options: {
                        filter: false,
                        sort: true,
                        customBodyRender: (value: any) => {
                            return (
                                (value ? formatDate(value) : "-")
                            )
                        }
                    }
                },




                {
                    label: "Performance",
                    name: "Performance",
                    options: {
                        filter: false,
                        sort: true,
                    }
                },


                {
                    label: "Monthly Performance Id",
                    name: "MonthlyPerformanceId",
                    options: {
                        filter: true,
                        sort: true,
                    }
                },

            ]} initialValues={initialValues} validationSchema={validationSchema} id="monthlyPerformance" />
        </Box>
    )
}






