import { BasicDataTable } from '../../../shared-web/basicTable/BasicDataTable'
import { TableBadge } from '../../../shared-web/basicTable/TableBadge';
import * as Yup from 'yup'



interface Properties {
  title: string;
}
export const InvoiceDetails = (props: Properties) => {
  const { title } = props

  const InvoiceDetails = JSON.parse(JSON.stringify({
    data: [
      {
        "Matter": "SPECIALTY LEGAL EXPENSE INSURANCE",
        "Status": "Open",
        "InvoiceNumber": "OP7053405",
        "DateEntered": "03\/08\/2022",
        "InvoiceDate": "03\/08\/2022",
        "Aging": 31,

        "Vendor": "Ed Broking (Bermuda) Limited (Setup Pending)",


        "ExpenseType": "Funds\/Accounts",
        "Amount": 50000,
        "AmountToPay": 50000,
      },
      {
        "Matter": "Claims Services",
        "Status": "Close",
        "InvoiceNumber": "1103",
        "DateEntered": "03\/07\/2022",
        "InvoiceDate": "02\/28\/2022",
        "Aging": 39,

        "Vendor": "Terrabella Risk Consulting LLC",
        "ExpenseType": "Funds\/Accounts",
        "Amount": 2125,
        "AmountToPay": 2125,
      },
      {
        "Matter": "Banro \/\/ Somas: Insurance (#0471625#)",
        "Status": "Open",
        "InvoiceNumber": "001-10247775",
        "DateEntered": "03\/08\/2022",
        "InvoiceDate": "02\/24\/2022",
        "Aging": 43,

        "Vendor": "ENSafrica",


        "ExpenseType": "Funds\/Accounts",
        "Amount": 2957,
        "AmountToPay": 2957,
      },
      {
        "Matter": "UNCITRAL arbitration against Venezuela",
        "Status": "Open",
        "InvoiceNumber": "6001010665",
        "DateEntered": "03\/07\/2022",
        "InvoiceDate": "02\/23\/2022",
        "Aging": 44,

        "Vendor": "Freshfields Bruckhaus Deringer US LLP",


        "ExpenseType": "Funds\/Accounts",
        "Amount": 43791.94,
        "AmountToPay": 43791.94,
      },
      {
        "Matter": "vs Venezuela",
        "Status": "Close",
        "InvoiceNumber": "6001010657",
        "DateEntered": "03\/07\/2022",
        "InvoiceDate": "02\/23\/2022",
        "Aging": 44,

        "Vendor": "Freshfields Bruckhaus Deringer US LLP",


        "ExpenseType": "Funds\/Accounts",
        "Amount": 80000,
        "AmountToPay": 80000,
      },
      {
        "Matter": "General",
        "Status": "Open",
        "InvoiceNumber": "DL 200-398",
        "DateEntered": "03\/07\/2022",
        "InvoiceDate": "02\/21\/2022",
        "Aging": 46,

        "Vendor": "Dechamps",


        "ExpenseType": "Funds\/Accounts",
        "Amount": 98550.89,
        "AmountToPay": 98550.89,
      },
      {
        "Matter": "General",
        "Status": "Open",
        "InvoiceNumber": "DL 200-399",
        "DateEntered": "03\/07\/2022",
        "InvoiceDate": "02\/21\/2022",
        "Aging": 46,

        "Vendor": "Dechamps",


        "ExpenseType": "Funds\/Accounts",
        "Amount": 110713.45,
        "AmountToPay": 110713.45,
      },
      {
        "Matter": "Zuly Milk and Z & M Transporte Arbitration",
        "Status": "Open",
        "InvoiceNumber": "10902",
        "DateEntered": "03\/07\/2022",
        "InvoiceDate": "02\/19\/2022",
        "Aging": 48,

        "Vendor": "Robert W. Pittman",


        "ExpenseType": "Funds\/Accounts",
        "Amount": 22270.97,
        "AmountToPay": 22270.97,
      },
      {
        "Matter": "General",
        "Status": "Close",
        "InvoiceNumber": "RDS_#4",
        "DateEntered": "03\/07\/2022",
        "InvoiceDate": "02\/19\/2022",
        "Aging": 48,

        "Vendor": "Rodrigo S. Da Silva",


        "ExpenseType": "Funds\/Accounts",
        "Amount": 21895.97,
        "AmountToPay": 21895.97,
      },
      {
        "Matter": "NAFTA",
        "Status": "Open",
        "InvoiceNumber": "202000021522",
        "DateEntered": "02\/24\/2022",
        "InvoiceDate": "02\/17\/2022",
        "Aging": 50,

        "Vendor": "Hogan Lovells",


        "ExpenseType": "Funds\/Accounts",
        "Amount": 200000,
        "AmountToPay": 200000,

      },
      {
        "Matter": "Counsel Fee",
        "Status": "Open",
        "InvoiceNumber": "1037073",
        "DateEntered": "02\/25\/2022",
        "InvoiceDate": "02\/16\/2022",
        "Aging": 51,

        "Vendor": "Lowenstein Sandler",


        "ExpenseType": "Unassigned",
        "Amount": 6903,
        "AmountToPay": 6903,


      },
      {
        "Matter": "Gramercy 1812 Opportunity Fund:",
        "Status": "Close",
        "InvoiceNumber": "1037147",
        "DateEntered": "02\/25\/2022",
        "InvoiceDate": "02\/16\/2022",
        "Aging": 51,

        "Vendor": "Lowenstein Sandler",


        "ExpenseType": "Unassigned",
        "Amount": 2150,
        "AmountToPay": 2150,


      },
      {
        "Matter": "SBCERA IMA",
        "Status": "Open",
        "InvoiceNumber": "1037148",
        "DateEntered": "02\/25\/2022",
        "InvoiceDate": "02\/16\/2022",
        "Aging": 51,

        "Vendor": "Lowenstein Sandler",


        "ExpenseType": "Unassigned",
        "Amount": 3352.5,
        "AmountToPay": 3352.5,

      },
      {
        "Matter": "PA Incorporation",
        "Status": "Open",
        "InvoiceNumber": "248487",
        "DateEntered": "02\/18\/2022",
        "InvoiceDate": "02\/15\/2022",
        "Aging": 52,

        "Vendor": "Brigard & Urrutia Abogados S.A.S.",


        "ExpenseType": "Unassigned",
        "Amount": 633.79,
        "AmountToPay": 633.79,

      },
      {
        "Matter": "Dick Abanto Ishivata v. Venezuela",
        "Status": "Open",
        "InvoiceNumber": "DL 200-396",
        "DateEntered": "02\/15\/2022",
        "InvoiceDate": "02\/11\/2022",
        "Aging": 56,

        "Vendor": "Dechamps",
        "ExpenseType": "Funds\/Accounts",
        "Amount": 8301.25,
        "AmountToPay": 8301.25,
      },
      {
        "Matter": "Dick Abanto Ishivata v. Venezuela",
        "Status": "Open",
        "InvoiceNumber": "2021 28",
        "DateEntered": "02\/15\/2022",
        "InvoiceDate": "02\/11\/2022",
        "Aging": 56,

        "Vendor": "Seelhof Consulting",
        "ExpenseType": "Funds\/Accounts",
        "Amount": 16600,
        "AmountToPay": 16600,
      },
      {
        "Matter": "GFM v. Olge Bakhmatyuk",
        "Status": "Close",
        "InvoiceNumber": "207753",
        "DateEntered": "03\/01\/2022",
        "InvoiceDate": "02\/08\/2022",
        "Aging": 59,

        "Vendor": "Hirst Applegate , LLP (Setup Pending)",


        "ExpenseType": "Unassigned",
        "Amount": 13699.55,
        "AmountToPay": 13699.55,
      },
      {
        "Matter": "Gramercy - ISDA and Repo Review",
        "Status": "Open",
        "InvoiceNumber": "7002027127",
        "DateEntered": "02\/07\/2022",
        "InvoiceDate": "02\/07\/2022",
        "Aging": 60,

        "Vendor": "LINKLATERS LLP",


        "ExpenseType": "Unassigned",
        "Amount": 25108.8,
        "AmountToPay": 25108.8,
      },
      {
        "Matter": "Public Relations | Media Activity",
        "Status": "Open",
        "InvoiceNumber": "105-38",
        "DateEntered": "02\/09\/2022",
        "InvoiceDate": "02\/04\/2022",
        "Aging": 63,

        "Vendor": "ASC ADVISORS, LLC",
        "ExpenseType": "Unassigned",
        "Amount": 11544.29,
        "AmountToPay": 11544.29,
      },
      {
        "Matter": "Dick Abanto Ishivata v. Venezuela",
        "Status": "Open",
        "InvoiceNumber": "IUK9937",
        "DateEntered": "02\/15\/2022",
        "InvoiceDate": "02\/03\/2022",
        "Aging": 64,

        "Vendor": "Analysys Mason ",
        "ExpenseType": "Funds\/Accounts",
        "Amount": 15930,
        "AmountToPay": 15930,
      },
      {
        "Matter": "Zuly Milk v Venezuela – initial phase",
        "Status": "Open",
        "InvoiceNumber": "2022\/02",
        "DateEntered": "03\/07\/2022",
        "InvoiceDate": "02\/01\/2022",
        "Aging": 66,

        "Vendor": "Seelhof Consulting",


        "ExpenseType": "Funds\/Accounts",
        "Amount": 10000,
        "AmountToPay": 10000,
      },
      {
        "Matter": "NAFTA arbitration",
        "Status": "Close",
        "InvoiceNumber": "1842-ESP-05",
        "DateEntered": "02\/28\/2022",
        "InvoiceDate": "01\/31\/2022",
        "Aging": 67,

        "Vendor": "Secretariat Advisors, LLC",


        "ExpenseType": "Funds\/Accounts",
        "Amount": 20155,
        "AmountToPay": 20155,
      },
      {
        "Matter": "Crueger Dickinson-Litigation Investment",
        "Status": "Open",
        "InvoiceNumber": "4275",
        "DateEntered": "03\/01\/2022",
        "InvoiceDate": "01\/26\/2022",
        "Aging": 72,
        "Payment Date": "03\/08\/2022",
        "Vendor": "Weisbrod Matteis & Copley PLLC",
        "Approved On": "03\/01\/2022",
        "Approved By": "Nick Paolazzi",
        "ExpenseType": "Funds\/Accounts",
        "Amount": 8888,
        "AmountToPay": 8888,
        "Invoice": "[{\"Filename\":\"InvoiceSubmission\/00002\/00002798_wiqf3vxkd6bq2.pdf\",\"OriginalName\":\"4275.pdf\"}]",
        "Instructions": "payable from CRH"
      },
      {
        "Matter": "Dalimonte Matter",
        "Status": "Open",
        "InvoiceNumber": "600276",
        "DateEntered": "01\/26\/2022",
        "InvoiceDate": "01\/25\/2022",
        "Aging": 73,

        "Vendor": "MINTZ GROUP",


        "ExpenseType": "Unassigned",
        "Amount": 9451.86,
        "AmountToPay": 9451.86,

      },
      {
        "Matter": "Futures Agr and CDEA Reviews",
        "Status": "Open",
        "InvoiceNumber": "7002027001",
        "DateEntered": "01\/28\/2022",
        "InvoiceDate": "01\/25\/2022",
        "Aging": 73,

        "Vendor": "LINKLATERS LLP",


        "ExpenseType": "Unassigned",
        "Amount": 1760,
        "AmountToPay": 1760,
      },
      {
        "Matter": "CMG - Gramercy General Advice",
        "Status": "Open",
        "InvoiceNumber": "7002027000",
        "DateEntered": "01\/28\/2022",
        "InvoiceDate": "01\/25\/2022",
        "Aging": 73,

        "Vendor": "LINKLATERS LLP",


        "ExpenseType": "Unassigned",
        "Amount": 3830,
        "AmountToPay": 3830,

      },
      {
        "Matter": "MRPA Review",
        "Status": "Close",
        "InvoiceNumber": "7002026999",
        "DateEntered": "01\/28\/2022",
        "InvoiceDate": "01\/25\/2022",
        "Aging": 73,

        "Vendor": "LINKLATERS LLP",


        "ExpenseType": "Unassigned",
        "Amount": 15151,
        "AmountToPay": 15151,
      },
      {
        "Matter": "María de la Concepción Felipe Velázquez and others v. Venezuela",
        "Status": "Open",
        "InvoiceNumber": "10893",
        "DateEntered": "01\/27\/2022",
        "InvoiceDate": "01\/24\/2022",
        "Aging": 74,

        "Vendor": "Robert W. Pittman",
        "ExpenseType": "Funds\/Accounts",
        "Amount": 21895.97,
        "AmountToPay": 21895.97,
      },
      {
        "Matter": "María de la Concepción Felipe Velázquez and others v. Venezuela",
        "Status": "Open",
        "InvoiceNumber": "RDS_#3",
        "DateEntered": "01\/27\/2022",
        "InvoiceDate": "01\/24\/2022",
        "Aging": 74,

        "Vendor": "Rodrigo S. Da Silva",
        "ExpenseType": "Funds\/Accounts",
        "Amount": 21895.97,
        "AmountToPay": 21895.97,
      },
      {
        "Matter": "General",
        "Status": "Open",
        "InvoiceNumber": "1032160",
        "DateEntered": "01\/19\/2022",
        "InvoiceDate": "01\/19\/2022",
        "Aging": 79,

        "Vendor": "Lowenstein Sandler",


        "ExpenseType": "Unassigned",
        "Amount": 14713.9,
        "AmountToPay": 14713.9,

      },
      {
        "Matter": "Gramercy Funds Management Line of Credit",
        "Status": "Open",
        "InvoiceNumber": "1032165",
        "DateEntered": "01\/19\/2022",
        "InvoiceDate": "01\/19\/2022",
        "Aging": 79,

        "Vendor": "Lowenstein Sandler",


        "ExpenseType": "Unassigned",
        "Amount": 2184,
        "AmountToPay": 2184,

      },
      {
        "Matter": "SBCERA IMA",
        "Status": "Close",
        "InvoiceNumber": "1032170",
        "DateEntered": "01\/19\/2022",
        "InvoiceDate": "01\/19\/2022",
        "Aging": 79,

        "Vendor": "Lowenstein Sandler",


        "ExpenseType": "Unassigned",
        "Amount": 240,
        "AmountToPay": 240,

      },
      {
        "Matter": "Schlumberger Sanctions Advice",
        "Status": "Open",
        "InvoiceNumber": "1881857",
        "DateEntered": "01\/18\/2022",
        "InvoiceDate": "01\/18\/2022",
        "Aging": 80,

        "Vendor": "Skadden, Arps, Slate, Meagher, & Flom LLP (Setup Pending)",


        "ExpenseType": "Unassigned",
        "Amount": 1832,
        "AmountToPay": 1832,

      },
      {
        "Matter": "Public Relations | Media Activity",
        "Status": "Open",
        "InvoiceNumber": "105-37",
        "DateEntered": "01\/12\/2022",
        "InvoiceDate": "01\/06\/2022",
        "Aging": 92,

        "Vendor": "ASC ADVISORS, LLC",
        "ExpenseType": "Unassigned",
        "Amount": 6511.81,
        "AmountToPay": 6511.81,
      },
      {
        "Matter": "Director Fees",
        "Status": "Open",
        "InvoiceNumber": "2153",
        "DateEntered": "12\/01\/2021",
        "InvoiceDate": "01\/01\/2022",
        "Aging": 97,
        "Payment Date": "12\/15\/2021",
        "Vendor": "MG Management Ltd. ",
        "Approved On": "12\/10\/2021",
        "Approved By": "Nick Paolazzi",
        "ExpenseType": "Funds\/Accounts",
        "Amount": 9000,
        "AmountToPay": 9000,
        "Invoice": "[{\"Filename\":\"InvoiceSubmission\/00002\/00002634_n6enqznh4isxs.pdf\",\"OriginalName\":\"Invoice_2153_from_FROM_MG_Management_Ltd.pdf\"}]",
        "Instructions": "Cant pay until cap call 100% MORANG"
      },
      {
        "Matter": "ULF\/AVG",
        "Status": "Open",
        "InvoiceNumber": "2372092",
        "DateEntered": "01\/05\/2022",
        "InvoiceDate": "12\/31\/2021",
        "Aging": 98,

        "Vendor": "TransPerfect Translations Intl Inc",
        "ExpenseType": "Funds\/Accounts",
        "Amount": 6875.22,
        "AmountToPay": 6875.22,
      },
      {
        "Matter": "General",
        "Status": "Close",
        "InvoiceNumber": "466324",
        "DateEntered": "01\/27\/2022",
        "InvoiceDate": "12\/31\/2021",
        "Aging": 98,

        "Vendor": "O'Byrne Stanko & Jefferson (Setup Pending)",


        "ExpenseType": "Unassigned",
        "Amount": 963.08,
        "AmountToPay": 963.08,

      },
      {
        "Matter": "General",
        "Status": "Open",
        "InvoiceNumber": "1026993",
        "DateEntered": "12\/20\/2021",
        "InvoiceDate": "12\/17\/2021",
        "Aging": 112,

        "Vendor": "Lowenstein Sandler",


        "ExpenseType": "Unassigned",
        "Amount": 3778.5,
        "AmountToPay": 3778.5,

      },
      {
        "Matter": "Gramercy Service Agreement:",
        "Status": "Open",
        "InvoiceNumber": "1027000",
        "DateEntered": "12\/20\/2021",
        "InvoiceDate": "12\/17\/2021",
        "Aging": 112,

        "Vendor": "Lowenstein Sandler",


        "ExpenseType": "Unassigned",
        "Amount": 1593,
        "AmountToPay": 1593,

      },
      {
        "Matter": "Aznar Dominguez matter",
        "Status": "Open",
        "InvoiceNumber": "434564",
        "DateEntered": "01\/25\/2022",
        "InvoiceDate": "12\/10\/2021",
        "Aging": 119,

        "Vendor": "MINTZ GROUP",


        "ExpenseType": "Unassigned",
        "Amount": 10635,
        "AmountToPay": 10635,

      },
      {
        "Matter": "Ukrland Farming",
        "Status": "Close",
        "InvoiceNumber": "206993",
        "DateEntered": "12\/14\/2021",
        "InvoiceDate": "12\/09\/2021",
        "Aging": 120,

        "Vendor": "Hirst Applegate , LLP (Setup Pending)",
        "ExpenseType": "Unassigned",
        "Amount": 4511.99,
        "AmountToPay": 4511.99,
      },
      {
        "Matter": "KPN",
        "Status": "Open",
        "InvoiceNumber": "466015",
        "DateEntered": "12\/14\/2021",
        "InvoiceDate": "12\/07\/2021",
        "Aging": 122,

        "Vendor": "O'Byrne Stanko & Jefferson (Setup Pending)",


        "ExpenseType": "Unassigned",
        "Amount": 963.08,
        "AmountToPay": 963.08,

      },
      {
        "Matter": "Public Relations | Media Activity",
        "Status": "Open",
        "InvoiceNumber": "105-36",
        "DateEntered": "12\/15\/2021",
        "InvoiceDate": "12\/06\/2021",
        "Aging": 123,

        "Vendor": "ASC ADVISORS, LLC",
        "ExpenseType": "Unassigned",
        "Amount": 3981.74,
        "AmountToPay": 3981.74,
      },
      {
        "Matter": "McDonald Worley matter",
        "Status": "Open",
        "InvoiceNumber": "434320",
        "DateEntered": "01\/25\/2022",
        "InvoiceDate": "11\/30\/2021",
        "Aging": 129,

        "Vendor": "MINTZ GROUP",


        "ExpenseType": "Unassigned",
        "Amount": 10635,
        "AmountToPay": 10635,

      },
      {
        "Matter": "vs Venezuela",
        "Status": "Close",
        "InvoiceNumber": "6001009625",
        "DateEntered": "02\/15\/2022",
        "InvoiceDate": "11\/30\/2021",
        "Aging": 129,

        "Vendor": "Freshfields Bruckhaus Deringer US LLP",
        "ExpenseType": "Funds\/Accounts",
        "Amount": 80000,
        "AmountToPay": 80000,
      },
      {
        "Matter": "Crueger Dickinson-Litigation Investment",
        "Status": "Open",
        "InvoiceNumber": "4222",
        "DateEntered": "03\/01\/2022",
        "InvoiceDate": "11\/30\/2021",
        "Aging": 129,
        "Payment Date": "03\/08\/2022",
        "Vendor": "Weisbrod Matteis & Copley PLLC",
        "Approved On": "03\/01\/2022",
        "Approved By": "Nick Paolazzi",
        "ExpenseType": "Funds\/Accounts",
        "Amount": 2017.5,
        "AmountToPay": 2017.5,
        "Invoice": "[{\"Filename\":\"InvoiceSubmission\/00002\/00002796_dx4fnz3txkv3q.pdf\",\"OriginalName\":\"4222.pdf\"}]",
        "Instructions": "payable from CRH"
      },
      {
        "Matter": "Insurance Policy: Venezuela Claims",
        "Status": "Open",
        "InvoiceNumber": "4240",
        "DateEntered": "03\/01\/2022",
        "InvoiceDate": "11\/30\/2021",
        "Aging": 129,
        "Payment Date": "03\/08\/2022",
        "Vendor": "Weisbrod Matteis & Copley PLLC",
        "Approved On": "03\/01\/2022",
        "Approved By": "Nick Paolazzi",
        "ExpenseType": "Funds\/Accounts",
        "Amount": 2640,
        "AmountToPay": 2640,
        "Invoice": "[{\"Filename\":\"InvoiceSubmission\/00002\/00002797_3uw4omkqc7wpe.pdf\",\"OriginalName\":\"4240.pdf\"}]",
        "Instructions": "payable from GVSSF"
      },
      {
        "Matter": "General",
        "Status": "Close",
        "InvoiceNumber": "1023106",
        "DateEntered": "12\/14\/2021",
        "InvoiceDate": "11\/19\/2021",
        "Aging": 140,

        "Vendor": "Lowenstein Sandler",


        "ExpenseType": "Unassigned",
        "Amount": 1532.5,
        "AmountToPay": 1532.5,

      },
      {
        "Matter": "Gramercy Service Agreement",
        "Status": "Open",
        "InvoiceNumber": "1023167",
        "DateEntered": "12\/14\/2021",
        "InvoiceDate": "11\/19\/2021",
        "Aging": 140,

        "Vendor": "Lowenstein Sandler",


        "ExpenseType": "Unassigned",
        "Amount": 4159.5,
        "AmountToPay": 4159.5,

      },
      {
        "Matter": "SBCERA IMA",
        "Status": "Open",
        "InvoiceNumber": "1023177",
        "DateEntered": "12\/14\/2021",
        "InvoiceDate": "11\/19\/2021",
        "Aging": 140,

        "Vendor": "Lowenstein Sandler",


        "ExpenseType": "Unassigned",
        "Amount": 12175,
        "AmountToPay": 12175,

      },
      {
        "Matter": "Insurance Policy: Venezuela Claims",
        "Status": "Open",
        "InvoiceNumber": "4214",
        "DateEntered": "03\/01\/2022",
        "InvoiceDate": "11\/17\/2021",
        "Aging": 142,
        "Payment Date": "03\/08\/2022",
        "Vendor": "Weisbrod Matteis & Copley PLLC",
        "Approved On": "03\/01\/2022",
        "Approved By": "Nick Paolazzi",
        "ExpenseType": "Funds\/Accounts",
        "Amount": 12240,
        "AmountToPay": 12240,
        "Invoice": "[{\"Filename\":\"InvoiceSubmission\/00002\/00002795_gl7llljmpkdi4.pdf\",\"OriginalName\":\"4214.pdf\"}]",
        "Instructions": "payable from GVSSF"
      },
      {
        "Matter": "Sanctions Advice re Special Situations",
        "Status": "Open",
        "InvoiceNumber": "1872773",
        "DateEntered": "11\/17\/2021",
        "InvoiceDate": "11\/16\/2021",
        "Aging": 143,

        "Vendor": "Skadden, Arps, Slate, Meagher, & Flom LLP (Setup Pending)",
        "ExpenseType": "Funds\/Accounts",
        "Amount": 8244,
        "AmountToPay": 8244,
      },
      {
        "Matter": "General Economic Sanctions Advice",
        "Status": "Close",
        "InvoiceNumber": "1872774",
        "DateEntered": "11\/17\/2021",
        "InvoiceDate": "11\/16\/2021",
        "Aging": 143,

        "Vendor": "Skadden, Arps, Slate, Meagher & Flom (Setup Pending)",


        "ExpenseType": "Unassigned",
        "Amount": 1488.5,
        "AmountToPay": 1488.5,

      },
      {
        "Matter": "Schlumberger Sanctions Advice",
        "Status": "Open",
        "InvoiceNumber": "1872777",
        "DateEntered": "11\/17\/2021",
        "InvoiceDate": "11\/16\/2021",
        "Aging": 143,

        "Vendor": "Skadden, Arps, Slate, Meagher & Flom (Setup Pending)",


        "ExpenseType": "Unassigned",
        "Amount": 2519,
        "AmountToPay": 2519,

      },
      {
        "Matter": "MW Speciality Finance LLC",
        "Status": "Open",
        "InvoiceNumber": "23133550-RI",
        "DateEntered": "11\/16\/2021",
        "InvoiceDate": "11\/15\/2021",
        "Aging": 144,

        "Vendor": "CT Corporation System",
        "ExpenseType": "Funds\/Accounts",
        "Amount": 686.15,
        "AmountToPay": 686.15,
      },
      {
        "Matter": "Gramercy Mexico Infrastructure (GMEX DIRECTS)",
        "Status": "Open",
        "InvoiceNumber": "23133551-RI",
        "DateEntered": "11\/16\/2021",
        "InvoiceDate": "11\/15\/2021",
        "Aging": 144,

        "Vendor": "CT Corporation System",


        "ExpenseType": "Funds\/Accounts",
        "Amount": 686.15,
        "AmountToPay": 686.15,
      },
      {
        "Matter": "Gramercy MW Holdings LLC",
        "Status": "Open",
        "InvoiceNumber": "23160725-RI",
        "DateEntered": "11\/16\/2021",
        "InvoiceDate": "11\/15\/2021",
        "Aging": 144,

        "Vendor": "CT Corporation System",


        "ExpenseType": "Funds\/Accounts",
        "Amount": 686.15,
        "AmountToPay": 686.15,
      },
      {
        "Matter": "Colombia Fintech (OMNI SPV)",
        "Status": "Close",
        "InvoiceNumber": "23160729-RI",
        "DateEntered": "11\/16\/2021",
        "InvoiceDate": "11\/15\/2021",
        "Aging": 144,

        "Vendor": "CT Corporation System",


        "ExpenseType": "Funds\/Accounts",
        "Amount": 686.15,
        "AmountToPay": 686.15,
      },
      {
        "Matter": "VENEZUELA LITIGATION FINANCING AGREEMENTS: SPECIAL SITUATIONS",
        "Status": "Open",
        "InvoiceNumber": "30016192",
        "DateEntered": "11\/16\/2021",
        "InvoiceDate": "11\/11\/2021",
        "Aging": 148,

        "Vendor": "Steptoe & Johnson LLP",


        "ExpenseType": "Unassigned",
        "Amount": 77918,
        "AmountToPay": 77918,

      },

      {
        "Matter": "KPN",
        "Status": "Open",
        "InvoiceNumber": "462019",
        "DateEntered": "05\/27\/2021",
        "InvoiceDate": "05\/19\/2021",
        "Aging": 324,

        "Vendor": "O'Byrne Stanko & Jefferson (Setup Pending)",


        "ExpenseType": "Unassigned",
        "Amount": 252.08,
        "AmountToPay": 252.08,
      },
      {
        "Matter": "PUERTO RICO PROJECT",
        "Status": "Open",
        "InvoiceNumber": "30003900",
        "DateEntered": "11\/22\/2021",
        "InvoiceDate": "05\/19\/2021",
        "Aging": 324,

        "Vendor": "Steptoe & Johnson LLP",


        "ExpenseType": "Unassigned",
        "Amount": 28702.5,
        "AmountToPay": 28702.5,

      },
      {
        "Matter": "VENEZUELA LITIGATION FINANCING AGREEMENTS: SPECIAL SITUATIONS",
        "Status": "Open",
        "InvoiceNumber": "30003902",
        "DateEntered": "11\/22\/2021",
        "InvoiceDate": "05\/19\/2021",
        "Aging": 324,

        "Vendor": "Steptoe & Johnson LLP",


        "ExpenseType": "Unassigned",
        "Amount": 687,
        "AmountToPay": 687,

      },
      {
        "Matter": "VENEZUELA RECEIVABLES INVESTMENT",
        "Status": "Close",
        "InvoiceNumber": "30003903",
        "DateEntered": "11\/22\/2021",
        "InvoiceDate": "05\/19\/2021",
        "Aging": 324,

        "Vendor": "Steptoe & Johnson LLP",


        "ExpenseType": "Unassigned",
        "Amount": 12468.5,
        "AmountToPay": 12468.5,

      },
      {
        "Matter": "CONFIDENTIAL - MORANG RESTRUCTURING IN BRAZIL",
        "Status": "Open",
        "InvoiceNumber": "30003904",
        "DateEntered": "11\/22\/2021",
        "InvoiceDate": "05\/19\/2021",
        "Aging": 324,

        "Vendor": "Steptoe & Johnson LLP",


        "ExpenseType": "Unassigned",
        "Amount": 14577,
        "AmountToPay": 14577,

      },
      {
        "Matter": "Sale of one or more Barbados domiciled subsidiaries",
        "Status": "Open",
        "InvoiceNumber": "18279 MSJ",
        "DateEntered": "05\/14\/2021",
        "InvoiceDate": "04\/30\/2021",
        "Aging": 343,

        "Vendor": "Lex Caribbean (Setup Pending)",
        "ExpenseType": "Funds\/Accounts",
        "Amount": 4450.75,
        "AmountToPay": 4450.75,
      },
      {
        "Matter": "Gramercy EAT - Santo Antonio Loan",
        "Status": "Open",
        "InvoiceNumber": "7002025604",
        "DateEntered": "10\/07\/2021",
        "InvoiceDate": "04\/30\/2021",
        "Aging": 343,

        "Vendor": "LINKLATERS LLP",


        "ExpenseType": "Unassigned",
        "Amount": 195000,
        "AmountToPay": 195000,

      },
      {
        "Matter": "Gramercy EAT - General Advice",
        "Status": "Close",
        "InvoiceNumber": "7002025611",
        "DateEntered": "10\/07\/2021",
        "InvoiceDate": "04\/30\/2021",
        "Aging": 343,

        "Vendor": "LINKLATERS LLP",


        "ExpenseType": "Unassigned",
        "Amount": 200512.77,
        "AmountToPay": 200512.77,

      },
      {
        "Matter": "PUERTO RICO PROJECT",
        "Status": "Open",
        "InvoiceNumber": "30000656",
        "DateEntered": "04\/16\/2021",
        "InvoiceDate": "04\/14\/2021",
        "Aging": 359,

        "Vendor": "Steptoe & Johnson LLP",


        "ExpenseType": "Unassigned",
        "Amount": 1474,
        "AmountToPay": 1474,

      },
      {
        "Matter": "VENEZUELA LITIGATION FINANCING AGREEMENTS: SPECIAL SITUATIONS",
        "Status": "Open",
        "InvoiceNumber": "30000658",
        "DateEntered": "04\/16\/2021",
        "InvoiceDate": "04\/14\/2021",
        "Aging": 359,

        "Vendor": "Steptoe & Johnson LLP",


        "ExpenseType": "Unassigned",
        "Amount": 916,
        "AmountToPay": 916,

      },
      {
        "Matter": "VENEZUELA RECEIVABLES INVESTMENT",
        "Status": "Open",
        "InvoiceNumber": "30000659",
        "DateEntered": "04\/16\/2021",
        "InvoiceDate": "04\/14\/2021",
        "Aging": 359,

        "Vendor": "Steptoe & Johnson LLP",


        "ExpenseType": "Unassigned",
        "Amount": 19608,
        "AmountToPay": 19608,

      },
      {
        "Matter": "General - MAE",
        "Status": "Open",
        "InvoiceNumber": "2401324",
        "DateEntered": "10\/15\/2021",
        "InvoiceDate": "04\/08\/2021",
        "Aging": 365,

        "Vendor": "DEBEVOISE AND PLIMPTON",


        "ExpenseType": "Management Company",
        "Amount": 12398.5,
        "AmountToPay": 12398.5,

      },
      {
        "Matter": "PUERTO RICO PROJECT",
        "Status": "Open",
        "InvoiceNumber": "2699772",
        "DateEntered": "03\/22\/2021",
        "InvoiceDate": "03\/18\/2021",
        "Aging": 386,

        "Vendor": "Steptoe & Johnson LLP",


        "ExpenseType": "Funds\/Accounts",
        "Amount": 9380,
        "AmountToPay": 9380,

      },
      {
        "Matter": "VENEZUELA LITIGATION FINANCING AGREEMENTS: SPECIAL SITUATIONS",
        "Status": "Close",
        "InvoiceNumber": "2699774",
        "DateEntered": "03\/22\/2021",
        "InvoiceDate": "03\/18\/2021",
        "Aging": 386,

        "Vendor": "Steptoe & Johnson LLP",


        "ExpenseType": "Unassigned",
        "Amount": 5249,
        "AmountToPay": 5249,

      },
      {
        "Matter": "VENEZUELA RECEIVABLES INVESTMENT",
        "Status": "Open",
        "InvoiceNumber": "2699775",
        "DateEntered": "03\/22\/2021",
        "InvoiceDate": "03\/18\/2021",
        "Aging": 386,

        "Vendor": "Steptoe & Johnson LLP",


        "ExpenseType": "Unassigned",
        "Amount": 31850.5,
        "AmountToPay": 31850.5,

      },
      {
        "Matter": "PUERTO RICO PROJECT",
        "Status": "Open",
        "InvoiceNumber": "2696850",
        "DateEntered": "02\/22\/2021",
        "InvoiceDate": "02\/18\/2021",
        "Aging": 414,

        "Vendor": "Steptoe & Johnson LLP",


        "ExpenseType": "Funds\/Accounts",
        "Amount": 3752,
        "AmountToPay": 3752,

      },
      {
        "Matter": "VENEZUELA LITIGATION FINANCING AGREEMENTS: SPECIAL SITUATIONS",
        "Status": "Open",
        "InvoiceNumber": "2696852",
        "DateEntered": "02\/22\/2021",
        "InvoiceDate": "02\/18\/2021",
        "Aging": 414,

        "Vendor": "Steptoe & Johnson LLP",


        "ExpenseType": "Unassigned",
        "Amount": 916,
        "AmountToPay": 916,

      },
      {
        "Matter": "VENEZUELA RECEIVABLES INVESTMENT",
        "Status": "Open",
        "InvoiceNumber": "2696853",
        "DateEntered": "02\/22\/2021",
        "InvoiceDate": "02\/18\/2021",
        "Aging": 414,

        "Vendor": "Steptoe & Johnson LLP",


        "ExpenseType": "Unassigned",
        "Amount": 19837.5,
        "AmountToPay": 19837.5,


      },
      {
        "Matter": "PUERTO RICO PROJECT",
        "Status": "Close",
        "InvoiceNumber": "2695777",
        "DateEntered": "01\/22\/2021",
        "InvoiceDate": "01\/22\/2021",
        "Aging": 441,

        "Vendor": "Steptoe & Johnson LLP",


        "ExpenseType": "Funds\/Accounts",
        "Amount": 3720,
        "AmountToPay": 3720,

      },
      {
        "Matter": "VENEZUELA LITIGATION FINANCING AGREEMENTS: SPECIAL SITUATIONS",
        "Status": "Open",
        "InvoiceNumber": "2695779",
        "DateEntered": "01\/22\/2021",
        "InvoiceDate": "01\/22\/2021",
        "Aging": 441,

        "Vendor": "Steptoe & Johnson LLP",


        "ExpenseType": "Unassigned",
        "Amount": 2428,
        "AmountToPay": 2428,

      },
      {
        "Matter": "VENEZUELA RECEIVABLES INVESTMENT",
        "Status": "Open",
        "InvoiceNumber": "2695780",
        "DateEntered": "01\/22\/2021",
        "InvoiceDate": "01\/22\/2021",
        "Aging": 441,

        "Vendor": "Steptoe & Johnson LLP",


        "ExpenseType": "Unassigned",
        "Amount": 416,
        "AmountToPay": 416,

      },
      {
        "Matter": "PUERTO RICO PROJECT",
        "Status": "Close",
        "InvoiceNumber": "2694881",
        "DateEntered": "01\/05\/2021",
        "InvoiceDate": "12\/30\/2020",
        "Aging": 464,

        "Vendor": "Steptoe & Johnson LLP",


        "ExpenseType": "Funds\/Accounts",
        "Amount": 7440,
        "AmountToPay": 7440,

      },
      {
        "Matter": "VENEZUELA LITIGATION FINANCING AGREEMENTS: SPECIAL SITUATIONS",
        "Status": "Open",
        "InvoiceNumber": "2694882",
        "DateEntered": "01\/05\/2021",
        "InvoiceDate": "12\/30\/2020",
        "Aging": 464,

        "Vendor": "Steptoe & Johnson LLP",


        "ExpenseType": "Unassigned",
        "Amount": 11125,
        "AmountToPay": 11125,

      },
      {
        "Matter": "VENEZUELA LITIGATION FINANCING AGREEMENTS: BONDS",
        "Status": "Close",
        "InvoiceNumber": "2694883",
        "DateEntered": "01\/05\/2021",
        "InvoiceDate": "12\/30\/2020",
        "Aging": 464,

        "Vendor": "Steptoe & Johnson LLP",


        "ExpenseType": "Unassigned",
        "Amount": 9194.5,
        "AmountToPay": 9194.5,

      },
      {
        "Matter": "VENEZUELA LITIGATION FINANCING AGREEMENTS: SPECIAL SITUATIONS",
        "Status": "Open",
        "InvoiceNumber": "2691853",
        "DateEntered": "12\/17\/2020",
        "InvoiceDate": "11\/17\/2020",
        "Aging": 507,

        "Vendor": "Steptoe & Johnson LLP",


        "ExpenseType": "Unassigned",
        "Amount": 12771,
        "AmountToPay": 12771,

      },
      {
        "Matter": "VENEZUELA RECEIVABLES INVESTMENT",
        "Status": "Open",
        "InvoiceNumber": "2691854",
        "DateEntered": "12\/17\/2020",
        "InvoiceDate": "11\/17\/2020",
        "Aging": 507,

        "Vendor": "Steptoe & Johnson LLP",


        "ExpenseType": "Unassigned",
        "Amount": 1590,
        "AmountToPay": 1590,

      },
      {
        "Matter": "VENEZUELA LITIGATION FINANCING AGREEMENTS: BONDS",
        "Status": "Close",
        "InvoiceNumber": "2691855",
        "DateEntered": "12\/17\/2020",
        "InvoiceDate": "11\/17\/2020",
        "Aging": 507,

        "Vendor": "Steptoe & Johnson LLP",


        "ExpenseType": "Unassigned",
        "Amount": 12003,
        "AmountToPay": 12003,

      },
      {
        "Matter": "Howard\/Piccirc",
        "Status": "Open",
        "InvoiceNumber": "1117196",
        "DateEntered": "11\/12\/2020",
        "InvoiceDate": "11\/11\/2020",
        "Aging": 513,

        "Vendor": "CADWALADER",


        "ExpenseType": "Unassigned",
        "Amount": 666,
        "AmountToPay": 666,

      },
      {
        "Matter": "Khan",
        "Status": "Close",
        "InvoiceNumber": "1117197",
        "DateEntered": "11\/12\/2020",
        "InvoiceDate": "11\/11\/2020",
        "Aging": 513,

        "Vendor": "CADWALADER",


        "ExpenseType": "Unassigned",
        "Amount": 145920.21,
        "AmountToPay": 145920.21,

      },
      {
        "Matter": "Chamberlain",
        "Status": "Open",
        "InvoiceNumber": "1117198",
        "DateEntered": "11\/12\/2020",
        "InvoiceDate": "11\/11\/2020",
        "Aging": 513,

        "Vendor": "CADWALADER",


        "ExpenseType": "Unassigned",
        "Amount": 1210.78,
        "AmountToPay": 1210.78,

      },
      {
        "Matter": "VENEZUELA LITIGATION FINANCING AGREEMENTS",
        "Status": "Open",
        "InvoiceNumber": "2688381",
        "DateEntered": "12\/17\/2020",
        "InvoiceDate": "10\/09\/2020",
        "Aging": 546,

        "Vendor": "Steptoe & Johnson LLP",


        "ExpenseType": "Unassigned",
        "Amount": 3752,
        "AmountToPay": 3752,

      },
      {
        "Matter": "VENEZUELA RECEIVABLES INVESTMENT",
        "Status": "Close",
        "InvoiceNumber": "2688382",
        "DateEntered": "12\/17\/2020",
        "InvoiceDate": "10\/09\/2020",
        "Aging": 546,

        "Vendor": "Steptoe & Johnson LLP",


        "ExpenseType": "Unassigned",
        "Amount": 416,
        "AmountToPay": 416,

      },
      {
        "Matter": "NEW LITIGATION FINANCING AGREEMENTS",
        "Status": "Open",
        "InvoiceNumber": "2688383",
        "DateEntered": "12\/17\/2020",
        "InvoiceDate": "10\/09\/2020",
        "Aging": 546,

        "Vendor": "Steptoe & Johnson LLP",


        "ExpenseType": "Unassigned",
        "Amount": 5587,
        "AmountToPay": 5587,

      },
      {
        "Matter": "New LFA work (matter #9)",
        "Status": "Open",
        "InvoiceNumber": "2688147",
        "DateEntered": "09\/02\/2020",
        "InvoiceDate": "09\/29\/2020",
        "Aging": 556,

        "Vendor": "Steptoe & Johnson LLP",


        "ExpenseType": "Funds\/Accounts",
        "Amount": 1602,
        "AmountToPay": 1602,
      },
      {
        "Matter": "Tax matter",
        "Status": "Close",
        "InvoiceNumber": "1436696",
        "DateEntered": "09\/24\/2020",
        "InvoiceDate": "09\/24\/2020",
        "Aging": 561,

        "Vendor": "DEBEVOISE AND PLIMPTON",


        "ExpenseType": "Management Company",
        "Amount": 69816,
        "AmountToPay": 69816,

      },
      {
        "Matter": "Argentina Opportunity",
        "Status": "Open",
        "InvoiceNumber": "9160016252",
        "DateEntered": "09\/29\/2020",
        "InvoiceDate": "09\/24\/2020",
        "Aging": 561,

        "Vendor": "SEWARD AND KISSEL",


        "ExpenseType": "Unassigned",
        "Amount": 87.5,
        "AmountToPay": 87.5,

      },
      {
        "Matter": "Audit Letters",
        "Status": "Close",
        "InvoiceNumber": "9160016250",
        "DateEntered": "09\/29\/2020",
        "InvoiceDate": "09\/24\/2020",
        "Aging": 561,

        "Vendor": "SEWARD AND KISSEL",


        "ExpenseType": "Unassigned",
        "Amount": 3287.5,
        "AmountToPay": 3287.5,

      },
      {
        "Matter": "Distressed Argentina Fund",
        "Status": "Open",
        "InvoiceNumber": "9160016249",
        "DateEntered": "09\/29\/2020",
        "InvoiceDate": "09\/24\/2020",
        "Aging": 561,

        "Vendor": "SEWARD AND KISSEL",


        "ExpenseType": "Unassigned",
        "Amount": 218.75,
        "AmountToPay": 218.75,

      },
      {
        "Matter": "Emerging Markets Equities",
        "Status": "Close",
        "InvoiceNumber": "9160016251",
        "DateEntered": "09\/29\/2020",
        "InvoiceDate": "09\/24\/2020",
        "Aging": 561,

        "Vendor": "SEWARD AND KISSEL",


        "ExpenseType": "Unassigned",
        "Amount": 125,
        "AmountToPay": 125,

      },
      {
        "Matter": "Funds General (Fg)",
        "Status": "Open",
        "InvoiceNumber": "9160016255",
        "DateEntered": "09\/29\/2020",
        "InvoiceDate": "09\/24\/2020",
        "Aging": 561,

        "Vendor": "SEWARD AND KISSEL",


        "ExpenseType": "Unassigned",
        "Amount": 78.75,
        "AmountToPay": 78.75,

      },
      {
        "Matter": "Parb",
        "Status": "Close",
        "InvoiceNumber": "9160016253",
        "DateEntered": "09\/29\/2020",
        "InvoiceDate": "09\/24\/2020",
        "Aging": 561,

        "Vendor": "SEWARD AND KISSEL",


        "ExpenseType": "Unassigned",
        "Amount": 304.25,
        "AmountToPay": 304.25,

      },
      {
        "Matter": "NEW LITIGATION FINANCING AGREEMENTS",
        "Status": "Open",
        "InvoiceNumber": "2687297",
        "DateEntered": "09\/17\/2020",
        "InvoiceDate": "09\/16\/2020",
        "Aging": 569,

        "Vendor": "Steptoe & Johnson LLP",


        "ExpenseType": "Funds\/Accounts",
        "Amount": 12751,
        "AmountToPay": 12751,
      },
      {
        "Matter": "VENEZUELA RECEIVABLES INVESTMENT",
        "Status": "Close",
        "InvoiceNumber": "2684910",
        "DateEntered": "09\/02\/2020",
        "InvoiceDate": "08\/15\/2020",
        "Aging": 601,

        "Vendor": "Steptoe & Johnson LLP",


        "ExpenseType": "Funds\/Accounts",
        "Amount": 4165,
        "AmountToPay": 4165,
      },
      {
        "Matter": "FTA",
        "Status": "Close",
        "InvoiceNumber": "1434111",
        "DateEntered": "09\/30\/2020",
        "InvoiceDate": "07\/21\/2020",
        "Aging": 626,

        "Vendor": "DEBEVOISE AND PLIMPTON",


        "ExpenseType": "Unassigned",
        "Amount": 687292.3,
        "AmountToPay": 687292.3,

      },
      {
        "Matter": "Banro Corporation",
        "Status": "Open",
        "InvoiceNumber": "741788",
        "DateEntered": "09\/17\/2020",
        "InvoiceDate": "06\/29\/2020",
        "Aging": 648,

        "Vendor": "GOODMANS LLP",


        "ExpenseType": "Unassigned",
        "Amount": 16275.45,
        "AmountToPay": 16275.45,

      },
      {
        "Matter": "FTA",
        "Status": "Close",
        "InvoiceNumber": "1431806",
        "DateEntered": "09\/30\/2020",
        "InvoiceDate": "06\/24\/2020",
        "Aging": 653,

        "Vendor": "DEBEVOISE AND PLIMPTON",


        "ExpenseType": "Unassigned",
        "Amount": 156979.6,
        "AmountToPay": 156979.6,

      },
      {
        "Matter": "Banro Corporation",
        "Status": "Open",
        "InvoiceNumber": "740561",
        "DateEntered": "09\/17\/2020",
        "InvoiceDate": "05\/29\/2020",
        "Aging": 679,

        "Vendor": "GOODMANS LLP",


        "ExpenseType": "Unassigned",
        "Amount": 23948.31,
        "AmountToPay": 23948.31,

      },
      {
        "Matter": "Stoneway Group",
        "Status": "Open",
        "InvoiceNumber": "740562",
        "DateEntered": "09\/17\/2020",
        "InvoiceDate": "05\/29\/2020",
        "Aging": 679,

        "Vendor": "GOODMANS LLP",


        "ExpenseType": "Unassigned",
        "Amount": 208949.29,
        "AmountToPay": 208949.29,

      },
      {
        "Matter": "FTA",
        "Status": "Close",
        "InvoiceNumber": "1431094",
        "DateEntered": "09\/30\/2020",
        "InvoiceDate": "05\/26\/2020",
        "Aging": 682,

        "Vendor": "DEBEVOISE AND PLIMPTON",


        "ExpenseType": "Unassigned",
        "Amount": 228727.1,
        "AmountToPay": 228727.1,

      },
      {
        "Matter": "VENEZUELA RECEIVABLES INVESTMENT",
        "Status": "Open",
        "InvoiceNumber": "2677603C",
        "DateEntered": "12\/17\/2020",
        "InvoiceDate": "05\/26\/2020",
        "Aging": 682,

        "Vendor": "Steptoe & Johnson LLP",


        "ExpenseType": "Unassigned",
        "Amount": 936,
        "AmountToPay": 936,

      },
      {
        "Matter": "VENEZUELA RECEIVABLES INVESTMENT",
        "Status": "Close",
        "InvoiceNumber": "2678484B",
        "DateEntered": "12\/17\/2020",
        "InvoiceDate": "05\/26\/2020",
        "Aging": 682,

        "Vendor": "Steptoe & Johnson LLP",


        "ExpenseType": "Unassigned",
        "Amount": 728,
        "AmountToPay": 728,

      },
      {
        "Matter": "PUERTO RICO",
        "Status": "Close",
        "InvoiceNumber": "1427882",
        "DateEntered": "09\/29\/2020",
        "InvoiceDate": "04\/05\/2020",
        "Aging": 733,

        "Vendor": "DEBEVOISE AND PLIMPTON",


        "ExpenseType": "Funds\/Accounts",
        "Amount": 3717,
        "AmountToPay": 3717,

      },
      {
        "Matter": "Amos Global Energy",
        "Status": "Open",
        "InvoiceNumber": "421826",
        "DateEntered": "03\/04\/2021",
        "InvoiceDate": "02\/29\/2020",
        "Aging": 769,

        "Vendor": "MINTZ GROUP",

        "ExpenseType": "Funds\/Accounts",
        "Amount": 10635,
        "AmountToPay": 10635,

      },
      {
        "Matter": "PUERTO RICO",
        "Status": "Open",
        "InvoiceNumber": "1418469",
        "DateEntered": "09\/29\/2020",
        "InvoiceDate": "11\/11\/2019",
        "Aging": 879,

        "Vendor": "DEBEVOISE AND PLIMPTON",


        "ExpenseType": "Funds\/Accounts",
        "Amount": 8673,
        "AmountToPay": 8673,

      },
      {
        "Matter": "Class Action Appeal",
        "Status": "Open",
        "InvoiceNumber": "727520",
        "DateEntered": "09\/17\/2020",
        "InvoiceDate": "09\/20\/2019",
        "Aging": 931,

        "Vendor": "GOODMANS LLP",


        "ExpenseType": "Unassigned",
        "Amount": 3390.55,
        "AmountToPay": 3390.55,

      },
      {
        "Matter": "PAZOS DISPUTE",
        "Status": "Close",
        "InvoiceNumber": "1406592",
        "DateEntered": "09\/29\/2020",
        "InvoiceDate": "04\/18\/2019",
        "Aging": 1086,

        "Vendor": "DEBEVOISE AND PLIMPTON",


        "ExpenseType": "Unassigned",
        "Amount": 12490.12,
        "AmountToPay": 12490.12,

      },
      {
        "Matter": "PUERTO RICO",
        "Status": "Close",
        "InvoiceNumber": "1406590",
        "DateEntered": "09\/29\/2020",
        "InvoiceDate": "04\/18\/2019",
        "Aging": 1086,

        "Vendor": "DEBEVOISE AND PLIMPTON",


        "ExpenseType": "Funds\/Accounts",
        "Amount": 39208.83,
        "AmountToPay": 39208.83,

      },
      {
        "Matter": "PAZOS DISPUTE",
        "Status": "Close",
        "InvoiceNumber": "1404700",
        "DateEntered": "09\/29\/2020",
        "InvoiceDate": "12\/13\/2018",
        "Aging": 1212,

        "Vendor": "DEBEVOISE AND PLIMPTON",


        "ExpenseType": "Unassigned",
        "Amount": 33915.38,
        "AmountToPay": 33915.38,

      },
      {
        "Matter": "Gramercy Hedge Fund - Without Adverse Parties",
        "Status": "Close",
        "InvoiceNumber": "35286974",
        "DateEntered": "09\/30\/2020",
        "InvoiceDate": "03\/23\/2017",
        "Aging": 1842,

        "Vendor": "Mayer Brown",


        "ExpenseType": "Unassigned",
        "Amount": 5568,
        "AmountToPay": 5568,


      }
    ]
  }))


  const initialValues = {
    Matter: "",
    Status: "",
    InvoiceNumber: "",
    DateEntered: "",
    InvoiceDate: "",
    Aging: "",
    Vendor: "",
    ExpenseType: "",
    Amount: "",
    AmountToPay: "",

  }
  const validationSchema = Yup.object({
    Matter: Yup.string(),
    Status: Yup.string(),
    InvoiceNumber: Yup.string(),
    DateEntered: Yup.date(),
    InvoiceDate: Yup.date(),
    Aging: Yup.string(),
    Vendor: Yup.string(),
    ExpenseType: Yup.string(),
    Amount: Yup.string(),
    AmountToPay: Yup.string(),

  })

  return (
    <BasicDataTable title={title} data={InvoiceDetails.data} columns={[
      {
        label: "Matter",
        name: "Matter",
        options: {
          filter: true,
          sort: true,
        }
      },
      {
        label: "Status",
        name: "Status",
        options: {
          filter: true,
          sort: true,
          customBodyRender: (value: any, tableMeta: any, updateValue: any) => {
            return value == "Open" ? <TableBadge itemColor={value == "Open" ? "tablebage_success" : "tablebage_warning"} columnValue={value} />
              : <TableBadge itemColor={value == "Open" ? "tablebage_success" : "tablebage_warning"} columnValue={value} />

          }
        }
      },
      {
        label: "Invoice Number",
        name: "InvoiceNumber",
        options: {
          filter: false,
          sort: true,
        }
      },
      {
        label: "Date Entered",
        name: "DateEntered",
        options: {
          filter: false,
          sort: true,
        }
      },

      {
        label: "Invoice Date",
        name: "InvoiceDate",
        options: {
          filter: false,
          sort: true,
        }
      },
      {
        label: "Aging",
        name: "Aging",
        options: {
          filter: false,
          sort: true,
        }
      },


      {
        label: "Vendor",
        name: "Vendor",
        options: {
          filter: true,
          sort: true,
        }
      },
      {
        label: "Expense Type",
        name: "ExpenseType",
        options: {
          filter: true,
          sort: true,
        }
      },
      {
        label: "Amount",
        name: "Amount",
        options: {
          filter: true,
          sort: true,
        }
      },
      {
        label: "Amount To Pay",
        name: "AmountToPay",
        options: {
          filter: false,
          sort: true,
        }
      },
    ]} initialValues={initialValues} validationSchema={validationSchema} id="InvoiceDatatable" filterLabel={'Status'} filteredLabelText={['Open', 'Close', 'Status']} />

  )
}






