import { BasicDataTable } from '../../../shared-web/basicTable/BasicDataTable';
import * as Yup from 'yup'


interface Properties {
   title: string
}
export const DailyAum = (props: Properties) => {
   const { title } = props

   const AumData = JSON.parse(JSON.stringify({
      "data": [
         {
            "id": "1",
            "Vertical": "Alternatives",
            "Estimated AUM": "1,174,846,182"
         },
         {
            "id": "2",
            "Vertical": "Capital Solution",
            "Estimated AUM": "1,184,946,172"
         },
         {
            "id": "3",
            "Vertical": "EMD Long-Only",
            "Estimated AUM": "1,124,776,142"
         },
         {
            "id": "4",
            "Vertical": "Multi-Asset",
            "Estimated AUM": "1,284,946,192"
         },
         {
            "id": "1",
            "Vertical": "Alternatives",
            "Estimated AUM": "1,174,846,182"
         },
         {
            "id": "2",
            "Vertical": "Capital Solution",
            "Estimated AUM": "1,184,946,172"
         },
         {
            "id": "3",
            "Vertical": "EMD Long-Only",
            "Estimated AUM": "1,124,776,142"
         },
         {
            "id": "4",
            "Vertical": "Multi-Asset",
            "Estimated AUM": "1,284,946,192"
         },
         {
            "id": "1",
            "Vertical": "Alternatives",
            "Estimated AUM": "1,174,846,182"
         },
         {
            "id": "2",
            "Vertical": "Capital Solution",
            "Estimated AUM": "1,184,946,172"
         },
         {
            "id": "3",
            "Vertical": "EMD Long-Only",
            "Estimated AUM": "1,124,776,142"
         },
         {
            "id": "4",
            "Vertical": "Multi-Asset",
            "Estimated AUM": "1,284,946,192"
         },
         {
            "id": "1",
            "Vertical": "Alternatives",
            "Estimated AUM": "1,174,846,182"
         },
         {
            "id": "2",
            "Vertical": "Capital Solution",
            "Estimated AUM": "1,184,946,172"
         },
         {
            "id": "3",
            "Vertical": "EMD Long-Only",
            "Estimated AUM": "1,124,776,142"
         },
         {
            "id": "4",
            "Vertical": "Multi-Asset",
            "Estimated AUM": "1,284,946,192"
         },
         {
            "id": "1",
            "Vertical": "Alternatives",
            "Estimated AUM": "1,174,846,182"
         },
         {
            "id": "2",
            "Vertical": "Capital Solution",
            "Estimated AUM": "1,184,946,172"
         },
         {
            "id": "3",
            "Vertical": "EMD Long-Only",
            "Estimated AUM": "1,124,776,142"
         },
         {
            "id": "4",
            "Vertical": "Multi-Asset",
            "Estimated AUM": "1,284,946,192"
         },
         {
            "id": "1",
            "Vertical": "Alternatives",
            "Estimated AUM": "1,174,846,182"
         },
         {
            "id": "2",
            "Vertical": "Capital Solution",
            "Estimated AUM": "1,184,946,172"
         },
         {
            "id": "3",
            "Vertical": "EMD Long-Only",
            "Estimated AUM": "1,124,776,142"
         },
         {
            "id": "4",
            "Vertical": "Multi-Asset",
            "Estimated AUM": "1,284,946,192"
         },
         {
            "id": "1",
            "Vertical": "Alternatives",
            "Estimated AUM": "1,174,846,182"
         },
         {
            "id": "2",
            "Vertical": "Capital Solution",
            "Estimated AUM": "1,184,946,172"
         },
         {
            "id": "3",
            "Vertical": "EMD Long-Only",
            "Estimated AUM": "1,124,776,142"
         },
         {
            "id": "4",
            "Vertical": "Multi-Asset",
            "Estimated AUM": "1,284,946,192"
         },
         {
            "id": "1",
            "Vertical": "Alternatives",
            "Estimated AUM": "1,174,846,182"
         },
         {
            "id": "2",
            "Vertical": "Capital Solution",
            "Estimated AUM": "1,184,946,172"
         },
         {
            "id": "3",
            "Vertical": "EMD Long-Only",
            "Estimated AUM": "1,124,776,142"
         },
         {
            "id": "4",
            "Vertical": "Multi-Asset",
            "Estimated AUM": "1,284,946,192"
         },
         {
            "id": "1",
            "Vertical": "Alternatives",
            "Estimated AUM": "1,174,846,182"
         },
         {
            "id": "2",
            "Vertical": "Capital Solution",
            "Estimated AUM": "1,184,946,172"
         },
         {
            "id": "3",
            "Vertical": "EMD Long-Only",
            "Estimated AUM": "1,124,776,142"
         },
         {
            "id": "4",
            "Vertical": "Multi-Asset",
            "Estimated AUM": "1,284,946,192"
         },
         {
            "id": "1",
            "Vertical": "Alternatives",
            "Estimated AUM": "1,174,846,182"
         },
         {
            "id": "2",
            "Vertical": "Capital Solution",
            "Estimated AUM": "1,184,946,172"
         },
         {
            "id": "3",
            "Vertical": "EMD Long-Only",
            "Estimated AUM": "1,124,776,142"
         },
         {
            "id": "4",
            "Vertical": "Multi-Asset",
            "Estimated AUM": "1,284,946,192"
         },
         {
            "id": "1",
            "Vertical": "Alternatives",
            "Estimated AUM": "1,174,846,182"
         },
         {
            "id": "2",
            "Vertical": "Capital Solution",
            "Estimated AUM": "1,184,946,172"
         },
         {
            "id": "3",
            "Vertical": "EMD Long-Only",
            "Estimated AUM": "1,124,776,142"
         },
         {
            "id": "4",
            "Vertical": "Multi-Asset",
            "Estimated AUM": "1,284,946,192"
         },
         {
            "id": "1",
            "Vertical": "Alternatives",
            "Estimated AUM": "1,174,846,182"
         },
         {
            "id": "2",
            "Vertical": "Capital Solution",
            "Estimated AUM": "1,184,946,172"
         },
         {
            "id": "3",
            "Vertical": "EMD Long-Only",
            "Estimated AUM": "1,124,776,142"
         },
         {
            "id": "4",
            "Vertical": "Multi-Asset",
            "Estimated AUM": "1,284,946,192"
         }
      ]
   }))




   const initialValues = {
      id: "",

      Vertical: "",
      EstimatedAUM: "",

   }
   const validationSchema = Yup.object({




      id: Yup.string(),

      Vertical: Yup.string(),
      EstimatedAUM: Yup.string(),


   })


   return (
      <div><BasicDataTable title={title} data={AumData.data} columns={[



         {
            label: "Id",
            name: "id",
            options: {
               filter: false,
               sort: true,
            }
         },
         {
            label: "Vertical",
            name: "Vertical",
            options: {
               filter: true,
               sort: true,
            }
         },
         {
            label: "Estimated AUM",
            name: "Estimated AUM",
            options: {
               filter: true,
               sort: true,
            }
         },
      ]} initialValues={initialValues} validationSchema={validationSchema} id="dailyAumDatatable" />

      </div>


   )
}


