import { BasicDataTable } from '../../../shared-web/basicTable/BasicDataTable'
import { TableBadge } from '../../../shared-web/basicTable/TableBadge'
import * as Yup from 'yup'

interface Properties {
  title: string;
}

export const EmuDetails = (props: Properties) => {
  const { title } = props


  const EMUData: any = [
    {
      id: "1",
      Year: 2019,
      Employee: "Alex Soto",
      Status: "Approved",
      StartDate: "02/04/2020",
      StartTime: "Out All Day",
      EndDate: "02/06/2020",
      EndTime: "Out All Day",

      Comments: "Personal",
      ApprovedBy: "Sam",
    },
    {
      id: "2",
      Year: 2020,
      Employee: "Alex Soto",
      Status: "Approved",
      StartDate: "02/27/2020",
      StartTime: "Out All Day",
      EndDate: "02/06/2020",
      EndTime: "Out All Day",

      Comments: "Vacation",
      ApprovedBy: "Estela",
    },
    {
      id: "3",
      Year: 2019,
      Employee: "Soto",
      Status: "Rejected",
      StartDate: "05/18/2020",
      StartTime: "Out All Day",
      EndDate: "02/06/2020",
      EndTime: "Out All Day",

      Comments: "Sick",
      ApprovedBy: "Alex",
    },
    {
      id: "4",
      Year: 2020,
      Employee: "Alex Soto",
      Status: "Approved",
      StartDate: "06/23/2020",
      StartTime: "Out All Day",
      EndDate: "02/06/2020",
      EndTime: "Day",

      Comments: "Vacation",
      ApprovedBy: "Sam",
    },
    {
      id: "5",
      Year: 2021,
      Employee: "Soto",
      Status: "InProgress",
      StartDate: "06/24/2020",
      StartTime: "Half All Day",
      EndDate: "02/06/2020",
      EndTime: "Day",

      Comments: "Paternity",
      ApprovedBy: "Estela",
    },
    {
      id: "1",
      Year: 2019,
      Employee: "Alex Soto",
      Status: "Approved",
      StartDate: "02/04/2020",
      StartTime: "All Day",
      EndDate: "02/06/2020",
      EndTime: "Out ",

      Comments: "Personal",
      ApprovedBy: "Alex",
    },
    {
      id: "2",
      Year: 2020,
      Employee: "Soto",
      Status: "Approved",
      StartDate: "02/27/2020",
      StartTime: "Out All Day",
      EndDate: "02/06/2020",
      EndTime: "Out All Day",

      Comments: "Vacation",
      ApprovedBy: "Estela",
    },
    {
      id: "3",
      Year: 2019,
      Employee: "Alex Soto",
      Status: "Rejected",
      StartDate: "05/18/2020",
      StartTime: "Out All Day",
      EndDate: "02/06/2020",
      EndTime: "Day",

      Comments: "Sick",
      ApprovedBy: "Henrik",
    },
    {
      id: "4",
      Year: 2020,
      Employee: "Alex",
      Status: "Approved",
      StartDate: "06/23/2021",
      StartTime: "Out All Day",
      EndDate: "02/06/2020",
      EndTime: "Out",

      Comments: "Vacation",
      ApprovedBy: "Estela",
    },
    {
      id: "5",
      Year: 2021,
      Employee: "Alex Soto",
      Status: "Approved",
      StartDate: "06/24/2020",
      StartTime: "Half All Day",
      EndDate: "02/06/2020",
      EndTime: "Out All Day",

      Comments: "Paternity",
      ApprovedBy: "Alex",
    },
    {
      id: "1",
      Year: 2019,
      Employee: "Alex",
      Status: "Approved",
      StartDate: "02/04/2020",
      StartTime: "Out All Day",
      EndDate: "02/06/2021",
      EndTime: "Out All Day",

      Comments: "Sick",
      ApprovedBy: "Estela",
    },
    {
      id: "2",
      Year: 2020,
      Employee: "Alex Soto",
      Status: "Approved",
      StartDate: "02/27/2020",
      StartTime: "Out All Day",
      EndDate: "02/06/2020",
      EndTime: "Out All Day",

      Comments: "Vacation",
      ApprovedBy: "Estela",
    },
    {
      id: "3",
      Year: 2019,
      Employee: "Alex Soto",
      Status: "Rejected",
      StartDate: "05/19/2020",
      StartTime: "Out All Day",
      EndDate: "02/06/2020",
      EndTime: "Out All Day",

      Comments: "Sick",
      ApprovedBy: "Alex",
    },
    {
      id: "4",
      Year: 2020,
      Employee: "Soto",
      Status: "Approved",
      StartDate: "86/23/2021",
      StartTime: "All Day",
      EndDate: "04/06/2020",
      EndTime: "Out All Day",

      Comments: "Vacation",
      ApprovedBy: "Estela",
    },
    {
      id: "5",
      Year: 2021,
      Employee: "John",
      Status: "InProgress",
      StartDate: "12/24/2020",
      StartTime: "Out All Day",
      EndDate: "02/09/2020",
      EndTime: "Out All",

      Comments: "Paternity",
      ApprovedBy: "Alex",
    },
    {
      id: "1",
      Year: 2019,
      Employee: "Alex Soto",
      Status: "Approved",
      StartDate: "02/07/2020",
      StartTime: "Out All Day",
      EndDate: "02/09/2020",
      EndTime: "Half All Day",

      Comments: "Sick",
      ApprovedBy: "Estela",
    },
    {
      id: "2",
      Year: 2020,
      Employee: "Alex Soto",
      Status: "Approved",
      StartDate: "02/27/2020",
      StartTime: "Out All Day",
      EndDate: "02/06/2020",
      EndTime: "Out All Day",

      Comments: "Vacation",
      ApprovedBy: "Henrik",
    },
    {
      id: "3",
      Year: 2019,
      Employee: "Alex Soto",
      Status: "Rejected",
      StartDate: "05/18/2020",
      StartTime: "Out All Day",
      EndDate: "02/06/2020",
      EndTime: "Out All Day",

      Comments: "Sick",
      ApprovedBy: "Estela",
    },
    {
      id: "4",
      Year: 2020,
      Employee: "John",
      Status: "Approved",
      StartDate: "06/23/2021",
      StartTime: "Out All Day",
      EndDate: "02/06/2020",
      EndTime: "Out All Day",

      Comments: "Personal",
      ApprovedBy: "Alex",
    },
    {
      id: "5",
      Year: 2021,
      Employee: "Alex Soto",
      Status: "Approved",
      StartDate: "06/24/2020",
      StartTime: "Out All Day",
      EndDate: "02/06/2020",
      EndTime: "Half All Day",

      Comments: "Paternity",
      ApprovedBy: "Bill",
    },
    {
      id: "1",
      Year: 2019,
      Employee: "Alex Soto",
      Status: "Approved",
      StartDate: "02/04/2020",
      StartTime: "Out All Day",
      EndDate: "02/06/2020",
      EndTime: "Out All Day",

      Comments: "Sick",
      ApprovedBy: "Estela",
    },
    {
      id: "2",
      Year: 2020,
      Employee: "John",
      Status: "InProgress",
      StartDate: "02/27/2020",
      StartTime: "Out All Day",
      EndDate: "02/06/2020",
      EndTime: "Out All Day",

      Comments: "Vacation",
      ApprovedBy: "Ait",
    },
    {
      id: "3",
      Year: 2019,
      Employee: "Alex Soto",
      Status: "Rejected",
      StartDate: "05/18/2020",
      StartTime: "Out All Day",
      EndDate: "02/06/2020",
      EndTime: "Out All Day",

      Comments: "Sick",
      ApprovedBy: "Alex",
    },
    {
      id: "4",
      Year: 2020,
      Employee: "Alex Soto",
      Status: "Approved",
      StartDate: "06/23/2021",
      StartTime: "Out All Day",
      EndDate: "02/06/2020",
      EndTime: "Half All Day",

      Comments: "Vacation",
      ApprovedBy: "Estela",
    },
    {
      id: "5",
      Year: 2021,
      Employee: "Alex Soto",
      Status: "Approved",
      StartDate: "06/24/2020",
      StartTime: "Out All Day",
      EndDate: "02/06/2020",
      EndTime: "Out All Day",

      Comments: "Paternity",
      ApprovedBy: "Global",
    },
    {
      id: "1",
      Year: 2019,
      Employee: "Alex Soto",
      Status: "Approved",
      StartDate: "02/04/2020",
      StartTime: "Out All Day",
      EndDate: "02/06/2020",
      EndTime: "Out All Day",

      Comments: "Sick",
      ApprovedBy: "Alex",
    },
    {
      id: "2",
      Year: 2020,
      Employee: "Alex Soto",
      Status: "Approved",
      StartDate: "02/27/2020",
      StartTime: "Out All Day",
      EndDate: "02/06/2020",
      EndTime: "Out All Day",

      Comments: "Vacation",
      ApprovedBy: "Vp",
    },
    {
      id: "3",
      Year: 2019,
      Employee: "John",
      Status: "Rejected",
      StartDate: "05/18/2020",
      StartTime: "Out All Day",
      EndDate: "02/06/2020",
      EndTime: "Out All Day",

      Comments: "Personal",
      ApprovedBy: "Estela",
    },
    {
      id: "4",
      Year: 2020,
      Employee: "Alex Soto",
      Status: "Approved",
      StartDate: "06/23/2020",
      StartTime: "Out All Day",
      EndDate: "02/06/2020",
      EndTime: "Half All Day",

      Comments: "Sick",
      ApprovedBy: "Jp",
    },
    {
      id: "5",
      Year: 2021,
      Employee: "Alex Soto",
      Status: "InProgress",
      StartDate: "06/24/2020",
      StartTime: "Out All Day",
      EndDate: "02/06/2020",
      EndTime: "Out All Day",

      Comments: "Paternity",
      ApprovedBy: "Alex",
    },
    {
      id: "1",
      Year: 2019,
      Employee: "Alex Soto",
      Status: "Rejected",
      StartDate: "02/04/2020",
      StartTime: "Out All Day",
      EndDate: "02/06/2020",
      EndTime: "Out All Day",

      Comments: "Sick",
      ApprovedBy: "Estela",
    },
    {
      id: "2",
      Year: 2020,
      Employee: "Alex Soto",
      Status: "Approved",
      StartDate: "02/27/2020",
      StartTime: "Out All Day",
      EndDate: "02/06/2020",
      EndTime: "Out All Day",

      Comments: "Vacation",
      ApprovedBy: "Stefan",
    },
    {
      id: "3",
      Year: 2019,
      Employee: "John",
      Status: "Rejected",
      StartDate: "05/18/2020",
      StartTime: "Half All Day",
      EndDate: "02/06/2020",
      EndTime: "Out All Day",

      Comments: "Sick",
      ApprovedBy: "Alex",
    },
    {
      id: "4",
      Year: 2020,
      Employee: "Alex Soto",
      Status: "Approved",
      StartDate: "06/23/2020",
      StartTime: "Out All Day",
      EndDate: "02/06/2020",
      EndTime: "Out All Day",

      Comments: "Personal",
      ApprovedBy: "Estela",
    },
    {
      id: "5",
      Year: 2021,
      Employee: "Robot",
      Status: "Approved",
      StartDate: "06/24/2020",
      StartTime: "Out All Day",
      EndDate: "02/28/2020",
      EndTime: "Out All Day",

      Comments: "Paternity",
      ApprovedBy: "Stefan",
    },
    {
      id: "1",
      Year: 2019,
      Employee: "Alex Soto",
      Status: "Approved",
      StartDate: "02/14/2020",
      StartTime: "Out All Day",
      EndDate: "02/02/2020",
      EndTime: "Out All Day",

      Comments: "Sick",
      ApprovedBy: "Estela",
    },
    {
      id: "2",
      Year: 2020,
      Employee: "Robot",
      Status: "InProgress",
      StartDate: "02/27/2020",
      StartTime: "Half All Day",
      EndDate: "02/09/2020",
      EndTime: "Out All Day",

      Comments: "Vacation",
      ApprovedBy: "Alex",
    },
    {
      id: "3",
      Year: 2019,
      Employee: "Alex Soto",
      Status: "Rejected",
      StartDate: "05/18/2020",
      StartTime: "Out All Day",
      EndDate: "02/05/2020",
      EndTime: "Out All Day",

      Comments: "Sick",
      ApprovedBy: "Estela",
    },
    {
      id: "4",
      Year: 2020,
      Employee: "Alex Soto",
      Status: "Approved",
      StartDate: "06/23/2020",
      StartTime: "Half All Day",
      EndDate: "02/12/2020",
      EndTime: "Out All Day",

      Comments: "Personal",
      ApprovedBy: "Stefan",
    },
    {
      id: "5",
      Year: 2021,
      Employee: "Robot",
      Status: "Approved",
      StartDate: "06/24/2020",
      StartTime: "Out All Day",
      EndDate: "02/16/2020",
      EndTime: "Out All Day",

      Comments: "Paternity",
      ApprovedBy: "Estela",
    },
    {
      id: "1",
      Year: 2019,
      Employee: "Alex Soto",
      Status: "Approved",
      StartDate: "02/24/2020",
      StartTime: "Out All Day",
      EndDate: "02/03/2020",
      EndTime: "Out All Day",

      Comments: "Sick",
      ApprovedBy: "Alex",
    },
    {
      id: "2",
      Year: 2020,
      Employee: "Alex Soto",
      Status: "Approved",
      StartDate: "02/27/2020",
      StartTime: "Half All Day",
      EndDate: "02/08/2020",
      EndTime: "Out All Day",

      Comments: "Vacation",
      ApprovedBy: "Estela",
    },
    {
      id: "3",
      Year: 2019,
      Employee: "Robot",
      Status: "Rejected",
      StartDate: "05/18/2020",
      StartTime: "Out All Day",
      EndDate: "02/09/2020",
      EndTime: "Out All Day",

      Comments: "Sick",
      ApprovedBy: "Stefan",
    },
    {
      id: "4",
      Year: 2020,
      Employee: "Alex Soto",
      Status: "InProgress",
      StartDate: "06/23/2021",
      StartTime: "Out All Day",
      EndDate: "02/12/2020",
      EndTime: "Out All Day",

      Comments: "Personal",
      ApprovedBy: "Estela",
    },
    {
      id: "5",
      Year: 2021,
      Employee: "Alex Soto",
      Status: "Approved",
      StartDate: "06/24/2020",
      StartTime: "Out All Day",
      EndDate: "02/29/2020",
      EndTime: "Out All Day",

      Comments: "Paternity",
      ApprovedBy: "Stefan",
    },
    {
      id: "1",
      Year: 2019,
      Employee: "Robot",
      Status: "Approved",
      StartDate: "02/04/2020",
      StartTime: "Half All Day",
      EndDate: "02/18/2020",
      EndTime: "Out All Day",

      Comments: "Sick",
      ApprovedBy: "Estela",
    },
    {
      id: "2",
      Year: 2020,
      Employee: "Alex Soto",
      Status: "Approved",
      StartDate: "02/27/2020",
      StartTime: "Out All Day",
      EndDate: "02/20/2020",
      EndTime: "Out All Day",

      Comments: "Vacation",
      ApprovedBy: "Estela",
    },
    {
      id: "3",
      Year: 2019,
      Employee: "Alex Soto",
      Status: "Rejected",
      StartDate: "05/18/2020",
      StartTime: "Out All Day",
      EndDate: "02/07/2020",
      EndTime: "Out All Day",

      Comments: "Sick",
      ApprovedBy: "Stefan",
    },
    {
      id: "4",
      Year: 2020,
      Employee: "Robot",
      Status: "InProgress",
      StartDate: "06/23/2020",
      StartTime: "Out All Day",
      EndDate: "02/06/2020",
      EndTime: "Out All Day",

      Comments: "Personal",
      ApprovedBy: "Estela",
    },
    {
      id: "5",
      Year: 2021,
      Employee: "Alex Soto",
      Status: "Rejected",
      StartDate: "06/24/2020",
      StartTime: "Half All Day",
      EndDate: "02/06/2020",
      EndTime: "Out All Day",

      Comments: "Paternity",
      ApprovedBy: "Stefan",
    }, {
      id: "1",
      Year: 2019,
      Employee: "Alex Soto",
      Status: "Approved",
      StartDate: "02/04/2020",
      StartTime: "Out All Day",
      EndDate: "02/06/2020",
      EndTime: "Out All Day",

      Comments: "Sick",
      ApprovedBy: "Estela",
    },
    {
      id: "2",
      Year: 2020,
      Employee: "Robot",
      Status: "Approved",
      StartDate: "02/27/2020",
      StartTime: "Out All Day",
      EndDate: "02/06/2020",
      EndTime: "Out All Day",

      Comments: "Vacation",
      ApprovedBy: "Estela",
    },
    {
      id: "3",
      Year: 2019,
      Employee: "Alex Soto",
      Status: "Rejected",
      StartDate: "05/18/2020",
      StartTime: "Out All Day",
      EndDate: "02/06/2020",
      EndTime: "Out All Day",

      Comments: "Sick",
      ApprovedBy: "Alex",
    },
    {
      id: "4",
      Year: 2020,
      Employee: "Alex Soto",
      Status: "Approved",
      StartDate: "06/23/2020",
      StartTime: "Half All Day",
      EndDate: "02/06/2020",
      EndTime: "Out All Day",

      Comments: "Vacation",
      ApprovedBy: "Estela",
    },
    {
      id: "5",
      Year: 2021,
      Employee: "Robot",
      Status: "Approved",
      StartDate: "06/24/2020",
      StartTime: "Half All Day",
      EndDate: "02/06/2020",
      EndTime: "Out All Day",

      Comments: "Paternity",
      ApprovedBy: "Alex",
    },

  ]

  // const [initialData, setInitialData] = useState<any>(EMUData)

  // useEffect(()=>{
  //   setInitialData(EMUData)
  // },[initialData])


  const initialValues = {
    Year: "",
    Employee: "",
    Status: "",
    StartDate: "",
    StartTime: "",
    EndDate: "",
    EndTime: "",

    Comments: "",
    ApprovedBy: "",

  }
  const validationSchema = Yup.object({
    Year: Yup.string(),
    Employee: Yup.string(),
    Status: Yup.string(),
    StartDate: Yup.date(),
    StartTime: Yup.string(),
    EndDate: Yup.date(),
    EndTime: Yup.string(),


    Comments: Yup.string(),
    ApprovedBy: Yup.string(),


  })



  return (
    <div>

      <BasicDataTable title={title} data={EMUData} columns={[
        {
          label: "Year",
          name: "Year",
          options: {
            filter: true,
            sort: true,
          }
        },
        {
          label: "Employee",
          name: "Employee",
          options: {
            filter: true,
            sort: true,
          }
        },

        {
          label: "Status",
          name: "Status",
          options: {
            filter: true,
            sort: true,
            customBodyRender: (value: any, tableMeta: any, updateValue: any) => {

              return value == "Approved" ?

                <TableBadge itemColor={"tablebage_success"}



                  columnValue={value} />
                : <TableBadge itemColor={value == "Rejected" ? "tablebage_Danger" : "tablebage_warning"}



                  columnValue={value} />;

            },
          }
        },
        {
          label: "Start Date",
          name: "StartDate",
          options: {
            filter: false,
            sort: true,
          }
        },
        {
          label: "Start Time",
          name: "StartTime",
          options: {
            filter: false,
            sort: true,
          }
        },
        {
          label: "End Date",
          name: "EndDate",
          options: {
            filter: false,
            sort: true,
          }
        },
        {
          label: "End Time",
          name: "EndTime",
          options: {
            filter: false,
            sort: true,
          }
        },



        {
          label: "Comments",
          name: "Comments",
          options: {
            filter: false,
            sort: true,
          }
        },
        {
          label: "Approved By",
          name: "ApprovedBy",
          options: {
            filter: true,
            sort: true,
          }
        },
      ]} initialValues={initialValues} validationSchema={validationSchema} id="EmuDataTable" filterLabel={'Year'} filteredLabelText={[2019, 2020, 2021, 'Year']} />

    </div>
  )
}
