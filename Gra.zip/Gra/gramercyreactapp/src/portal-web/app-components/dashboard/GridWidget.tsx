/**
 * Grid Widget
 */

import React, { Component } from "react";
import { Responsive, WidthProvider } from "react-grid-layout";
import GridItem from './GridItem';
import { Layout } from 'react-grid-layout';
import { calculateLayout } from "../../services/dashboardServices";


const ResponsiveGridLayout = WidthProvider(Responsive);

interface GridLayoutState {
    componentRefData: any;
    showData: boolean;
    showComponent: boolean;
    existingId: boolean;
    newCounter: any;
}

interface GridLayoutProps {
    data: Array<any>;
    layouts: { [string: string]: Layout[] };
    sideMenuStatus: boolean;
    updateLayout(layout: Array<Layout>): void;
    updateBreakpoint(breakpoint: string): void;
    updateGridLayout(item: any): void;
    updatedDragWidgetSiderbar(item: any): void;
    updateDashoboardGridLayout: any;
}

class GridWidget extends Component<GridLayoutProps, GridLayoutState> {
    constructor(props: GridLayoutProps) {
        super(props);
        this.state = {
            componentRefData: [],
            showData: false,
            showComponent: false,
            existingId: false,
            newCounter: 10,

        };
        this.getRefOfComponent = this.getRefOfComponent.bind(this);
        this.onResizeStopActivity = this.onResizeStopActivity.bind(this);
        this.handleBreakPointChange = this.handleBreakPointChange.bind(this);
        this.onRemoveItem = this.onRemoveItem.bind(this);
        this.onDrop = this.onDrop.bind(this);
    }

    handleBreakPointChange(breakpoint: string) {
        this.props.updateBreakpoint(breakpoint);
        this.setState({ showData: false }, () => {
            this.setState({ showData: true });
        });


    };
    onResizeStopActivity(layout: Layout[], oldItem: Layout, newItem: Layout) {
        if (this.state.componentRefData && this.state.componentRefData.length > 0) {
            const index = layout.indexOf(newItem);
            if (this.state.componentRefData[index] !== null && this.state.componentRefData[index] !== undefined) {
                if (newItem.i === 'graph1') {
                    this.state.componentRefData[index].chart.reflow();
                } else if (newItem.i === 'graph2') {
                    this.state.componentRefData[index].chart.reflow();
                }
            }
        }

        this.props.updateLayout(layout);
    };

    componentDidMount() {
        this.setState({ showData: false }, () => {
            this.setState({ showData: true });
        });
    }
    // componentDidUpdate(prevProps: GridLayoutProps) {
    //     if (prevProps.sideMenuStatus !== this.props.sideMenuStatus) {
    //         this.setState({
    //             showComponent: !this.state.showComponent
    //         }, () => {
    //             setTimeout(() => {
    //                 this.setState({ showComponent: !this.state.showComponent });
    //             }, 300);
    //         });
    //     }
    // }

    onDrop = (layout: any, layoutItem: any, _event: any) => {
        const dragedElement = JSON.parse(_event.dataTransfer.getData('text'));
        const data = this.props.data;
        const newdata = data.some((obj) => {
            return obj.graphType == dragedElement.id
        })
        this.setState({ existingId: newdata });

        const extID = newdata ? 'graph' + this.state.newCounter : dragedElement.id;
        const newPanel: Layout = {
            i: extID,
            x: layoutItem.x,
            y: layoutItem.y,
            w: 1,
            h: 3,
            minW: 1,
            minH: 3,
            maxW: undefined,
            maxH: undefined,
            isDraggable: true,
            isResizable: true,
            isBounded: true,
            resizeHandles: ["se"],
            static: false
        };
        layout[layout.length - 1] = newPanel;
        const dataItem = { graphTitle: dragedElement.chartName, graphType: extID, }
        data.push(dataItem);
        this.props.updateGridLayout(data);
        this.props.updateLayout(layout);
        this.props.updatedDragWidgetSiderbar(data);
        this.setState({ newCounter: this.state.newCounter + 1 });
        this.forceUpdate();
    };

    render() {
        const { data, layouts } = this.props;
        const layoutc = calculateLayout(data.length, this.props.updateDashoboardGridLayout, layouts);
        const dashboardLayout = this.props.updateDashoboardGridLayout === 3 ? { lg: 3, md: 3, sm: 2, xs: 1, xxs: 1 } : { lg: 2, md: 2, sm: 1, xs: 1, xxs: 1 };
        return (
            <React.Fragment>
                {this.state.showData && !this.state.showComponent &&
                    <div style={{ width: "100vw!important" }}>
                        <ResponsiveGridLayout
                            className="layout"
                            layouts={layoutc}
                            onBreakpointChange={this.handleBreakPointChange}
                            isDraggable={true}
                            isResizable={false}
                            isBounded={true}
                            draggableHandle=".grid-item__title"
                            breakpoints={{ lg: 1280, md: 992, sm: 767, xs: 480, xxs: 0 }}
                            cols={dashboardLayout}
                            onResizeStop={this.onResizeStopActivity}
                            autoSize={true}
                            measureBeforeMount={true}
                            allowOverlap={false}
                            preventCollision={false}
                            onDrop={this.onDrop}
                            isDroppable={true}
                            rowHeight={135}
                            onDragStop={this.onResizeStopActivity}
                        >
                            {data.map((item, index) => <GridItem key={item.graphType} item={item} style getRef={(ref) => { this.getRefOfComponent(ref, index) }} removeItem={() => { this.onRemoveItem(index) }} />)}
                        </ResponsiveGridLayout>
                    </div>
                }
            </React.Fragment>
        );
    }
    getRefOfComponent(ref: any, index: number) {
        const componentRefData = this.state.componentRefData;
        componentRefData.push(ref);
        this.setState({ componentRefData: componentRefData });
    }
    onRemoveItem(index: number) {
        let graphType = this.props.data.splice(index, 1);
        this.props.layouts.lg = this.props.layouts.lg.filter(value => value.i != graphType[0].graphType);
        this.props.updateLayout(this.props.layouts.lg)
        this.props.updateGridLayout(this.props.data);
        this.props.updatedDragWidgetSiderbar(this.props.layouts.lg);
        this.forceUpdate();
    }
}

export default GridWidget;