/**
 * Grid Item
 */
import React, { forwardRef, useState } from 'react';
import LineChart from '../charts/LineChart';
import TotalGrowthBarChart from '../charts/TotalGrowthBarChart';
import ChartMixed from '../charts/ChartMixed';
import OverallData from '../charts/OverallBarChart';
import ArrowUpwardIcon from '@mui/icons-material/ArrowUpward';
import { Tooltip } from '@material-ui/core';
import { Menu, MenuItem } from '@mui/material';
import DialogBox from '../shared/modal/DialogBox';
import ArrowDownwardIcon from '@mui/icons-material/ArrowDownward';
import DailyAumTableChart from '../charts/DailyAumTableChart';
import ClearIcon from '@mui/icons-material/Clear';
import CalendarComponent from '../calendar/Calendar';
import { TableauIntegration } from '../shared/analytics/tableauIntegration/TableauIntegration';
import CompanyNewsWidget from '../news/CompanyNewsWidget';
import SSRSReportIntegration from '../shared/analytics/ssrsReportWidgets/SSRSReportIntegration';
import colors from '@styles/_themes-vars.module.scss';
import { DonutPieChartData, OverAllChartData } from '../charts/chartData/PieChartData';

interface GridItemProps {
    style: any;
    item: any;
    getRef(ref: any): void;
    removeItem(index: any): void;
}
const GridItem: React.FC<GridItemProps> = forwardRef<any, GridItemProps>(({ style, item, children, getRef, removeItem, ...rest }, ref) => {
    const width = parseInt(style.width, 10);
    const height = parseInt(style.height, 10) - 50;

    const [showItemType, setShowItemType] = useState('')
    const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
    const [showZoom, setShowZoom] = useState(false)
    const [showChart, setShowChart] = useState<any>(false)
    const [showTotalChart, setShowTotalChart] = useState<any>(false)

    const open = Boolean(anchorEl);
    const styleData = {
        ...style,
        "boxShadow": "0px 3px 11px 0 #b4b4b4"
    };

    const handleOnMenuItemSelect = (event: any) => {
        switch (event.target.id) {
            case 'lineChart':
                setShowItemType('graph4')
                break;
            case 'barChart':
                setShowItemType('graph2')
                break;
            case 'ColumnChart':
                setShowItemType('graph5')
                break;
            case 'PieChart':
                setShowItemType('graph3')
                break;
            case 'Calendar':
                setShowItemType('graph9')
                break;
            case 'Tableau Charts':
                setShowItemType('graph10')
                break;
            case 'SSRSReport':
                setShowItemType('SSRSReport')
                break;
            default:
                setShowItemType('')

        }
        setAnchorEl(null);
        console.log(showItemType)
    };

    const handleShowChartBtn = () => {
        setShowChart(!showChart)
    }

    const handleShowTotalChartBtn = () => {
        setShowTotalChart(!showTotalChart)
    }

    const handleOnZoomBtnClick = () => {
        setShowZoom(true)
    }

    const handleOnDialogBoxClose = () => {
        setShowZoom(false)
    }

    const renderChunkContent = () => {
        let value: any;
        switch (showItemType) {
            // case 'graph2':
            //     value = <ChartMixed width={width} height={height} getRef={getRef} />
            //     break;
            // case 'graph3':
            //     value = <OverallData chartData={overAllChartData()} />
            //     break;
            // case 'graph4':
            //     value = <LineChart width={width} height={height} getRef={getRef} showChart={showChart} handleShowChart={handleShowChartBtn} />
            //     break;
            // case 'graph5':
            //     value = <TotalGrowthBarChart isLoading={false} showTotalChart={showTotalChart} handleShowTotalChartBtn={handleShowTotalChartBtn} />
            //     break;


            default:
                switch (item.graphType) {
                    case 'graph1':
                        value = <TotalGrowthBarChart isLoading={false} showTotalChart={showTotalChart} handleShowTotalChartBtn={handleShowTotalChartBtn} />

                        break;
                    case 'graph2':
                        value = <DailyAumTableChart width={width} height={height} getRef={getRef} showChart={showChart} handleShowChart={handleShowChartBtn} />

                        break;
                    case 'graph3':
                        value = <ChartMixed width={width} height={height} getRef={getRef} />
                        break;
                    case 'graph4':
                        value = <OverallData chartData={OverAllChartData()} />
                        break;
                    case 'graph5':
                        value = <LineChart width={width} height={height} getRef={getRef} />
                        break;
                    case 'graph6':
                        value = <TotalGrowthBarChart isLoading={false} showTotalChart={showTotalChart} handleShowTotalChartBtn={handleShowTotalChartBtn} />
                        break;
                    case 'graph7':
                        value = <ChartMixed width={width} height={height} getRef={getRef} />
                        break;
                    case 'graph8':
                        value = <OverallData chartData={OverAllChartData()} />
                        break;
                    case 'graph9':
                        value = <CalendarComponent />
                        break;
                    case 'graph10':
                        value = <TableauIntegration />
                        break;
                    case 'graph11':
                        value = <OverallData chartData={DonutPieChartData()} />
                        break;
                    case 'CompanyNews':
                        value = <CompanyNewsWidget />
                        break;
                    case 'SSRSReport':
                        value = <SSRSReportIntegration />
                        break;
                    default:
                        value = <OverallData chartData={OverAllChartData()} />
                        break;
                }
        }


        return value
    }

    return (
        <div className={`grid-item `} style={styleData} {...rest}>
            <DialogBox openModel={showZoom} handleOnCloseBtn={handleOnDialogBoxClose}
                ModelCloseicon={
                    <Tooltip title="Zoom Out">
                        <ArrowDownwardIcon fontSize="medium" sx={{ transform: 'rotate(45deg)', color: colors.sTextColor }} />
                    </Tooltip>}
                HeaderTitle={item.graphTitle}>
                {renderChunkContent()}
            </DialogBox>
            <div className="grid-item__title">

                <div className="dragPanelTitle" style={{ "flex": "auto" }}>
                    {item.graphTitle}
                </div>
                <div style={{ "textAlign": "end" }}>
                    <Tooltip title={'Zoom In'}>

                        <ArrowUpwardIcon fontSize="medium" sx={{ transform: 'rotate( 45deg)' }} onClick={handleOnZoomBtnClick} className="zoomIcon" />
                    </Tooltip>

                    <Menu
                        id="basic-menu"
                        anchorEl={anchorEl}
                        open={open}
                        onClose={handleOnMenuItemSelect}
                        MenuListProps={{
                            'aria-labelledby': 'basic-button',
                        }}
                    >
                        <MenuItem id='lineChart' onClick={handleOnMenuItemSelect}>Line Chart</MenuItem>
                        <MenuItem id='barChart' onClick={handleOnMenuItemSelect}>Bar Chart</MenuItem>
                        <MenuItem id='ColumnChart' onClick={handleOnMenuItemSelect}>Column Chart</MenuItem>
                        <MenuItem id='PieChart' onClick={handleOnMenuItemSelect}>Pie Chart</MenuItem>
                        <MenuItem id='Calendar' onClick={handleOnMenuItemSelect}>Calendar</MenuItem>
                        <MenuItem id='Tableau Charts' onClick={handleOnMenuItemSelect}>Tableau Charts</MenuItem>
                        <MenuItem id='SSRSReport' onClick={handleOnMenuItemSelect}>SSRS Report Widgets</MenuItem>
                    </Menu>
                    <Tooltip title={'Remove Item'}>
                        <ClearIcon className='removeIcon' onClick={removeItem} />
                    </Tooltip>
                </div>

            </div>
            <div className="grid-item__graph">
                <div className="grid-item_inner">
                    {renderChunkContent()}
                </div>
            </div>
            {children}
        </div>
    );
});

export default GridItem;