import * as React from "react";
import Box from "@mui/material/Box";
import { useTheme } from "@mui/material/styles";
import MobileStepper from "@mui/material/MobileStepper";
import Paper from "@mui/material/Paper";
import Button from "@mui/material/Button";
import KeyboardArrowLeft from "@mui/icons-material/KeyboardArrowLeft";
import KeyboardArrowRight from "@mui/icons-material/KeyboardArrowRight";
import SwipeableViews from "react-swipeable-views";
import { autoPlay } from "react-swipeable-views-utils";
import Card from "@mui/material/Card";
import '../../pages/dashboard/dashboardStyles.scss';

const AutoPlaySwipeableViews = autoPlay(SwipeableViews);

const steps = [
  {
    label: "Friendly Reminder Friday Hours  ",
    description: `Dear all,Effective Friday, September 10 - Friday, May 27,
    2022 | Friday dismissal is 4pm.
    Thank you!`,
    Date: "9/17/2021",
  },
  {
    label: "Gramercy Online Store  ",
    description: `Dear all,
      For those of you who have not yet used your gift card, be sure to
      check out our  `,
    Date: '5/20/2019',
    link: <a href="https://gramercyonlinestore.com/"> Gramercy Online Store</a>,

  },
  {
    label: "  Bloomberg Video of Mohamed El-Erian  ",
    description: ` Dear all,
      Gramercy Funds Management names Mohamed A. El-Erian as Senior
      Advisor, he discusses the role on Bloomberg.TV below.
      View Video Mohamed El-Erian | Paradigm of Non-Payments in Emerging
      Markets Bloomberg News12/9/2020 
    Thank you!`,
    Date: '12/9/2020'
  },

  {
    label: "  Gramercy Amended Cash Bonus Plan  ",
    description: `Dear all,
    Please be advised that the Gramercy Amended Cash Bonus Plan which
    governs deferred bonus compensation is available for
    review by accessing the Quick Links (Benefits, Gramercy Amended
    Cash Bonus Plan).
  Thank you!`,
    Date: '9/17/2021'
  },

  {
    label: "Sweat Equity Reimbursement ",
    description: ` Dear all
      Please be advised that Oxford has expanded the Sweat Equity
      Reimbursement Program to include virtual workouts 
      (Peloton included)! If you have completed 50 workouts in the last
      6 months, you can submit for a reimbursement up to $200.
      Please see Gym Reimbursement form to submit.
    `,
    Date: '5/6/2021'
  },
];

const NewsCarousal = () => {
  const theme = useTheme();
  const [activeStep, setActiveStep] = React.useState(0);
  const [autoPlay, setAutoPlay] = React.useState(true);
  const maxSteps = steps.length;

  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleStepChange = (step: any) => {
    setActiveStep(step);
  };

  return (
    <Card
      className="News"
      sx={{ textAlign: "center", }}
    >
      <Box
        sx={{ maxWidth: "80", flexGrow: 10, p: 5 }}
      >
        <Paper
          square
          elevation={0}
          sx={{
            display: "flex",
            alignItems: "center",
            pl: 2,


          }}
        >

          <h2 className="w-100">
            {steps[activeStep].label}&nbsp;{steps[activeStep].Date}
          </h2>


        </Paper>

        <AutoPlaySwipeableViews
          axis={theme.direction === "rtl" ? "x-reverse" : "x"}
          index={activeStep}
          onChangeIndex={handleStepChange}
          enableMouseEvents
          resistance={true}
          autoplay={autoPlay}
        >
          {steps.map((step, index) => (
            <div key={step.label} style={{ cursor: "pointer" }} onMouseOver={() => {
              setAutoPlay(false);
            }}
              onMouseLeave={() => {
                setAutoPlay(true);
              }}>

              {Math.abs(activeStep - index) <= 1 ? (
                <Box
                  sx={{
                    maxWidth: 1000,
                    width: "100%",
                    p: 2,
                    textAlign: "center",

                  }}
                >
                  {steps[activeStep].description}{steps[activeStep].link}
                </Box>
              ) : null}
            </div>
          ))}
        </AutoPlaySwipeableViews>
        <MobileStepper
          variant="text"
          steps={maxSteps}
          position="static"
          activeStep={activeStep}
          sx={{ textAlign: "center" }}
          nextButton={
            <Button
              size="small"
              onClick={handleNext}
              disabled={activeStep === maxSteps - 1}
            >
              Next
              {theme.direction === "rtl" ? (
                <KeyboardArrowLeft />
              ) : (
                <KeyboardArrowRight />
              )}
            </Button>
          }
          backButton={
            <Button
              size="small"
              onClick={handleBack}
              disabled={activeStep === 0}
            >
              {theme.direction === "rtl" ? (
                <KeyboardArrowRight />
              ) : (
                <KeyboardArrowLeft />
              )}
              Previous
            </Button>
          }
        />
      </Box>
    </Card>
  );
};
export default NewsCarousal;
