import NewsCarousal from "./NewsCarousal";
import { Card } from '@mui/material';
const CompanyNewsWidget = () => {
  return (
    <>
      <Card sx={{ p: '1%' }}>
        <NewsCarousal />
      </Card>
      <Card sx={{ p: '1%' }}>
      </Card>
    </>
  );
};

export default CompanyNewsWidget;
