import { Tab, Tabs, Typography } from '@mui/material'
import { Box } from '@mui/system';
import React, { ReactElement, useState } from 'react'
import './customTabs.scss';

interface Properties {
    tabData: {
        tabHeader: string | ReactElement;
        tabComponent: ReactElement;
        tabLabel: string

    }[]
}

export const CustomTabs: React.FunctionComponent<Properties> = (props) => {
    const { tabData } = props

    const [value, setValue] = useState(0)

    function TabPanel(props: any) {
        const { children, value, index, label, ...other } = props;

        return (
            <Typography component="div"
                role="tabpanel"
                hidden={value !== index}
                id={`${label}-${index}`}
                aria-labelledby={`${label}-${index}`}
                {...other}
            >
                {value === index && (
                    <Box sx={{ p: 2 }}>
                        <Typography component="span">{children}</Typography>
                    </Box>
                )}
            </Typography>
        );
    }

    const handleChange = (event: any, newValue: any) => {
        setValue(newValue);
    };
    return (
        <Box className="roootRightSidebar">
            <Tabs className='tabHeaderRoot'
                value={value}
                onChange={handleChange}
                aria-label="Custom Tabs"
            >
                {
                    tabData.map((tabData: any, index: any) => {
                        const { tabHeader } = tabData
                        return (
                            <Tab label={tabHeader} key={index} className="customTabHead" />
                        )
                    })
                }
            </Tabs>
            {

                tabData.map((tabData: any, tabIndex: number) => {
                    const { tabComponent, tabLabel } = tabData
                    return (
                        <TabPanel value={value} index={tabIndex} key={tabIndex} label={tabLabel}>
                            {tabComponent}
                        </TabPanel>
                    )
                })
            }
        </Box>
    )
}
