/**
 * Simple Calendar with event
 */
import React from 'react';
import FullCalendar from '@fullcalendar/react'
import dayGridPlugin from '@fullcalendar/daygrid'
import timeGridPlugin from '@fullcalendar/timegrid'
import interactionPlugin from '@fullcalendar/interaction'
import { INITIAL_EVENTS, createEventId } from './data/event'
import googleCalendarPlugin from '@fullcalendar/google-calendar';
import "./calendar.scss";
interface CalendarComponentProps {

}

interface CalendarComponentState {
    weekendsVisible: boolean;
    currentEvents: any;
}

class CalendarComponent extends React.Component<CalendarComponentProps, CalendarComponentState>{

    constructor(props: CalendarComponentProps) {
        super(props);
        this.state = {
            weekendsVisible: true,
            currentEvents: []
        }
    }

    render() {

        return (
            <div className='calendar-wrapper calenderBgColor'>
                <FullCalendar
                    plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
                    themeSystem='bootstrap5'
                    headerToolbar={{
                        left: 'prev,next today',
                        center: 'title',
                        right: 'dayGridMonth,timeGridWeek,timeGridDay'
                    }}
                    initialView='dayGridMonth'
                    editable={true}
                    selectable={true}
                    selectMirror={true}
                    dayMaxEvents={true}
                    weekends={this.state.weekendsVisible}
                    initialEvents={INITIAL_EVENTS} // alternatively, use the `events` setting to fetch from a feed
                    select={this.handleDateSelect}
                    eventClick={this.handleEventClick}
                    eventColor={'red'}
                    eventBackgroundColor={'red'}
                    eventTextColor={'white'}
                    views={{
                        dayGridMonth: {
                            dayHeaderFormat: { weekday: 'short' },
                            contentHeight: 400

                        }, timeGridDay: {
                            dayHeaderFormat: { weekday: 'long' },
                            contentHeight: 650
                        },
                        timeGridWeek: {
                            dayHeaderFormat: { weekday: 'narrow' },
                            contentHeight: 650
                        }
                    }
                    }
                // googleCalendarApiKey="AIzaSyAvu2YptqlQXux0zwPZ6RIDJ4L4Qu2JqtM"
                // events={{ googleCalendarId: "gnk3737@gmail.com" }}

                /* you can update a remote database when these fire:
                eventAdd={function(){}}
                eventChange={function(){}}
                eventRemove={function(){}}
                */
                />
            </div>
        );
    }

    handleWeekendsToggle = () => {
        this.setState({
            weekendsVisible: !this.state.weekendsVisible
        })
    }

    handleDateSelect = (selectInfo: any) => {
        let title = prompt('Please enter a new title for your event')
        let calendarApi = selectInfo.view.calendar

        calendarApi.unselect() // clear date selection

        if (title) {
            calendarApi.addEvent({
                id: createEventId(),
                title,
                start: selectInfo.startStr,
                end: selectInfo.endStr,
                allDay: selectInfo.allDay
            })
        }
    }

    handleEventClick = (clickInfo: any) => {
        clickInfo.event.remove()
    }

    handleEvents = (events: any) => {
        this.setState({
            currentEvents: events
        })
    }

}

export default CalendarComponent;