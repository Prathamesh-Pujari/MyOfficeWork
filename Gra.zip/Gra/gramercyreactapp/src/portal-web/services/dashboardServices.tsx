/**
 * Dashboard related utils
 */
import React from 'react';
import { Layout } from "react-grid-layout";

export const aumData = {
    columns: [
        {
            name: "name",
            label: "Vertical",
            options: {
                filter: true,
                sort: true,
            }
        },
        {
            name: "est",
            label: "Estimated AUM",
            options: {
                filter: true,
                sort: true,
            }
        },
        {
            name: "per",
            label: "% of Assets",
            options: {
                filter: true,
                sort: true,
            }
        }
    ],

    data: [
        {
            id: 1,
            name: 'Alternatives',
            est: '1,174,846,192',
            per: '23.60',
        },
        {
            id: 2,
            name: 'Capital Solutions',
            est: '1,182,594,168',
            per: '22.23',
        },
        {
            id: 3,
            name: 'EMD Long-Only',
            est: '1,183,865,471',
            per: '22.25',
        },
        {
            id: 4,
            name: 'Multi Asset',
            est: '1,031,303,190',
            per: '19.38',
        },
        {
            id: 5,
            name: 'Special Situations',
            est: '748,364,488',
            per: '14.06',
        }
    ]
};

export const aumOptions = (component: React.ReactNode) => {
    return {
        selectableRowsHideCheckboxes: true,
        print: false,
        searchable: false,
        pagination: false,
        draggableColumns: {
            enable: true
        },
        customToolbar: () => {
            return component;
        }
    }
};

export const rows = [
    {
        id: 1,
        name: 'Alternatives',
        est: '1,174,846,192',
        per: '22.08%',
    },
    {
        id: 2,
        name: 'Capital Solutions',
        est: '1,182,594,168',
        per: '22.23%',
    },
    {
        id: 3,
        name: 'EMD Long-Only',
        est: '1,183,865,471',
        per: '22.25%',
    },
    {
        id: 4,
        name: 'Multi Asset',
        est: '1,031,303,190',
        per: '19.38%',
    },
    {
        id: 5,
        name: 'Special Situations',
        est: '748,364,488',
        per: '14.06%',
    },
];

export const calculateLayout = (totalWidgets: number, columnCount: number, layout: { [string: string]: Layout[] }) => {
    let rem = totalWidgets % columnCount;
    let totalRows = 0;
    if (rem > 0) {
        totalRows = Math.floor(totalWidgets / columnCount) + 1;
    } else {
        totalRows = totalWidgets / columnCount;
    }

    layout.lg.sort((b, a) => b.x - a.x).sort((b, a) => b.y - a.y);

    let widgetUpdated = 0;
    for (let r = 0; r < totalRows; r++) {
        for (let c = 0; c < columnCount; c++) {
            if (widgetUpdated === totalWidgets) {
                break;
            } else {
                if (layout.lg[widgetUpdated]) {
                    layout.lg[widgetUpdated].x = c;
                    layout.lg[widgetUpdated].y = r;
                    widgetUpdated++;
                }
            }
        }
    }
    return layout;
};



export const layoutsData: { [string: string]: Layout[] } = {
    lg: [
        {
            "w": 1,
            "h": 3,
            "x": 0,
            "y": 0,
            "i": "graph1",
            "moved": false,
            "static": false,
            "isDraggable": true
        },
        {
            "w": 1,
            "h": 3,
            "x": 1,
            "y": 0,
            "i": "graph2",
            "moved": false,
            "static": false
        },
        {
            "w": 1,
            "h": 3,
            "x": 2,
            "y": 0,
            "i": "graph3",
            "moved": false,
            "static": false,
            "isDraggable": true,
            "resizeHandles": [
                "se"
            ]
        },
        {
            "w": 1,
            "h": 3,
            "x": 0,
            "y": 1,
            "i": "graph5",
            "moved": false,
            "static": false
        },
    ],

};

export const gridLayoutDisplay = [
    { graphTitle: 'Daily Performance', graphType: 'graph1' },
    { graphTitle: 'Daily AUM', graphType: 'graph2' },
    { graphTitle: 'AUM Progress', graphType: 'graph3' },
    { graphTitle: 'Employee Growth', graphType: 'graph5' },
];