import { UserPrefernces } from "../../shared-web/models/UserPreferncesModels";
import { apiPost } from "../../shared-web/baseServices/BaseService";

export const getUserPrefernces = (data: UserPrefernces) => {
  return apiPost("/portal/getUserPrefernces", data);
};

export const UpdateUserQuickLinks = (
  userId: string,
  UpdatedQuickLinks: string
) => {
  const data = {
    userId,
    json: UpdatedQuickLinks,
  };
  return apiPost("/portal/UpdateUserQuickLinks", data);
};
