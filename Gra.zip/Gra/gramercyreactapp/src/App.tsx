import React from "react";
import {
  StyledEngineProvider,
  ThemeProvider,
  CssBaseline,
} from "@mui/material";
import { bindActionCreators, Dispatch } from "redux";
import { connect } from "react-redux";

import "./App.css";
import { RootState } from "./shared-web/reducers/ReducerMain";
import { RoutesMain } from "./shared-web/routes/RoutesMain";
// defaultTheme
import themes from "./shared-web/themes/ThemeMain";
// project imports
import NavigationScroll from "./shared-web/layout/NavigationScroll";
import { AppProps, AppState, User } from "./shared-web/reducers/appReducer/types";
import * as AppActions from "./shared-web/reducers/appReducer/appActions";
import { getAppState } from "./shared-web/reducers/appReducer/appSelector";
import { getLayoutState } from "./shared-web/reducers/layoutReducer/layoutSelector";

class App extends React.Component<AppProps, AppState> {
  constructor(props: AppProps) {
    super(props);
    this.state = {
      user: {
        isLoggedIn: false,
      },
    };
  }

  render() {
    const user: User = this.props.user ? this.props.user : this.state.user;

    return (
      <StyledEngineProvider injectFirst>
        <ThemeProvider theme={themes(this.props.theme)}>
          <CssBaseline />
          <NavigationScroll>
            <RoutesMain isLoggedIn={user.isLoggedIn} />
          </NavigationScroll>
        </ThemeProvider>
      </StyledEngineProvider>
    );
  }
}

function mapStateToProps(state: RootState) {
  return {
    ...getAppState(state),
    theme: getLayoutState(state),
  };
}
function mapDispatchToProps(dispatch: Dispatch) {
  return {
    actions: bindActionCreators(Object.assign({}, AppActions) as any, dispatch),
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(App);
