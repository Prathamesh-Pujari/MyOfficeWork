export interface GetQuery {
    query: string;
}
export interface createWidgetStepOne {
    widgetSourceQueryName: string,
    widgetSourceQuery: string
    status: string,
    createdBy: string
}
