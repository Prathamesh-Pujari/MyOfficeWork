export interface UserPrefernces {
  userId: string;
  userActiveWidgets: string;
  userQuickLinks: string;
  userDashBoard: string;
}
