export interface GenericOption {
  id: any;
  text: string;
}
