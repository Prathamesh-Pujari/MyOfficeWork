/**
 *  Theme constant
 */

export const gridSpacing = 3;
// export const drawerWidth = 240; //260 default
// export const drawerWidth = 240; //260 default

// export const miniDrawerWidth = 80; //80 default
// export const appDrawerWidth = 320;
