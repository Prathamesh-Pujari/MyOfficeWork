/* eslint-disable react/jsx-no-useless-fragment */
import React, { forwardRef, useCallback, useEffect, useMemo, Ref } from "react";
import ReactDOM from "react-dom";
import styles from "./PopUp.module.scss";
// import { Icon, IconType } from "../icon/Icon";
import CloseIcon from "@mui/icons-material/Close";

interface Properties extends React.ButtonHTMLAttributes<HTMLInputElement> {
  header?: string;
  width?: string;
  height?: string;
  popupType?: "form" | "information";
  headerImg?: string;
  showClose?: boolean;
  bodyClassName?: string;
  contentClassName?: string;
  onClose(): void;
}

const portalContainer = document.body;

const PopUpInternal = (
  props: Properties,
  ref: Ref<HTMLDivElement>
): JSX.Element => {
  const { className, contentClassName, bodyClassName } = props;

  useEffect(() => {
    portalContainer.classList.add(styles.disableScroll);

    return (): void => {
      portalContainer.classList.remove(styles.disableScroll);
    };
  }, []);

  const renderCloseIcon = useCallback((): JSX.Element => {
    return (
      <div className={styles["close-popup"]} onClick={props.onClose}>
        {/* <Icon type={IconType.Times} /> */}
        <CloseIcon />
      </div>
    );
  }, [props]);

  const closeIcon = useMemo(
    () => (props.showClose ?? true) && renderCloseIcon(),
    [props.showClose, renderCloseIcon]
  );

  const style = useMemo<React.CSSProperties>(
    () => ({
      maxWidth: props.width,
      minHeight: props.height,
    }),
    [props]
  );

  const header = useMemo((): JSX.Element => {
    return (
      <div className={styles["modal-header-popup"]}>
        <h3>
          {props.header}
          {closeIcon}
        </h3>
        <hr />
      </div>
    );
  }, [props, closeIcon]);

  return portalContainer ? (
    ReactDOM.createPortal(
      <>
        <div
          className={styles["modal-overlay-popup"]}
          onClick={props.onClose}
        />
        <div
          ref={ref}
          className={`${styles["modal-popup"]} ${className ?? ""}`}
        >
          <div
            className={`${styles["modal-content-popup"]} ${
              contentClassName ?? ""
            }`}
            style={style}
          >
            {props.header && header}
            {!props.header && closeIcon}
            <div
              className={`${styles["modal-body-popup"]} ${bodyClassName ?? ""}`}
            >
              {props.children}
            </div>
          </div>
        </div>
      </>,
      portalContainer
    )
  ) : (
    <></>
  );
};

export const PopUp = forwardRef(PopUpInternal);

interface PopUpFooterProps {
  className?: string;
}

export const PopUpFooter = ({
  children,
  className = "",
}: React.PropsWithChildren<PopUpFooterProps>): JSX.Element => {
  return (
    <div
      className={`${className} d-flex justify-content-end border-top mt-4 pt-3`}
    >
      {children}
    </div>
  );
};
