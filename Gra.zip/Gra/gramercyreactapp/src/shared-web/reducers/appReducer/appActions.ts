/**
 * App Actions
 */

 import { createAction } from "redux-actions";
 
 
 export const Type = {
  DO_LOGIN: "DO_LOGIN",
  DO_LOGOUT: "DO_LOGOUT"
 };
 
 
 export const doLogin = createAction(
   Type.DO_LOGIN
 );

 export const doLogout = createAction(
  Type.DO_LOGOUT
);
