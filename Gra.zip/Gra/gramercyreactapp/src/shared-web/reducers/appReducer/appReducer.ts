/**
 * App reducer
 */
 import { handleActions } from "redux-actions";

 import { AppState } from './types';
 import * as AppActions from "./appActions";
 
 
 const initialState = {
    user: {
      isLoggedIn: false
    }
 };
 export const appReducer = handleActions<AppState, any>(
   {
     [AppActions.Type.DO_LOGIN]: (
       state,
       action: any
     ) => {
        return {
            ...state,
            user: {
              isLoggedIn: action.status
            }
        };
     },
     [AppActions.Type.DO_LOGOUT]: (
      state,
      action: any
    ) => {
       return {
           ...state,
           user: {
             isLoggedIn: false
           }
       };
    }
   },
   initialState
 );