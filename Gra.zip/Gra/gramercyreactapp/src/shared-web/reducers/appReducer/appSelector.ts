/**
 * App selectors
 */

import { createSelector } from 'reselect'
import { RootState } from '../ReducerMain';
// selector
const getData = (state: RootState) => state.app
// reselect function
export const getAppState = createSelector(
  [getData],
  (data) => data
)