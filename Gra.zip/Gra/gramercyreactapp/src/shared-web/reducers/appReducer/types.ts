import { LayoutState } from '../layoutReducer/layoutTypes';
/**
 * Types related to App
 */

export interface User {
    isLoggedIn: boolean;
}

export interface AppState {
    user: User;
}

export interface AppActions {
    doLogin(): void;
}
export interface AppProps {
    user: User;
    theme: LayoutState;
    action?: AppActions;
}