/**
 * Register types
 */

export interface PasswordStrengthColor{
    label: string;
    color: string;
}