/**
 * Layout Actions
 */
/**
 * Dashboard Actions
 */

import { createAction } from "redux-actions";


export const Type = {
  SET_BORDER_RADIUS: "SET_BORDER_RADIUS",
  SET_FONT_FAMILY: "SET_FONT_FAMILY",
  MENU_OPEN: "MENU_OPEN",
  SET_MENU: "SET_MENU"
};

export const menuOpen = createAction(
  Type.MENU_OPEN
);
export const setMenu = createAction(
  Type.SET_MENU
);
export const setData = createAction(
  Type.SET_BORDER_RADIUS
);
export const resetData = createAction(
  Type.SET_FONT_FAMILY
);