/**
 * Layout Reducer
 */

import { handleActions } from "redux-actions";

import { LayoutState } from './layoutTypes';
import * as LayoutActions from "./layoutActions";

const initialState = {
  isOpen: ['default'], // for active default menu
  fontFamily: `'Roboto', sans-serif`,
  borderRadius: 4,
  opened: true
};
export const layoutReducer = handleActions<LayoutState>(
  {
    [LayoutActions.Type.SET_BORDER_RADIUS]: (
      state,
      action: any
    ) => {
      return {
        ...state,
        borderRadius: action.borderRadius
      };
    },
    [LayoutActions.Type.SET_FONT_FAMILY]: (
      state,
      action: any
    ) => {
      return {
        ...state,
        fontFamily: action.fontFamily
      };
    },
    [LayoutActions.Type.MENU_OPEN]: (
      state,
      action: any
    ) => {
      const id = action.id;

      return {
        ...state,
        isOpen: [id]
      };
    },
    [LayoutActions.Type.SET_MENU]: (
      state,
      action: any
    ) => {
      return {
        ...state,
        opened: action.opened
      };
    }
  },
  initialState
);