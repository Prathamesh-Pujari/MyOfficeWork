/**
 * Layout selectors
 */

import { createSelector } from 'reselect'
import { RootState } from '../ReducerMain';
// selector
const getData = (state: RootState) => state.layout
const getSideMenuStatusData = (state: RootState) => state.layout.opened
// reselect function
export const getLayoutState = createSelector(
  [getData],
  (data) => data
)

export const getSideMenuOpenStatus = createSelector(
  [getSideMenuStatusData],
  (data) => data
)