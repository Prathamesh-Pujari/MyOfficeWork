/**
 * Layout types
 */

export interface LayoutState{
    isOpen: Array<any>;
    fontFamily: string;
    borderRadius: number;
    opened: boolean;
}