/**
 * Reducer index
 */

/* import { combineReducers } from "redux";
import { routerReducer as router, RouterState } from "react-router-redux";
import { DashboardState } from "../composition/dashboard/ducks/types";
import {dashboardReducer} from "../composition/dashboard/ducks/dashboardReducer";

const appReducer = combineReducers({
  router,
  dashboardReducer: dashboardReducer
});

export type ApplicationState  = ReturnType<typeof appReducer>;

export default appReducer; */

import { History } from "history";
import { combineReducers } from "redux";
import { routerReducer, RouterState } from 'react-router-redux'
import { DashboardState } from "../../portal-web/reducers/dashboardReducer/types";
import { dashboardReducer } from "../../portal-web/reducers/dashboardReducer/dashboardReducer";
import { appReducer } from "./appReducer/appReducer";
import { AppState } from './appReducer/types';
import { LayoutState } from './layoutReducer/layoutTypes';
import { layoutReducer } from './layoutReducer/layoutReducer';
import { AnalyticsState } from "../../portal-web/reducers/emuReducer/EmuTypes";
import { analyticsReducer } from "../../portal-web/reducers/emuReducer/EmuReducer";
import { HrState } from "../../portal-web/reducers/hrReducer/hrTypes";
import { hrReducer } from "../../portal-web/reducers/hrReducer/hrReducer";

export interface RootState {
	app: AppState,
	analytics: AnalyticsState,
	dashboard: DashboardState,
	hr: HrState,
	layout: LayoutState,
	routerReducer: RouterState
}

export default (history: History) =>
	combineReducers({
		app: appReducer,
		analytics: analyticsReducer,
		dashboard: dashboardReducer,
		hr: hrReducer,
		layout: layoutReducer,
		routerReducer,
	});