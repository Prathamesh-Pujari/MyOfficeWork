import React from "react";
import { Field, FormikErrors, FormikTouched } from "formik";
import { CheckBox, CheckboxType } from "../checkbox/Checkbox";
import { ReactNode } from "react";

interface Properties {
  id: string;
  name?: string;
  labelText?: ReactNode;
  isSelected?: boolean;
  className?: string;
  enableDefaultEvent?: boolean;
  type?: CheckboxType;
  disabled?: boolean;
  onClick?(id: string): void;
  sx?:any;
}

interface FieldFormik {
  field: {
    value: boolean;
  };
  form: {
    errors: FormikErrors<any>;
    submitCount: number;
    touched: FormikTouched<any>;
    setFieldValue(id: string, value: any): void;
  };
}

export class FormikCheckBox extends React.Component<Properties> {
  handleOnClick = (fieldFormik: FieldFormik, id: string): void => {
    fieldFormik.form.setFieldValue(id, !fieldFormik.field.value);
    this.props.onClick?.(this.props.id);
  };

  render(): JSX.Element {
    const { id, name, className, isSelected, labelText, disabled, type = CheckboxType.Checkbox,sx} = this.props;
    return (
      <Field name={id}>
        {(fieldFormik: FieldFormik): JSX.Element => {
          return (
            <CheckBox
              id={id}
              name={name ?? id}
              labelText={labelText}
              checked={fieldFormik.field.value ?? isSelected}
              className={className}
              disabled={disabled}
              type={type}
              onClick={this.handleOnClick.bind(this, fieldFormik, id)}
              enableDefaultEvent={this.props.enableDefaultEvent}
              sx={sx}
            />
          );
        }}
      </Field>
    );
  }
}
