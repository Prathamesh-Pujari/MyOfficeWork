import React, { useCallback, useMemo } from "react";
import { FormikErrors, FormikProps, useFormikContext } from "formik";
// import flatMapDepth from "lodash/flatMapDepth";
import "./FormikFormErrors.scss";
import { resolvePath } from "../helpers/util";
import { Alert } from "@mui/material";

interface Properties {
  namespace?: string | string[];
  errorsTitle?: string;
  className?: string;

  /**
   * @deprecated left for backwards compatibility
   */
  form?: FormikProps<any>;

  maxDepth?: number;
  requireSubmissionToShow?: boolean;
}

export const FormikFormErrors: React.FC<Properties> = props => {
  const { className, errorsTitle, maxDepth, requireSubmissionToShow = true } = props;

  const form = useFormikContext();

  const namespace = useMemo(() => props.namespace ?? "", [props.namespace]);
  const canShow = useMemo(() => (requireSubmissionToShow ? form.submitCount > 0 : true), [form.submitCount, requireSubmissionToShow]);

  const getErrorsToShow = useCallback((errors?: object | string, maxDepth = 1): string[] => {
    if (errors) {
      if (typeof errors === "string") {
        return [errors];
      } else if (Array.isArray(errors)) {
        // return flatMapDepth(errors, err => getErrorsToShow(err, maxDepth), maxDepth);
      } else if (typeof errors === "object") {
        if (maxDepth === 1) {
          return Object.values(errors).filter(err => typeof err === "string");
        }
        return getErrorsToShow(Object.values(errors), maxDepth);
      }
    }
    return [];
  }, []);

  const errors = useMemo(() => {
    if (namespace) {
      if (!Array.isArray(namespace)) {
        return resolvePath(form.errors, namespace) as FormikErrors<any>;
      } else {
        return namespace.reduce((acum, individualNamespace) => ({ ...acum, ...resolvePath(form.errors, individualNamespace) }), {});
      }
    }

    return form.errors;
  }, [form.errors, namespace]);

  const errorsToShow = useMemo(() => getErrorsToShow(errors, maxDepth), [errors, getErrorsToShow, maxDepth]);

  return errorsToShow.length > 0 && canShow ? (
    <div className={`alert alert-danger ${className ?? ""}`}>
      <Alert severity="error">
      {errorsTitle && <strong>{errorsTitle}</strong>}
      {errorsToShow.map((message: string, index: number) => (
        <div key={index} className="error">
          - {message}
        </div>
      ))}
      </Alert>
    </div>
  ) : null;
};
