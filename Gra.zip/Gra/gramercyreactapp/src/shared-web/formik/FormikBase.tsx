import { FormikErrors, FormikTouched } from "formik";

export interface FieldFormik<T> {
  field: {
    value: T;
    onChange: any;
    name: string;
    onBlur: any;
  };
  form: {
    errors: FormikErrors<any>;
    submitCount: number;
    touched: FormikTouched<any>;
    setFieldValue(id: string, value: T): void;
    setFieldValue(id: string, value: any): void;
  };
}
