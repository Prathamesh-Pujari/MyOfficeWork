import React from "react";
import { Field, FastField } from "formik";
import { GenericOption } from "../models/GenericOption";
import { Dropdown } from "../dropdown/Dropdown";
import { resolvePath } from "../helpers/util";
import { FieldFormik } from "./FormikBase";

interface Properties {
  id: string;
  placeholder?: string;
  className?: string;
  // options: GenericOption[];
  options: any;
  value?: any;
  isDisabled?: boolean;
  menuPlacement?: "auto" | "bottom" | "top";
  onChange?(value: any, fieldFormik: FieldFormik<any>): void;
  onBlur?(event: React.FocusEvent<any>): void;
  maxMenuHeight?: number;
}

export class FormikDropdown extends React.Component<Properties> {
  onChange = (fieldFormik: FieldFormik<any>, id: string | undefined, value: any): void => {
    if (id) {
      fieldFormik.form.setFieldValue(id, value);
    }
    this.props.onChange?.(value, fieldFormik);
  };

  render(): JSX.Element {
    const { id, isDisabled, className, value, options, onBlur, placeholder, menuPlacement, maxMenuHeight } = this.props;
    return (
      <Field id={id} name={id}>
        {(fieldFormik: FieldFormik<any>): JSX.Element => (
          <Dropdown
            id={id}
            isDisabled={isDisabled}
            menuPlacement={menuPlacement}
            className={
              className + (resolvePath(fieldFormik.form.errors, id) && (fieldFormik.form.touched[id] || fieldFormik.form.submitCount > 0) ? " is-invalid" : "")
            }
            options={options}
            placeholder={placeholder}
            value={fieldFormik.field.value ?? value}
            maxMenuHeight={maxMenuHeight}
            onChange={this.onChange.bind(this, fieldFormik, id)}
            onBlur={onBlur}
          />
        )}
      </Field>
    );
  }
}

export class FormikFastDropdown extends React.Component<Properties> {
  onChange = (fieldFormik: FieldFormik<any>, id: string | undefined, value: any): void => {
    id && fieldFormik.form.setFieldValue(id, value);
    this.props.onChange?.(value, fieldFormik);
  };

  render(): JSX.Element {
    const { id, isDisabled, className, value: value, options, onBlur, placeholder, menuPlacement } = this.props;
    return (
      <FastField id={id} name={id}>
        {(fieldFormik: FieldFormik<any>): JSX.Element => (
          <Dropdown
            id={id}
            isDisabled={isDisabled}
            menuPlacement={menuPlacement}
            className={
              className + (resolvePath(fieldFormik.form.errors, id) && (fieldFormik.form.touched[id] || fieldFormik.form.submitCount > 0) ? " is-invalid" : "")
            }
            options={options}
            placeholder={placeholder}
            value={fieldFormik.field.value ?? value}
            onChange={this.onChange.bind(this, fieldFormik, id)}
            onBlur={onBlur}
          />
        )}
      </FastField>
    );
  }
}
