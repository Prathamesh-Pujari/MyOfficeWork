export enum buttonVariants {
  text = "text",
  contained = "contained",
  outlined = "outlined",
}

export enum buttonTypeVariants {
  button = "Button",
  iconButton = "IconButton",
}

export enum btnColorType {
  inherit = "inherit",
  primary = "primary",
  secondary = "secondary",
  success = "success",
  error = "error",
  info = "info",
  warning = "warning",
}

export enum btnSizeType {
  small = "small",
  medium = "medium",
  large = "large",
}

export enum toolTipPositionType {
  top = 'top',
  bottomEnd = 'bottom-end',
  bottomStart = 'bottom-start',
  bottom = 'bottom',
  leftEnd = 'left-end',
  leftStart = 'left-start',
  left = 'left',
  rightEnd = 'right-end',
  rightStart = 'right-start',
  right = 'right',
  topEnd = 'top-end',
  topStart = 'top-start',
}

