import React, { ReactNode, useCallback, useMemo } from "react";
import { Label } from "../label/Label";
import "./Checkbox.scss";

export enum CheckboxType {
  Checkbox = "checkbox",
  Radio = "radio"
}

export enum CheckboxColor {
  Default = "default",
  Dark = "dark"
}

export interface Props {
  id?: string;
  name?: string;
  className?: string;
  labelText?: ReactNode;
  checked?: boolean;
  value?: string | number | boolean;
  disabled?: boolean;
  enableDefaultEvent?: boolean;
  type?: CheckboxType;
  color?: CheckboxColor;
  stopPropagation?: boolean;
  tooltip?: string;
  onClick?(value?: string | number): void;
  sx?:any;
}

export const CheckBox: React.FC<Props> = props => {
  const inputType = props.type ?? CheckboxType.Checkbox;

  const onClick = useCallback(
    (event: React.MouseEvent<HTMLDivElement, MouseEvent>): void => {
      if (props.stopPropagation) {
        event.stopPropagation();
      }
      const { onClick } = props;
      onClick?.(event.currentTarget.dataset["value"]);
      if (!props.enableDefaultEvent) {
        event.preventDefault();
      }
    },
    [props]
  );

  const renderedCheckbox = useMemo((): JSX.Element => {
    return (
      <div className={`"container" ${props.className}`} data-value={props.value} onClick={props.disabled ? undefined : onClick}>
        <input
          id={props.id}
          type={inputType}
          name={props.name ?? props.id}
          checked={props.checked ?? false}
          readOnly
          className={inputType === CheckboxType.Checkbox ? "checkbox" : "radio"}
          disabled={props.disabled}
          style={props.sx}
        />
        <Label text={props.labelText ?? ""} className={"label"} />
      </div>
    );
  }, [props, inputType, onClick]);

  return renderedCheckbox
};
