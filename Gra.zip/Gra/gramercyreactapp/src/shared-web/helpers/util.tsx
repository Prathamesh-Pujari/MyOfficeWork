export function partitionArray<T extends any>(array: T[], size: number): T[][] {
  const partitionArr = [];
  for (let i = 0; i < array.length; i++) {
    const last = partitionArr[partitionArr.length - 1];
    if (!last || last.length === size) {
      partitionArr.push([array[i]]);
    } else {
      last.push(array[i]);
    }
  }
  return partitionArr;
}

/**
 * Convert a string in snake_case or kebab-case into a camelCase one
 *
 * @param s String in snake_case or kebab-case
 *
 * @returns string in camelCase
 */
export function toCamel(s: string): string {
  return s.replace(/([-_][a-z])/gi, $1 => {
    return $1.toUpperCase().replace("-", "").replace("_", "");
  });
}

export function keysToCamel(o: any): any {
  const isObject = function (o: any) {
    return o === Object(o) && !Array.isArray(o) && typeof o !== "function";
  };

  if (isObject(o)) {
    const n: any = {};

    Object.keys(o).forEach(k => {
      n[toCamel(k)] = keysToCamel(o[k]);
    });

    return n;
  } else if (Array.isArray(o)) {
    return o.map(i => {
      return keysToCamel(i);
    });
  }

  return o;
}

export const resolvePath = (object: any, path: string): object | undefined => {
  try {
    return eval("object." + path);
  } catch (error) {
    return undefined;
  }
};
