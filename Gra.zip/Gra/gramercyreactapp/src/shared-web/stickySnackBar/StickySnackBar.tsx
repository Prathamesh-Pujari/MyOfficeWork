import { Snackbar } from '@material-ui/core'
import { Alert } from '@mui/material';
import React, { ReactElement } from 'react'



interface Properties {
    id?: string;
    showSnackBar: boolean;
    onClose?(): void;
    message: string;
    autoHideDuration?: number;
    anchorOrigin?: {
        vertical: 'bottom' | 'top';
        horizontal: 'center' | 'left' | 'right';
    }
    style?: object;
    severity?: 'error' | 'info' | 'success' | 'warning';
    variant?: 'filled' | 'outlined' | 'standard';
    sx?: object
    className?: string


}
const StickySnackBar: React.FunctionComponent<Properties> = ({ id, showSnackBar, onClose, severity = 'success', variant = 'standard', autoHideDuration = 3000, anchorOrigin = { vertical: "top", horizontal: "right" }, style = { borderRadius: "4px" }, message, className, sx = { width: '100%' } }): ReactElement => {
    return (

        <Snackbar key={id} open={showSnackBar} autoHideDuration={autoHideDuration} onClose={onClose} style={style} anchorOrigin={anchorOrigin} >
            <Alert onClose={onClose} severity={severity} variant={variant} className={className} sx={sx} >
                {message}
            </Alert>
        </Snackbar>

    )
}

export default StickySnackBar