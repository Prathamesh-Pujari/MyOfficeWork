import React from 'react'
import './TableStyle.scss'


interface Properties {
  itemColor: string,
  columnValue: string

}
export const TableBadge = (props: Properties) => {
  const { itemColor, columnValue } = props
  return (
    <span className={itemColor}>
      {columnValue}
    </span>
  )
}
