import React, { forwardRef } from 'react';
import { DataGrid } from '@mui/x-data-grid'
import { Typography } from '@mui/material';
import MUIDataTable from 'mui-datatables';
import './TableStyle.scss';

interface DataTableProps {
    id: string;
    className?: string;
    titleColor: string;
    title: string;
    titleFontSize: number;
    tableData: any;
    tableColumn: any;
    tableOptions: any;
    tableType: any;
    onTableInit?(action: string, tableState: Object): void;
}
const DataTable: React.FC<DataTableProps> = forwardRef<HTMLDivElement, DataTableProps>(({ id, className, titleColor, title, titleFontSize, tableData, tableColumn, tableOptions, tableType = 'mui', onTableInit }, ref) => {

    return (
        <React.Fragment>
            {tableType === 'mui' ?
                <MUIDataTable
                    title={<Typography fontSize={titleFontSize} color={titleColor}>{title}</Typography>}
                    data={tableData}
                    columns={tableColumn}
                    options={tableOptions}
                // onTableInit={onTableInit}
                />
                :
                <DataGrid
                    columns={tableColumn}
                    rows={tableData}
                />
            }
        </React.Fragment>

    )
});

const MuiDataTable: React.FC<DataTableProps> = ({ id, className, titleColor, title, titleFontSize, tableData, tableColumn, tableOptions, tableType = 'mui' }) => {

    return (
        <div id={id} className={className}>
            {tableType === 'mui' ?
                <MUIDataTable

                    title={<Typography fontSize={titleFontSize} color={titleColor}>{title}</Typography>}
                    data={tableData}
                    columns={tableColumn}
                    options={tableOptions}
                />
                :
                <DataGrid
                    columns={tableColumn}
                    rows={tableData}
                />
            }
        </div>

    )
};

export { DataTable, MuiDataTable };
