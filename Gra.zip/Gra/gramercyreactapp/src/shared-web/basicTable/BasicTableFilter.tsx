import {  FormControl, MenuItem, Select } from '@mui/material'

interface Properties{
    value:any; 
    label:any;
    MenuProps:any;
    handleOnChange(e:any):void;
    filteredLabelText?:any;
}

export const BasicTableFilter = (props:Properties) => {
  const {value,label,MenuProps,filteredLabelText,handleOnChange}=props
  return (
    <FormControl sx={{ m: 1, width: 100 }}>
    <Select
      id="demo-simple-select"
      labelId="demo-simple-select-label"
      label={label}
      value={value}
      onChange={handleOnChange}
      MenuProps={MenuProps}
      variant="standard"
      className='fliterInputField'
    >
        {filteredLabelText.map((value:any,index:any)=>{
         return <MenuItem defaultValue={label} className='fliterDropdownList' key={index} value={value}>{value}</MenuItem>
        })}    
    </Select>
  </FormControl>
  )
}
