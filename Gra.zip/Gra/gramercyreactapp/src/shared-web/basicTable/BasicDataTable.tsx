import { IconButton, Tooltip, Typography } from '@mui/material'
import MUIDataTable from 'mui-datatables'
import { useCallback, useEffect, useState } from 'react'
import './TableStyle.scss';
import "./tableStyles.scss";
import AddIcon from '@mui/icons-material/Add';
import { GenericPopUp } from '../../portal-web/app-components/shared/modal/tableModal/GenericPopUp'
import { Delete, Edit } from '@material-ui/icons'
import { BasicTableFilter } from './BasicTableFilter';
import StickySnackBar from '../stickySnackBar/StickySnackBar';
import { EditTableForm } from '../../portal-web/app-components/shared/tableForms/EditTableForm';
import { AddTableForm } from '../../portal-web/app-components/shared/tableForms/AddTableForm';

interface Properties {
  title: string,
  data: any,
  columns: any,
  initialValues: any,
  validationSchema: any;
  id: string;
  filterLabel?: string;
  filteredLabelText?: any;
}

export const BasicDataTable = (props: Properties) => {
  const { title, data, columns, validationSchema, initialValues, id, filterLabel, filteredLabelText } = props
  const [tableData, setTableData] = useState<any>(data);
  const [filter, setFilter] = useState<any>(filterLabel);
  const [filteredData, setFilteredData] = useState<any>(tableData);
  const [editableData, setEditableData] = useState<any>();
  const [editpopUpVisible, setEditPopUpVisible] = useState(false);
  const [addPopUpVisible, setAddPopUpVisible] = useState(false);

  const [editingDataIndex, setEditingDataIndex] = useState();
  const [deletedFilteredData, setDeletedFilteredData] = useState();
  const [showDeleteSnackBar, setShowDeleteSnackBar] = useState(false);

  const [showEditSnackBar, setShowEditSnackBar] = useState(false);


  const handleRenderTitle = () => {
    return <Typography className='tableTitleHeader'>{title}</Typography>
  }



  const handleOnChange = (event: any) => {
    const {
      target: { value },
    } = event;
    setFilter(value);
  };


  useEffect(() => {

    setFilteredData(
      filter === filterLabel
        ? tableData
        : tableData.filter((value: any) => value[filterLabel!] === filter)
    )

  }, [filterLabel, tableData, filter]);


  const ITEM_HEIGHT = 100;
  const ITEM_PADDING_TOP = 10;
  const MenuProps = {
    PaperProps: {
      style: {
        maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
        width: 100,
      },
    },
  };

  const handleOnEditBtnClick = (dataIndex: any) => {
    setEditableData(filteredData[dataIndex])
    setEditingDataIndex(dataIndex)
    setEditPopUpVisible(true)
  }

  const handleOnDeleteBtnClick = useCallback((dataIndex: any) => {

    filteredData.splice(dataIndex, 1)

    setShowDeleteSnackBar(true)
  }, [filteredData])

  const handleCloseDeleteSnackBar = () => {
    setShowDeleteSnackBar(false);

    setShowEditSnackBar(false);
  }


  const handleCloseEditSnackBar = () => {
    setShowEditSnackBar(false);
  }

  const TableColumns = [
    {
      name: "Actions",
      options: {
        filter: false,
        sort: false,
        empty: true,


        customBodyRenderLite: (data: any, dataIndex: any, rowIndex: any) => {
          return (<div className='editIcon'>
            <Tooltip title="Edit">
              <IconButton
                onClick={() => handleOnEditBtnClick(dataIndex)}
              >
                <Edit />
              </IconButton>
            </Tooltip>
            <Tooltip title="Delete">
              <IconButton
                onClick={() => handleOnDeleteBtnClick(dataIndex)}

              >
                <Delete />
              </IconButton>
            </Tooltip>

          </div>
          )
        }
      }
    },
    ...columns
  ]



  const handleOnUpdate = (data: any) => {
    setDeletedFilteredData(filteredData[editingDataIndex!] = data)
    setEditPopUpVisible(false)
    setShowEditSnackBar(true);
  }

  const handleOnConfirm = (data: any) => {
    filteredData.unshift(data);
    setAddPopUpVisible(false);

  }

  const handleOnEditPopUpClose = () => {
    setEditPopUpVisible(false)
  }
  const handleOnAddPopUpClose = () => {
    setAddPopUpVisible(false)
  }

  const handleOnAddBtnClick = () => {
    setAddPopUpVisible(true)
  }

  return (
    <div className="basicTableCustom">
      <GenericPopUp open={editpopUpVisible} handleonClose={handleOnEditPopUpClose} title={"Edit Record"} handleOnConfirm={handleOnUpdate} >
        <EditTableForm title={title} onClose={handleOnEditPopUpClose} initialValue={editableData} validationSchema={validationSchema} handleOnUpdate={handleOnUpdate} />
      </GenericPopUp>

      <GenericPopUp title={'Add New Records'} open={addPopUpVisible} handleOnConfirm={handleOnConfirm} handleonClose={handleOnAddPopUpClose} >
        <AddTableForm title={title} handleOnSave={handleOnConfirm} onClose={handleOnAddPopUpClose} initialValue={initialValues} validationSchema={validationSchema} />
      </GenericPopUp>



      <MUIDataTable
        title=""
        key={id}
        data={filteredData}
        columns={TableColumns}

        options={{
          download: true,
          filter: true,
          rowsPerPage: 20,
          rowsPerPageOptions: [20, 30],
          draggableColumns: {
            enabled: true,
          },

          elevation: 4,
          filterType: "dropdown",
          fixedHeader: true,
          pagination: true,
          print: true,
          responsive: "vertical",
          rowHover: true,
          search: true,
          searchPlaceholder: "Search",
          searchOpen: false,
          selectableRows: "multiple",
          sort: true,
          viewColumns: true,
          customToolbar: () => {
            return <span >
              <Tooltip title="Add">
                <IconButton onClick={handleOnAddBtnClick}>
                  <AddIcon />
                </IconButton>
              </Tooltip>
              {filteredLabelText && <BasicTableFilter value={filter} label={filterLabel} MenuProps={MenuProps} filteredLabelText={filteredLabelText} handleOnChange={handleOnChange} />}
            </span>
          }

        }}
      />

      <StickySnackBar showSnackBar={showEditSnackBar} onClose={handleCloseEditSnackBar} message={"Row edited succesfully"} className="tableMsg" />
      <StickySnackBar showSnackBar={showDeleteSnackBar} onClose={handleCloseDeleteSnackBar} message=" Row deleted succesfully" className="tableMsg" />


    </div>)
}