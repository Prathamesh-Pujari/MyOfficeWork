import { createContext } from "react";

export interface StepperContextProvider {
    activeStep: number;
    handleOnNextStep(): void;
    handleOnBackStep(): void;
}

export const StepperProviderContext = createContext<StepperContextProvider>(
    {} as StepperContextProvider
);

export const StepperProvider = StepperProviderContext.Provider;