import * as React from "react";
import Box from "@mui/material/Box";
import Stepper from "@mui/material/Stepper";
import Step from "@mui/material/Step";
import StepLabel from "@mui/material/StepLabel";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import { useActiveSteps } from "../hooks/useActiveSteps";
import { StepperProviderContext } from "./StepperContextProvider";

interface StepperValue {
  stepsContent: any;
  selectedSteps: string[];
}

const Steppers: React.FC<StepperValue> = (props) => {

  const { activeStep } = React.useContext(StepperProviderContext);

  return (
    <Box className="stepperMain">
      <Box mb={5} mt={5}>
        <Stepper activeStep={activeStep} alternativeLabel>
          {props.selectedSteps.map((label: string) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>
      </Box>
      {activeStep === props.selectedSteps.length ? (
        <React.Fragment>
          <Typography variant="h3" align="center">
            Widget submitted
          </Typography>
        </React.Fragment>
      ) : (
        <React.Fragment>
          <Typography sx={{ mt: 2, mb: 1 }}>
            {props.stepsContent(activeStep)}
          </Typography>
          <Box sx={{ display: "flex", flexDirection: "row", pt: 2, mt: 5 }}>
            {/* <Button
              color="inherit"
              disabled={currentStep === 0}
              onClick={handleBack}
              sx={{ mr: 1 }}
            >
              Back
            </Button> */}

            {/* <Button onClick={handleNext}>
              {activeStep === props.selectedSteps.length - 1
                ? "Publish Widget"
                : "Confirm Selection"}
            </Button> */}
          </Box>
        </React.Fragment>
      )}
    </Box>
  );
};

export default Steppers;
