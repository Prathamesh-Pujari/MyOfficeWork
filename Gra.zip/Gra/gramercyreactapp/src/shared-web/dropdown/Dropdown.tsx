import React from "react";
import Select, { ValueType } from "react-select";
import "./Dropdown.scss";
import { GenericOption } from "../models/GenericOption";

interface Properties {
  id?: string;
  placeholder?: string;
  className?: string;
  classNamePrefix?: string;
  options: GenericOption[];
  value?: any;
  isDisabled?: boolean;
  menuPlacement?: "auto" | "bottom" | "top";
  maxMenuHeight?: number;
  onChange?(value: any): void;
  onBlur?(e: React.FocusEvent<any>): void;
}

interface DropdownItem {
  value: string;
  label: string;
}

export class Dropdown extends React.Component<Properties> {
  constructor(props: Properties) {
    super(props);
  }

  getOptions = (): { value: string; label: string }[] => {
    return this.props.options.map(this.convertToDropdownItem);
  };

  private convertToDropdownItem = (option: GenericOption): { value: any; label: string } => {
    return { value: option.id, label: option.text };
  };

  onChange = (optionSelected: ValueType<{ value: string; label: string }, boolean>): void => {
    const dropdownItem = optionSelected as DropdownItem;
    if (this.props.onChange && dropdownItem.value !== this.props.value) {
      this.props.onChange(dropdownItem.value);
    }
  };

  getSelectedOption = (): DropdownItem | null => {
    let option = undefined;
    option = this.props.options.find((option: GenericOption) => {
      return option.id === this.props.value;
    });

    if (option) {
      return this.convertToDropdownItem(option);
    } else {
      return null;
    }
  };

  render(): JSX.Element {
    const { id, className, placeholder, isDisabled, menuPlacement, maxMenuHeight, onBlur } = this.props;
    const selectedOption = this.getSelectedOption();
    const options = this.getOptions();
    const customStyles = {
      control: (base: any) => ({
        ...base,
        minHeight: 0,
        /*  border: "none", */
        boxShadow: "none"
      }),
      dropdownIndicator: (base: any) => ({
        ...base,
        paddingTop: 0,
        paddingBottom: 0
      }),
      menu: (base: any) => ({
        ...base,
        zIndex: 9999
      })
    };
    return (
      <Select
        styles={customStyles}
        menuPlacement={menuPlacement}
        isDisabled={isDisabled}
        placeholder={placeholder}
        className={`${className ?? ""}`}
        onChange={this.onChange}
        value={selectedOption}
        options={options}
        onBlur={onBlur}
        inputId={id}
        classNamePrefix={`${this.props.classNamePrefix ?? ""} defaultDropdown`}
        maxMenuHeight={maxMenuHeight}
        components={{
          IndicatorSeparator: () => null
        }}
      />
    );
  }
}
