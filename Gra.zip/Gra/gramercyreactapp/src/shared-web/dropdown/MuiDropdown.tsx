import { MenuItem, OutlinedInput, Select, SelectChangeEvent } from "@mui/material"
import { ChangeEvent } from "react";
import "./MuiDropdown.scss";

interface Properties {
    id: string;
    value?: string;
    onChange(value: SelectChangeEvent<string>): ChangeEvent<HTMLInputElement>;
    options: any;
    defaultValue?:string;
}

export const MuiDropdown: React.FC<Properties> = props => {
    const { id, value, onChange, options,defaultValue } = props;
    return (
        <Select
            id={id}
            value={value}
            input={<OutlinedInput />}
            onChange={onChange}
            variant="filled"
            className="muiDropdown"
            defaultValue={defaultValue}
        >
            {options.map((option: any) => (
                <MenuItem key={option.id} value={option.id}>
                    {option.text}
                </MenuItem>
            ))}
        </Select>
    )
}