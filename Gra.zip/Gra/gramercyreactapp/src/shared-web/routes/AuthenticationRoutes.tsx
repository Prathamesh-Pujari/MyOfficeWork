import { lazy } from 'react';

// project imports
import Loadable from "../loader/Loadable";
import MinimalLayout from '../layout/MinimalLayout';

// login option 3 routing
const AuthLogin = Loadable(lazy(() => import('../../portal-web/pages/LoginPage')));
const AuthRegister = Loadable(lazy(() => import('../../portal-web/pages/RegisterPage')));

// ==============================|| AUTHENTICATION ROUTING ||============================== //

const AuthenticationRoutes = {
    path: '/',
    element: <MinimalLayout />,
    children: [
        {
            path: '/pages/login',
            element: <AuthLogin />
        },
        {
            path: '/pages/register',
            element: <AuthRegister />
        }
    ]
};

export default AuthenticationRoutes;
