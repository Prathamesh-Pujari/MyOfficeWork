import React from 'react';
import { useRoutes } from 'react-router-dom';

// routes
import AppRoutes from './AppRoutes';
import AuthenticationRoutes from './AuthenticationRoutes';

// ==============================|| ROUTING RENDER ||============================== //
interface AppRoutesProps{
    isLoggedIn: boolean;
}
export const RoutesMain:React.FC<AppRoutesProps> = ({isLoggedIn}) => {
    return useRoutes([AppRoutes(isLoggedIn), AuthenticationRoutes]);
}
