import { lazy } from 'react';

// project imports
import LayoutMain from '../layout/MainLayout/LayoutMain';
import Loadable from '../loader/Loadable';
import { RouteObject } from 'react-router-dom';
import MinimalLayout from '../layout/MinimalLayout';
import HRPage from '../../portal-web/pages/HRPage';
import EmuDetailsPage from '../../portal-web/pages/emu/EmuDetailsPage';
import { TableauIntegration } from '../../portal-web/app-components/shared/analytics/tableauIntegration/TableauIntegration';
import { MonthlyPerformance } from '../../portal-web/app-components/tables/MonthlyPerformance';

// login 
const AuthLogin = Loadable(lazy(() => import('../../portal-web/pages/LoginPage')));
// dashboard routing
const Dashboard = Loadable(lazy(() => import('../../portal-web/pages/dashboard/DashboardPage')));
// dashboard routing
const AdminDashboard = Loadable(lazy(() => import('../../admin-web/pages/AdminDashboardPage')));
const WidgetBuilder = Loadable(lazy(() => import('../../admin-web/pages/WidgetBuilderPage')));

// ==============================|| MAIN ROUTING ||============================== //

function AppRoutes(isLoggedIn: boolean): RouteObject {
    return {
        path: '/',
        element: isLoggedIn ? <LayoutMain /> : <MinimalLayout />,
        children: [
            {
                path: '/',
                element: isLoggedIn ? <Dashboard /> : <AuthLogin />
            },
            {
                path: '/emu',
                element: isLoggedIn ? <EmuDetailsPage /> : <AuthLogin />
            },
            {
                path: '/historicalPerformance',
                element: isLoggedIn ? <MonthlyPerformance title="Monthly Performance" /> : <AuthLogin />
            },
            {
                path: '/tableauDashboard',
                element: isLoggedIn ? <TableauIntegration /> : <AuthLogin />
            },
            {
                path: '/hr',
                element: isLoggedIn ? <HRPage /> : <AuthLogin />
            },
            {
                path: '/admindashboard',
                element: isLoggedIn ? <AdminDashboard /> : <AuthLogin />
            },
            {
                path: '/admindashboard/WidgetBuilder',
                element: isLoggedIn ? <WidgetBuilder /> : <AuthLogin />
            }
        ]
    };
};

export default AppRoutes;
