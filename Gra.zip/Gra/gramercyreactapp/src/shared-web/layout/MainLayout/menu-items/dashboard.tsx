// assets
import HomeIcon from '@mui/icons-material/Home';

// ==============================|| DASHBOARD MENU ITEMS ||============================== //



const dashboard = {
    id: 'default',
    title: 'Dashboard',
    type: 'group',
    icon: <HomeIcon />,
    children: [
        {
            id: 'default',
            title: 'Dashboard',
            type: 'item',
            url: '/',
            breadcrumbs: false
        }
    ]
};

export default dashboard;
