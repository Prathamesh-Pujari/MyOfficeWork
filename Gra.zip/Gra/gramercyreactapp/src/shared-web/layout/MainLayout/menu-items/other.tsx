import GroupIcon from '@mui/icons-material/Group';

// ==============================|| SAMPLE PAGE & DOCUMENTATION MENU ITEMS ||============================== //

const other = {
    id: 'other-data',
    title: 'HR',
    type: 'group',
    icon: <GroupIcon />,
    children: [
        {
            id: 'hr',
            title: 'HR',
            type: 'item',
            url: '/hr',
            breadcrumbs: false
        }
    ]
};

export default other;
