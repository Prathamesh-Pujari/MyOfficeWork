import ManageAccountsIcon from '@mui/icons-material/ManageAccounts';

const admin = {
    id: 'admin',
    title: 'Admin Dashboard',
    icon: <ManageAccountsIcon />,
    type: 'group',
    children: [
        {
            id: 'admin',
            title: 'Admin Dashboard',
            type: 'item',
            url: '/admindashboard',
            breadcrumbs: false
        }
    ]
}

export default admin;