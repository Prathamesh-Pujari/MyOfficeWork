// assets
import { IconUsers } from '@tabler/icons';

// constant
const icons = {
    IconUsers
};

// ==============================|| EXTRA PAGES MENU ITEMS ||============================== //

const reference = {
    id: 'reference',
    title: 'Reference Data',
    type: 'group',
    children: [
        {
            id: 'employee-data',
            title: 'Employee Data',
            type: 'item',
            url: '?',
            icon: icons.IconUsers
        }
    ]
};

export default reference;
