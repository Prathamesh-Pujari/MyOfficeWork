// assets
import { IconBolt, IconTool, IconTools, IconStack3, IconTrees } from '@tabler/icons';

// constant
const icons = {
    IconBolt,
    IconTool,
    IconTools,
    IconStack3,
    IconTrees
};

// ==============================|| UTILITIES MENU ITEMS ||============================== //

const tools = {
    id: 'tools',
    title: 'Tools & Application',
    type: 'group',
    children: [
        {
            id: 'tools',
            title: 'Tools',
            type: 'collapse',
            icon: icons.IconTools,
            children: [
                {
                    id: 'emu-detail',
                    title: 'EMU Detail',
                    type: 'item',
                    url: '?',
                    icon: icons.IconBolt,
                    breadcrumbs: false
                },
                {
                    id: 'technical',
                    title: 'Technical',
                    type: 'item',
                    url: '?',
                    icon: icons.IconTool,
                    breadcrumbs: false
                },
                {
                    id: 'fundamental',
                    title: 'Fundamental',
                    type: 'item',
                    url: '?',
                    icon: icons.IconStack3,
                    breadcrumbs: false
                },
                {
                    id: 'esg-detail',
                    title: 'ESG Detail',
                    type: 'item',
                    url: '?',
                    icon: icons.IconTrees,
                    breadcrumbs: false
                }
            ]
        }
    ]
};

export default tools;
