import other from './other';
import analytics from './analytics';
import admin from './admin';

// ==============================|| MENU ITEMS ||============================== //

const MenuItemsMain = {
    items: [
        analytics,    
        other,
        admin
    ]
};

export default MenuItemsMain;
