import PieChartIcon from '@mui/icons-material/PieChart';
import TableViewIcon from '@mui/icons-material/TableView';
import WatchLaterIcon from '@mui/icons-material/WatchLater';
import AssessmentIcon from '@mui/icons-material/Assessment';

// ==============================|| EXTRA PAGES MENU ITEMS ||============================== //

const analytics = {
    id: 'analytics',
    title: 'Analytics',
    icon: <PieChartIcon />,
    type: 'group',
    children: [
        {
            id: 'emd',
            title: 'EMU',
            type: 'item',
            url: '/emu',
            icon: <TableViewIcon />,
            breadcrumbs: false
        },
        {
            id: 'historicalPerformance',
            title: 'Historical Performance',
            type: 'item',
            url: '/historicalPerformance',
            icon: <WatchLaterIcon />,
            breadcrumbs: false
        },
        {
            id: 'tableauDashboard',
            title: 'Tableau Dashboard',
            type: 'item',
            url: '/tableauDashboard',
            icon: <AssessmentIcon />,
            breadcrumbs: false
        },

    ]
};

export default analytics;
