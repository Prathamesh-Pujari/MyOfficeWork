import React from 'react';

// material-ui
import { Divider, Typography } from '@mui/material';

// project imports
import NavItem from './NavItem';
import NavCollapse from './NavCollapse';
import {
    Menu,
    MenuItem,
    SubMenu,
} from "react-pro-sidebar";
import { Link } from 'react-router-dom';

// ==============================|| SIDEBAR MENU LIST GROUP ||============================== //
interface NavGroupProps {
    item: any;
}

const NavGroup: React.FC<NavGroupProps> = ({ item }) => {
    // menu list collapse & items
    const items = item.children?.map((menu: any) => {
        switch (menu.type) {
            case 'collapse':
                return <NavCollapse key={menu.id} menu={menu} level={1} />;
            case 'item':
                return <NavItem key={menu.id} item={menu} level={1} />;
            default:
                return (
                    <Typography key={menu.id} variant="h6" color="error" align="center">
                        Menu Items Error
                    </Typography>
                );
        }
    });

    return (
        <>
            <Menu iconShape="circle">
                {item.children.length <= 1 ? <MenuItem title={item.title} icon={item.icon}>{item.title} <Link to={item.children[0].url} /> </MenuItem> : <SubMenu title={item.title} icon={item.icon} >
                    {items}
                </SubMenu>
                }
            </Menu>           
            <Divider sx={{ mt: 0.25, mb: 1.25, borderColor: '#6e6e6ea6' }} />
        </>
    );
};

export default NavGroup;
