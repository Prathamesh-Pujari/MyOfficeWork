import React, { forwardRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';

// material-ui
import { useTheme } from '@mui/material/styles';
import { Avatar, Chip, ListItemButton, useMediaQuery } from '@mui/material';

// project imports
import * as layoutActions from '../../../../reducers/layoutReducer/layoutActions';
// assets
import FiberManualRecordIcon from '@mui/icons-material/FiberManualRecord';
import { RootState } from '../../../../reducers/ReducerMain';
import {
    MenuItem,
} from "react-pro-sidebar";

// ==============================|| SIDEBAR MENU LIST ITEMS ||============================== //
interface NavItemProps {
    item: any;
    level: number;
}

const NavItem: React.FC<NavItemProps> = ({ item, level }) => {
    const theme: any = useTheme();
    const dispatch = useDispatch();
    const customization = useSelector((state: RootState) => state.layout);
    const matchesSM = useMediaQuery(theme.breakpoints.down('lg'));

    const Icon = item.icon;
    const itemIcon = item?.icon ? (
        <Icon stroke={1.5} size="1.3rem" />
    ) : (
        <FiberManualRecordIcon
            sx={{
                width: customization.isOpen.findIndex((id) => id === item?.id) > -1 ? 8 : 6,
                height: customization.isOpen.findIndex((id) => id === item?.id) > -1 ? 8 : 6
            }}
            fontSize={level > 0 ? 'inherit' : 'medium'}
        />
    );

    let itemTarget = '_self';
    if (item.target) {
        itemTarget = '_blank';
    }
    let listItemProps = {
        component: forwardRef<any, any>((props, ref) => <Link ref={ref} {...props} to={`${item.url}`} target={itemTarget} />)
    };
    if (item?.external) {
        // @ts-ignore-start
        listItemProps = { component: 'a', href: item.url, target: itemTarget };
        // @ts-ignore-end
    }

    const itemHandler = (id: any) => {
        dispatch({ type: layoutActions.Type.MENU_OPEN, id });
    };

    // active menu item on page load
    useEffect(() => {
        const currentIndex = document.location.pathname
            .toString()
            .split('/')
            .findIndex((id) => id === item.id);
        if (currentIndex > -1) {
            dispatch({ type: layoutActions.Type.MENU_OPEN, id: item.id });
        }
        // eslint-disable-next-line
    }, []);

    return (
        <>
            <ListItemButton
                {...listItemProps}
                disabled={item.disabled}
                className={customization.isOpen.findIndex((id) => id === item.id) > -1 ? 'left-menu-active' : 'left-menu-inactive'}
                sx={{
                    borderRadius: `${customization.borderRadius}px`,
                    alignItems: 'flex-start',
                    py: level > 1 ? 1 : 1.25,
                    pl: `${level * 10}px`
                }}
                selected={customization.isOpen.findIndex((id) => id === item.id) > -1}
                onClick={() => itemHandler(item.id)}
            >

                <MenuItem icon={item.icon}> {item.title} </MenuItem>
                {item.chip && (
                    <Chip
                        color={item.chip.color}
                        variant={item.chip.variant}
                        size={item.chip.size}
                        label={item.chip.label}
                        avatar={item.chip.avatar && <Avatar>{item.chip.avatar}</Avatar>}
                    />
                )}
            </ListItemButton>
        </>
    );
};

export default NavItem;
