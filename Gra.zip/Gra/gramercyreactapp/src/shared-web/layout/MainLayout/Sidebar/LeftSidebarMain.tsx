import React, { useState } from "react";
// material-ui
import { useTheme } from "@mui/material/styles";
import { Box, Drawer, SwipeableDrawer, useMediaQuery } from "@mui/material";
// third-party
// project imports
import MenuListMain from "./MenuList/MenuListMain";
// import logo from '../../../../assets/images/logos.png'
import logoRound from '@images/circleLogo.png';
import logoName from '@images/gramercyLogo145.png';
import {
    ProSidebar,
    Menu,
    SidebarHeader,
    SidebarFooter,
    SidebarContent,
} from "react-pro-sidebar";
import "react-pro-sidebar/dist/css/styles.css";
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import { Link } from 'react-router-dom';
import "./leftSidebarMain.scss";
// ==============================|| SIDEBAR DRAWER ||============================== //
interface SidebarProps {
    drawerOpen: boolean;
    window?: any;
    drawerToggle(): void;
}
const LeftSidebarMain: React.FC<SidebarProps> = ({
    drawerOpen,
    drawerToggle,
    window,
}) => {
    const theme = useTheme();
    const matchUpMd = useMediaQuery(theme.breakpoints.up("md"));
    const [menuCollapse, setMenuCollapse] = useState(true);
    const menuIconClick = () => {
        menuCollapse ? setMenuCollapse(false) : setMenuCollapse(true);
    };
    drawerOpen = matchUpMd ? drawerOpen : !drawerOpen;
    const drawer = (

        <>
            < ProSidebar className="proSidebarMain" collapsed={drawerOpen}>
                <SidebarHeader>
                    <div className="closemenu" onClick={menuIconClick}>
                        <Link to="/" >{drawerOpen ? <img src={logoRound} width='45' alt="" /> : <img src={logoName} width='145' alt="" />}</Link>
                    </div>
                </SidebarHeader>
                <SidebarContent>
                    <MenuListMain />
                </SidebarContent>
                <SidebarFooter>
                    <Menu iconShape="square">
                        {drawerOpen ? <ArrowForwardIosIcon className="rightIcon" onClick={drawerToggle} /> : <ArrowBackIosIcon className="leftIcon" onClick={drawerToggle} />}
                    </Menu>
                </SidebarFooter>
            </ProSidebar>
        </>
    );
    const container =
        window !== undefined ? () => window.document.body : undefined;
    return (
        <Box
            component="nav"
            aria-label="mailbox folders"
        >
            <SwipeableDrawer
                container={container}
                variant="permanent"
                anchor="left"
                open={drawerOpen}
                onClose={drawerToggle}
                onOpen={drawerToggle}
                sx={{
                    "& .MuiDrawer-paper": {
                        background: theme.palette.background.default,
                        color: theme.palette.text.primary,
                        borderRight: "none",
                    },
                }}
                ModalProps={{ keepMounted: true }}
                color="inherit"
            >
                {drawer}
            </SwipeableDrawer>
        </Box>
    );
};
export default LeftSidebarMain;
