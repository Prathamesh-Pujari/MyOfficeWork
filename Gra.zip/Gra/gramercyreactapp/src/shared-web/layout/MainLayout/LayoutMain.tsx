import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Outlet } from "react-router-dom";

// material-ui
import { CSSObject, styled, Theme, useTheme } from "@mui/material/styles";
import {
  AppBar,
  Box,
  CssBaseline,
  Toolbar,
  useMediaQuery,
} from "@mui/material";

// project imports
import Breadcrumbs from "../../../portal-web/app-components/buttons/Breadcrumbs";
import HeaderMain from "./Header/HeaderMain";
import LeftSidebarMain from "./Sidebar/LeftSidebarMain";
import navigation from "./menu-items/MenuItemsMain";
// assets
import { IconChevronRight } from "@tabler/icons";
import { RootState } from "../../reducers/ReducerMain";

import * as layoutAction from "../../reducers/layoutReducer/layoutActions";
import "./layoutMain.scss";
import colors from "@styles/_themes-vars.module.scss";


const openedMixin = (theme: Theme): CSSObject => ({
  // width: drawerWidth,
  transition: theme.transitions.create("width", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.enteringScreen,
  }),
  overflowX: "hidden",
});

const closedMixin = (theme: Theme): CSSObject => ({
  transition: theme.transitions.create("width", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  overflowX: "hidden",
});
// styles
const Main = styled("main", {
  shouldForwardProp: (prop: any) => prop !== "open",
})(
  ({
    theme,
    // @ts-ignore
    open,
  }) => {
    const themeData: any = theme;

    return {
      ...themeData.typography.mainContent,
      ...(!open && {
        ...openedMixin(theme),
        "& .MuiDrawer-paper": openedMixin(theme),
        zIndex: theme.zIndex.drawer + 1,
        transition: theme.transitions.create(["width", "margin"], {
          easing: theme.transitions.easing.sharp,
          duration: theme.transitions.duration.leavingScreen,
        }),
        borderBottomLeftRadius: 0,
        borderBottomRightRadius: 0,
      }),
      ...(open && {
        ...closedMixin(theme),
        "& .MuiDrawer-paper": closedMixin(theme),
        transition: theme.transitions.create(["width", "margin"], {
          easing: theme.transitions.easing.sharp,
          duration: theme.transitions.duration.enteringScreen,
        }),
        borderBottomLeftRadius: 0,
        borderBottomRightRadius: 0,
        // width: `calc(100% - ${drawerWidth}px)`,
      }),
    };
  }
);

// ==============================|| MAIN LAYOUT ||============================== //

const LayoutMain: React.FC = () => {
  const theme = useTheme();
  const matchDownMd = useMediaQuery(theme.breakpoints.down("lg"));
  // Handle left drawer
  const leftDrawerOpened = useSelector(
    (state: RootState) => state.layout.opened
  );
  const dispatch = useDispatch();
  const handleLeftDrawerToggle = () => {
    dispatch({ type: layoutAction.Type.SET_MENU, opened: !leftDrawerOpened });
  };

  useEffect(() => {
    dispatch({ type: layoutAction.Type.SET_MENU, opened: !matchDownMd });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [matchDownMd]);

  return (
    <Box sx={{ display: "flex" }}>
      <CssBaseline />
      <AppBar
        className="appBarMain bgImage"
        enableColorOnDark
        position="fixed"
        color="inherit"
        aria-label="open drawer"
        sx={{
          backgroundColor: `${colors.hBgColor} !important`,
          boxShadow: "none",
          borderBottom: colors.borderWithColor,
          transition: leftDrawerOpened
            ? theme.transitions.create("width")
            : "none",
        }}
      >
        <Toolbar className="headerMain">
          <HeaderMain
            leftDrawerOpened={leftDrawerOpened}
            handleLeftDrawerToggle={handleLeftDrawerToggle}
          />
        </Toolbar>
      </AppBar>

      <LeftSidebarMain
        drawerOpen={leftDrawerOpened}
        drawerToggle={handleLeftDrawerToggle}
      />

      <Main
        theme={theme}
        //@ts-ignore
        open={leftDrawerOpened}
      >
        <Breadcrumbs
          separator={IconChevronRight}
          navigation={navigation}
          icon
          title
          rightAlign
        />
        <Outlet />
      </Main>
    </Box>
  );
};

export default LayoutMain;
