
// material-ui
import { useTheme } from '@mui/material/styles';
import { Box } from '@mui/material';

// project imports
import LogoSection from '../LogoSection';

// assets
import RightSidebarMain from '../../../../portal-web/app-components/rightSidebar/RightSidebarMain';
import { DashboardLayoutSelection } from './DashboardLayoutSelection';
import "./header.scss";
import MenuIcon from "@mui/icons-material/Menu";


// ==============================|| MAIN NAVBAR / HEADER ||============================== //
interface HeaderProps {
    leftDrawerOpened: boolean;
    handleLeftDrawerToggle(): void;
}

const HeaderMain: React.FC<HeaderProps> = ({ leftDrawerOpened, handleLeftDrawerToggle }) => {
    const theme: any = useTheme();

    return (
        <>
            {/* logo & toggler button */}
            {/* <Box
                sx={{
                    width: leftDrawerOpened ? 228 : 100,
                    display: 'flex',
                    [theme.breakpoints.down('md')]: {
                        width: 'auto'
                    }
                }}
            >
                <Box component="span" sx={{ display: leftDrawerOpened ? 'block' : 'none', flexGrow: 1 }}>
                    <LogoSection leftDrawerOpened={leftDrawerOpened} />
                </Box>
            </Box> */}
            <MenuIcon id="burger" onClick={handleLeftDrawerToggle} />

            <Box sx={{ flexGrow: 1 }} />
            <Box sx={{ flexGrow: 1 }} />
            {/* <SearchSection /> */}
            {/* <NotificationSection /> */}
            {/* <ProfileSection /> */}
            <DashboardLayoutSelection />
            <RightSidebarMain />


        </>
    );
};

export default HeaderMain;
