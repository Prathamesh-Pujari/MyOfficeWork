
import { useTheme } from "@mui/material/styles";
import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../../../reducers/ReducerMain";
import * as dashboardActions from '../../../../portal-web/reducers/dashboardReducer/dashboardActions';
import {
    IconButton,
    Tooltip
} from '@mui/material';
import ViewAgendaOutlinedIcon from '@mui/icons-material/ViewAgendaOutlined';
import ViewWeekOutlinedIcon from '@mui/icons-material/ViewWeekOutlined';


export const DashboardLayoutSelection: React.FC = () => {

    const theme = useTheme();
    const dispatch = useDispatch();
    const selectedDashboardGridLayout = useSelector((state: RootState) => state.dashboard.updateDashoboardGridLayout);

    const handleChangeDashboardLayout = (columns: any) => {
        dispatch({ type: dashboardActions.Type.SET_DASHBOARD_GRID_LAYOUT, payload: columns });
    }
    return (
        <div className="dashboardLayoutMain">
            {selectedDashboardGridLayout === 3 ?

                <Tooltip title="Change to 2 Column Layout">
                    <IconButton className="gridLayoutIcons rotate" onClick={() => handleChangeDashboardLayout(2)}>
                        <ViewAgendaOutlinedIcon sx={selectedDashboardGridLayout === 2 ? { color: theme.palette.primary.main } : {}} />
                    </IconButton>
                </Tooltip>

                :
                <Tooltip title="Change to 3 Column Layout" >
                    <IconButton className="gridLayoutIcons" onClick={() => handleChangeDashboardLayout(3)}>
                        <ViewWeekOutlinedIcon sx={selectedDashboardGridLayout === 3 ? { color: theme.palette.primary.main } : {}} />
                    </IconButton>
                </Tooltip>
            }
        </div>
    );

}
