import { Link } from 'react-router-dom';

// material-ui
import { ButtonBase } from '@mui/material';

// project imports
import Logo, { CollapseLogo } from '../../logo/Logo';

// ==============================|| MAIN LOGO ||============================== //

interface LogoSectionProps {
    leftDrawerOpened?: boolean;
}

const LogoSection: React.FC<LogoSectionProps> = ({ leftDrawerOpened = true }) => (
    <ButtonBase disableRipple component={Link} to={'/'}>
        {
            leftDrawerOpened ?
                <Logo />
                :
                <CollapseLogo />
        }
    </ButtonBase>
);

export default LogoSection;
