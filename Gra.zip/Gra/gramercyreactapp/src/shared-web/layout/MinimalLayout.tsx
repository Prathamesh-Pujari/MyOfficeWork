import React from 'react';
import { Outlet } from 'react-router-dom';

// project imports
import RightSidebarMain from '../../portal-web/app-components/rightSidebar/RightSidebarMain';

// ==============================|| MINIMAL LAYOUT ||============================== //

const MinimalLayout: React.FC = () => (
    <>
        <Outlet />
        <RightSidebarMain />
    </>
);

export default MinimalLayout;
