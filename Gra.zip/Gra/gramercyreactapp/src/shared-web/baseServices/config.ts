import { Dictionary } from "./Collections";


export function readEnvString(env: Dictionary<string>, key: string): string {
    return env[key] as string;
}


export class BaseConfigProcessor {
    processConfig(env: Dictionary<string>): AppSettingsBase {
        return {
            ApiUrl: readEnvString(env, "REACT_APP_API_URL"),
        };
    }
}

export interface AppSettingsBase {
    ApiUrl: string;
}

const configProcessor = new BaseConfigProcessor();
export const config = configProcessor.processConfig(process.env);
