import axios, { AxiosRequestConfig, AxiosResponse } from "axios";
import { ConfigurationService } from "./ConfigurationService";

export enum HttpMethod {
  Delete,
  Get,
  Patch,
  Post,
  Put,
}
export class ErrorApiException extends Error {
  error: APIErrorResponse;
  constructor(error: APIErrorResponse, message?: string) {
    super(message);
    this.error = error;
  }
}

export interface RequestConfig {
  headers?: { [headerId: string]: string };
  responseType?: ResponseType;
}

export type ResponseType =
  | "arraybuffer"
  | "blob"
  | "document"
  | "json"
  | "text"
  | "stream";

let res: any;

const getResponse = async <ResT, ReqT>(
  httpMethod: HttpMethod,
  relativeUrl: string,
  data?: ReqT,
  config: RequestConfig = {}
): Promise<ResT> => {
  let fullUrl: string;
  const axiosRequestConfig: AxiosRequestConfig | undefined = config;
  fullUrl = `${ConfigurationService.AppSettings.ApiUrl}${relativeUrl}`;
  switch (httpMethod) {
    case HttpMethod.Get: {
      try {
        const response: any = await axios.get<APIResponse<ResT>>(
          fullUrl,
          axiosRequestConfig
        );
        if (response?.status === 200) {
          res = response?.data || response?.status;
        }
      } catch (error: any) {
        handleError(error.response, "GET");
      }
      break;
    }
    case HttpMethod.Post: {
      try {
        const response = await axios.post<
          ReqT,
          AxiosResponse<APIDataResponse<ResT>>
        >(fullUrl, data, axiosRequestConfig);
        if (response?.status === 200) {
          res = response.data;
        }
      } catch (error: any) {
        handleError(error.response, "POST", "", data);
      }
      break;
    }

    case HttpMethod.Put: {
      try {
        const response = await axios.put<
          ReqT,
          AxiosResponse<APIDataResponse<ResT>>
        >(relativeUrl, data, axiosRequestConfig);
        if (response?.data?.result === "success") {
          res = response.data.data;
        }
      } catch (error: any) {
        handleError(error.response, "PUT", "", data);
      }
      break;
    }

    case HttpMethod.Patch: {
      try {
        const response = await axios.patch<
          ReqT,
          AxiosResponse<APIDataResponse<ResT>>
        >(relativeUrl, data, axiosRequestConfig);
        res = response?.data?.data;
      } catch (error: any) {
        handleError(error.response, "PATCH", "", data);
      }
      break;
    }

    case HttpMethod.Delete: {
      try {
        const response = await axios.delete<
          ReqT,
          AxiosResponse<APIDataResponse<ResT>>
        >(relativeUrl, axiosRequestConfig);
        if (response?.data?.result === "success") {
          res = response.data.data;
        }
      } catch (error: any) {
        handleError(error.response, "DELETE", "", data);
      }
      break;
    }
    default: {
      return Promise.reject("Invalid HTTP Method " + httpMethod);
    }
  }
  return res;
};

const handleError = (error: any, method: string, fullUrl = "", data = {}): void => {
  if (error.response) {
    const apiError = error.response as APIErrorResponse;
    console.error(
      `Error in request. Error Code: ${apiError.status
      } URL requested: ${fullUrl} Payload: ${JSON.stringify(data)}`
    );
    throw new ErrorApiException(
      apiError,
      `Error in ${method} request. Error Code: ${apiError.status}. Message: ${apiError.data?.message}`
    );
  } else if (error.data?.error) {
    console.error(
      `Error in request. Error: ${error.message
      } URL requested: ${fullUrl} Payload: ${JSON.stringify(
        data
      )}, Result: ${JSON.stringify(error.data?.error)}`
    );
    throw error.data.error;
  } else {
    console.error(
      `Error in request. Error: ${error.message
      } URL requested: ${fullUrl} Payload: ${JSON.stringify(data)}`
    );
    throw error;
  }
};

export const apiPost = async <ReqT, ResT>(url: string, data?: ReqT): Promise<ResT> =>
  await getResponse(HttpMethod.Post, url, data);
export const apiPut = async <ReqT, ResT>(url: string, data?: ReqT): Promise<ResT> =>
  await getResponse(HttpMethod.Put, url, data);
export const apiPatch = async <ReqT, ResT>(url: string, data?: ReqT): Promise<ResT> =>
  await getResponse(HttpMethod.Patch, url, data);
export const apiGet = async <ResT>(url: string): Promise<ResT> =>
  await getResponse(HttpMethod.Get, url, undefined);
export const apiDelete = async <ResT>(url: string): Promise<ResT> =>
  await getResponse(HttpMethod.Delete, url, undefined);

export enum Status {
  Loading = 0,
  Loaded,
  Error,
  Unauthorized,
}

export type Service<T> = {
  status: Status;
  payload?: T;
  error?: Error;
};

export type APIResponse<T> =
  APIDataResponse<T> | APIErrorResponse;

export type APIErrorResponse = {
  data?: {
    message: string;
    result: "error";
  };
  status: number;
  statusText: string;
  config: {
    data?: object;
    method: string;
    url: string;
  };
};

export type APIMessageResponse = {
  result: "success";
  message: string;
};

export type APIDataResponse<T> = {
  result: "success";
  data: T;
};

export type APIDataResponsePaginated<T> = APIDataResponse<T> & {
  size: number;
  totalCount: number;
  offset: number;
  nextUrl?: string;
};
