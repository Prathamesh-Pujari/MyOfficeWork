import React, { ReactNode } from "react";
import "./Label.scss";

interface Props extends React.LabelHTMLAttributes<HTMLInputElement> {
  text: ReactNode;
}

export const Label: React.FC<Props> = ({ htmlFor, text}) => {
 
  return (
    <label htmlFor={htmlFor}>
      {text ?? ""}
    </label>
  );
};
