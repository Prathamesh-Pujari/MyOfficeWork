/**
 * Application types
 */

export interface sample{}