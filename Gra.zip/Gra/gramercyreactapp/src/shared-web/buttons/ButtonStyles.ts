import { makeStyles } from "@material-ui/core";

export const useStyles = makeStyles({
    btn1: {
        float: "right",
        margin: "0px 10px !important"
        // color: "#000 !important",
        // backgroundColor: "#d3d3d3 !important"
    },
    queryListbtn: {
        float: "right",
        margin: "0px 10px !important"
    }
})