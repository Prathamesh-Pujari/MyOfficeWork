import { Button, IconButton, Tooltip } from '@mui/material'
import React from 'react'
import Typography from '@mui/material/Typography';
import { btnColorType, btnSizeType, buttonTypeVariants, buttonVariants, toolTipPositionType } from '../enums/Buttons';
import { Zoom } from '@material-ui/core';


interface Properties {
    buttonList: {
        buttonType: buttonTypeVariants
        variant?: buttonVariants;
        label: string | JSX.Element;
        toolTipLabel: string;
        handleOnBtnClick?(e?:any): void;
        btnColor: btnColorType;
        btnclassName: any;
        btnSize: btnSizeType
        toolTipPosition?: toolTipPositionType
        type?:string;
    }[];

}

export const Buttons: React.FC<Properties> = (props) => {
    const { buttonList } = props

    return (
        <Typography>
            {
                buttonList.map((item: any, index: number) => {
                    return (
                        <React.Fragment key={index}>
                            {item.buttonType === buttonTypeVariants.button ?

                                <Button size={item.btnSize} type={item.type} className={item.btnclassName} variant={item.variant} color={item.btnColor} onClick={item.handleOnBtnClick} >{item.label}</Button>
                                : (
                                    <Tooltip title={item.toolTipLabel} placement={item.toolTipPosition} arrow TransitionComponent={Zoom}>
                                        <IconButton size={item.btnSize} className={item.btnclassName} color={item.btnColor} onClick={item.handleOnBtnClick}  >{item.label}</IconButton>
                                    </Tooltip>)
                            }
                        </React.Fragment>
                    )
                })


            }
        </Typography>
    )
}


