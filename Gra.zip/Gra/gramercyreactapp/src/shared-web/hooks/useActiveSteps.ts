import React from "react";

export const useActiveSteps = (activeStep?: number) => {
    const [currentStep, setCurrentStep] = React.useState<number>(0);
    const handleNext = () => {
        setCurrentStep(currentStep + 1);
    };

    const handleBack = () => {
        setCurrentStep(currentStep - 1);
    };

    return { currentStep, handleNext, handleBack }
}  