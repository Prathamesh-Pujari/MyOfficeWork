/// <reference types="react-scripts" />
import PopupState  from 'material-ui-popup-state';

declare const PopupState;